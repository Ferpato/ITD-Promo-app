export class NaviBarClass {
   static titles: string[] = ["Inicio", "Oferta educativa", "Materias", "Proyectos"];
   static routes: string[] = ["/", "/oferta", "/materias", "/proyectos"]
   static icons: string[] = [
      "/assets/svg/NaviBar/home.svg",
      "/assets/svg/NaviBar/briefcase.svg",
      "/assets/svg/NaviBar/bookmark.svg",
      "/assets/svg/NaviBar/user-check.svg"];
}