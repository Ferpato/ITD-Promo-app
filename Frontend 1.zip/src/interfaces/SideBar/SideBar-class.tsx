export class SideBarClass {
    static routes: string[] = ["/inicio", "/oferta", "/materias", "/proyectos"]
}