

export interface Proyecto {
  id: number;
  indexSlider: number;
  media: string;
}