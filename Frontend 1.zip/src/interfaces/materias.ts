export interface Materia {
  id: number;
  nombre: string;
  descripcion: string;
  imagen?: never[]; // Ajusta el tipo de 'imagen' según tu backend
  // ... otras propiedades que tu objeto materia pueda tener
}