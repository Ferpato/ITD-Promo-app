"use client";
import React from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";

interface ButtonLinkProps {
    text: string;
    route: string;
    icon: string;
    gradientFrom: string;
    gradientTo: string;
    underlined?: boolean;
    //animated?: boolean;
}

export default function ButtonLink({ text, route, icon, gradientFrom, gradientTo, underlined }: ButtonLinkProps) {
    const router = useRouter();

    return (
        <div className="grid grid-cols-1">
            <div className={"flex min-w-fit justify-between lg:justify-center p-6 pl-10 pr-10 gap-5 rounded-full"+
            " text-base lg:text-[1.65rem] text-white  font-semibold cursor-pointer " +
                " bg-gradient-to-r " + gradientFrom + " " + gradientTo}
                onClick={() => {
                    if (route.startsWith('http')) {
                        window.open(route, '_blank');
                    } else {
                        router.push(route);
                    }
                }}>{text}
                <Image className="w-6 lg:w-8" height={1} width={1}
                    src={icon} alt="icono" />
            </div>
            <div className={"m-auto mt-3 h-[0.35rem] rounded-full w-[65%]" +
                (underlined ?? false ? (" bg-gradient-to-r " + gradientFrom + " " + gradientTo) : "")
            } />
        </div>
    );
}