import React from "react";

const COLORS = [
    // Standard Tailwind Colors
    { name: "Azul (Estándar)", from: "from-blue-500", to: "to-blue-500", preview: "bg-blue-500" },
    { name: "Rojo (Estándar)", from: "from-red-500", to: "to-red-500", preview: "bg-red-500" },
    { name: "Verde (Estándar)", from: "from-green-500", to: "to-green-500", preview: "bg-green-500" },
    { name: "Amarillo (Estándar)", from: "from-yellow-400", to: "to-yellow-400", preview: "bg-yellow-400" },
    { name: "Rosa (Estándar)", from: "from-rose-700", to: "to-rose-700", preview: "bg-rose-700" },
    { name: "Violeta (Estándar)", from: "from-violet-500", to: "to-violet-500", preview: "bg-violet-500" },
    { name: "Cian (Estándar)", from: "from-cyan-500", to: "to-cyan-500", preview: "bg-cyan-500" },
    { name: "Naranja (Estándar)", from: "from-orange-500", to: "to-orange-500", preview: "bg-orange-500" },
    { name: "Gris (Estándar)", from: "from-gray-500", to: "to-gray-500", preview: "bg-gray-500" },
    { name: "Negro", from: "from-black", to: "to-black", preview: "bg-black" },
    { name: "Blanco", from: "from-white", to: "to-white", preview: "bg-white border border-gray-400" },
    { name: "Indigo (Estándar)", from: "from-indigo-500", to: "to-indigo-500", preview: "bg-indigo-500" },
    { name: "Lima (Estándar)", from: "from-lime-500", to: "to-lime-500", preview: "bg-lime-500" },
    { name: "Celeste (Estándar)", from: "from-sky-400", to: "to-sky-400", preview: "bg-sky-400" },
    { name: "Ámbar (Estándar)", from: "from-amber-800", to: "to-amber-800", preview: "bg-amber-800" },
    { name: "Turquesa (Estándar)", from: "from-teal-400", to: "to-teal-400", preview: "bg-teal-400" },

    // Custom Colors from globals.css
    { name: "Azul Claro (Custom)", from: "from-light-blue", to: "to-light-blue", preview: "bg-light-blue" },
    { name: "Azul Claro Oscuro (Custom)", from: "from-dark-light-blue", to: "to-dark-light-blue", preview: "bg-dark-light-blue" },
    { name: "Verde Claro (Custom)", from: "from-light-green", to: "to-light-green", preview: "bg-light-green" },
    { name: "Verde Claro Oscuro (Custom)", from: "from-dark-light-green", to: "to-dark-light-green", preview: "bg-dark-light-green" },
    { name: "Naranja Claro (Custom)", from: "from-light-orange", to: "to-light-orange", preview: "bg-light-orange" },
    { name: "Naranja Claro Oscuro (Custom)", from: "from-dark-light-orange", to: "to-dark-light-orange", preview: "bg-dark-light-orange" },
    { name: "Azul Principal (Custom)", from: "from-blue", to: "to-blue", preview: "bg-blue" },
    { name: "Azul Oscuro Principal (Custom)", from: "from-dark-blue", to: "to-dark-blue", preview: "bg-dark-blue" },
    { name: "Guinda (Custom)", from: "from-guinda", to: "to-guinda", preview: "bg-guinda" },
    { name: "Vino (Custom)", from: "from-vino", to: "to-vino", preview: "bg-vino" },
];

interface ColorComboBoxProps {
    value?: { from: string; to: string };
    onChange?: (value: { from: string; to: string }) => void;
    idPrefix?: string;
}

const ColorComboBox: React.FC<ColorComboBoxProps> = ({
    // Set a default value that is guaranteed to be in your COLORS array.
    // This ensures a valid selection from the start.
    value = { from: COLORS[0].from, to: COLORS[1].to }, // Using COLORS[1].to as an example for the 'to' color
    onChange,
    idPrefix = 'color-combo'
}) => {
    const colorOptions = COLORS.map(color => ({ value: color.from, label: color.name }));

    // Find the full color objects for preview.
    // It's important to find by the actual 'from' or 'to' class name
    // to ensure the preview accurately reflects the selected gradient.
    const fromColorObject = COLORS.find(c => c.from === value.from);
    // For the 'to' color, we need to match its 'to' class.
    // If the 'value.to' is derived from a 'from' class (e.g., 'from-blue-500' -> 'to-blue-500'),
    // we need to find the original color object that corresponds to that 'to' class.
    const toColorObject = COLORS.find(c => c.to === value.to);


    return (
        <div className="flex flex-col gap-2 sm:gap-3">
            <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 items-start sm:items-center">
                <div className="w-full sm:w-1/2">
                    <label htmlFor={`${idPrefix}-from`} className="block text-2xs sm:text-xs font-medium text-gray-600 mb-0.5 sm:mb-1">Desde:</label>
                    <select
                        id={`${idPrefix}-from`}
                        value={value.from}
                        onChange={e => onChange?.({ ...value, from: e.target.value })}
                        className="block w-full border border-gray-300 rounded px-1.5 sm:px-2 py-0.5 sm:py-1 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-2xs sm:text-xs"
                        required // Make the field required
                    >
                        {/* No empty option needed since a default value is always set */}
                        {colorOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                    </select>
                </div>
                <div className="w-full sm:w-1/2">
                    <label htmlFor={`${idPrefix}-to`} className="block text-2xs sm:text-xs font-medium text-gray-600 mb-0.5 sm:mb-1">Hasta:</label>
                    <select
                        id={`${idPrefix}-to`}
                        value={value.to}
                        onChange={e => onChange?.({ ...value, to: e.target.value })}
                        className="block w-full border border-gray-300 rounded px-1.5 sm:px-2 py-0.5 sm:py-1 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-2xs sm:text-xs"
                        required // Make the field required
                    >
                        {/* Map 'from' values to 'to' values for the options, or directly use 'to' values if available */}
                        {COLORS.map(color => (
                            <option key={`to-${color.from}`} value={color.to}>{color.name}</option>
                        ))}
                    </select>
                </div>
            </div>
            {/* Gradient Preview */}
            <div className="mt-1 sm:mt-2">
                <label className="block text-2xs sm:text-xs font-medium text-gray-600 mb-0.5 sm:mb-1">Vista Previa:</label>
                <div
                    className={`h-8 sm:h-10 w-full rounded border border-gray-200 bg-gradient-to-r ${fromColorObject?.from || value.from} ${toColorObject?.to || value.to}`}
                    title={`Gradiente de ${fromColorObject?.name || 'color desconocido'} a ${toColorObject?.name || 'color desconocido'}`}
                >
                </div>
            </div>
        </div>
    );
};

export default ColorComboBox;