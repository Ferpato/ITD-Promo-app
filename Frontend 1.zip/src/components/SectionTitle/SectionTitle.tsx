import Image from "next/image";

interface SectionTitleProps {
    children?: React.ReactNode;
    icon: string;
    gradientTo: string;
    bgColor: string;
}

export default function SectionTitle({ children, icon, bgColor, gradientTo }: SectionTitleProps) {
    return (
        <div className={"flex flex-row mr-2 lg:mr-80"}>
            <div className={"w-full bg-gradient-to-r -mr-10 from-white/10 " +
                " " + gradientTo}>
            </div>
            <div className={"flex justify-between items-center gap-30 rounded-3xl p-2 px-4" +
                " " + bgColor
            }>
                <p className="text-white text-lg md:text-2xl font-semibold">
                    {children}
                </p>
                <div className="relative p-8 self-stretch *:brightness-100">
                    <Image src={icon} alt={"icono"} fill></Image>
                </div>
            </div>
        </div>
    );
}