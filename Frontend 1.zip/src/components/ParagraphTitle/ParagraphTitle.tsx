import React from "react";
import Image from "next/image";

interface ParagraphTitleProps {
    title: string;
    gradientFrom: string;
    gradientTo: string;
}

export default function ParagraphTitle({ title, gradientFrom, gradientTo }: ParagraphTitleProps) {
    return (
        <div className={"flex justify-start gap-4 bg-gradient-to-r h-22 items-center min-w-fit min-h-fit rounded-3xl p-4 relative z-50 " +
            "  " + gradientFrom + " " + gradientTo}>
            <div className="relative p-4 lg:p-5 -my-5">
                <Image className="" src="/assets/svg/git-commit.svg" alt="icono" fill objectFit="contain"></Image>
            </div>
            <p className="text-white font-semibold text-lg lg:text-[1.65rem] mr-10">{title}</p>
        </div>
    );
}