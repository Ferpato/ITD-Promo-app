"use client";

import { useRouter } from "next/navigation";
import React from "react";
import Image from "next/image";

interface NaviBarProps {
    selectedIndex: number;
    titles: string[];
    routes: string[];
    icons: string[];  // new: icons for mobile navigation buttons
}

export default function NaviBar({ selectedIndex, titles, routes, icons }: NaviBarProps) {
    const router = useRouter();

    function formatTitle(title: string) {
        return title.includes(' ')
            ? title.split(' ').map((word, i) => (
                <React.Fragment key={i}>
                    {word}
                    <br />
                </React.Fragment>
            ))
            : title;
    }

    function createButtons(titles: string[]) {
        return titles.map((title, i) => (
            <div
                key={i}
                className={
                    'flex h-20 items-center -my-2 cursor-pointer' +
                    (selectedIndex === i ? " bg-white text-black" : " text-white")
                }
                onClick={() => router.push(routes[i])}
            >
                {formatTitle(title.trim())}
            </div>
        ));
    }

    return (
        <>
            {/* Desktop Navigation */}
            <div className="hidden xl:flex justify-between items-center m-8 bg-gradient-to-r from-blue to-dark-blue font-semibold
                p-3 pl-8 lg:text-2xl drop-shadow-2xl rounded-full">
                <div className="flex items-center gap-2">
                    <div className="relative w-18 h-18 bg-white rounded-3xl">
                        <Image className="p-1" src="/assets/img/TecNM-logo.png" alt="TecNM logo" fill objectFit="contain" />
                    </div>
                    <p className="text-white">Tecnológico<br />Nacional de México</p>
                </div>
                <div className="bg-black/15 p-1 *:pl-10 *:pr-10 rounded-full text-2xl *:rounded-full gap-15 flex items-center justify-between">
                    {createButtons(titles)}
                </div>
            </div>
            {/* Mobile Bottom Navigation */}
            <div className="xl:hidden min-w-fit m-auto bg-gradient-to-r from-blue to-dark-blue font-semibold
                 p-3 drop-shadow-2xl rounded-full fixed bottom-0 left-0 right-0 mb-2 mx-2 px-10 z-109">
                <div className="flex flex-row justify-between items-center flex-wrap">
                    {titles.map((title, i) => (
                        <div
                            key={i}
                            onClick={() => router.push(routes[i])}
                            className="flex flex-col items-center cursor-pointer py-1"
                        >
                            <div className={"relative w-6 h-6 mb-1 px-6 rounded-full"
                                + " " + (selectedIndex === i ? "bg-white *:brightness-0" : "")
                            }>
                                <Image
                                    className="brightness-100"
                                    src={icons[i]}
                                    alt={`icon ${i}`}
                                    fill
                                    objectFit="contain"
                                />
                            </div>
                            <span className="text-xs text-center text-white">{title.split(" ")[0]}</span>
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
}