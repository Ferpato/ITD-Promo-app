import React, { useState, useEffect } from "react";

// Re-using the COLORS definition from ColorComboBox, or you can centralize it
const BASE_COLORS = [
    // Standard Tailwind Colors
    { name: "Azul (Estándar)", from: "from-blue-500", to: "to-blue-500", preview: "bg-blue-500" },
    { name: "Rojo (Estándar)", from: "from-red-500", to: "to-red-500", preview: "bg-red-500" },
    { name: "Verde (Estándar)", from: "from-green-500", to: "to-green-500", preview: "bg-green-500" },
    { name: "Amarillo (Estándar)", from: "from-yellow-400", to: "to-yellow-400", preview: "bg-yellow-400" },
    { name: "Rosa (Estándar)", from: "from-rose-700", to: "to-rose-700", preview: "bg-rose-700" }, // Assuming 'Guinda' was rose
    { name: "Violeta (Estándar)", from: "from-violet-500", to: "to-violet-500", preview: "bg-violet-500" },
    { name: "Cian (Estándar)", from: "from-cyan-500", to: "to-cyan-500", preview: "bg-cyan-500" },
    { name: "Naranja (Estándar)", from: "from-orange-500", to: "to-orange-500", preview: "bg-orange-500" },
    { name: "Gris (Estándar)", from: "from-gray-500", to: "to-gray-500", preview: "bg-gray-500" },
    { name: "Negro", from: "from-black", to: "to-black", preview: "bg-black" },
    { name: "Blanco", from: "from-white", to: "to-white", preview: "bg-white border border-gray-300" }, // Added border for white preview
    { name: "Indigo (Estándar)", from: "from-indigo-500", to: "to-indigo-500", preview: "bg-indigo-500" },
    { name: "Lima (Estándar)", from: "from-lime-500", to: "to-lime-500", preview: "bg-lime-500" },
    { name: "Celeste (Estándar)", from: "from-sky-400", to: "to-sky-400", preview: "bg-sky-400" },
    { name: "Ámbar (Estándar)", from: "from-amber-800", to: "to-amber-800", preview: "bg-amber-800" },
    { name: "Turquesa (Estándar)", from: "from-teal-400", to: "to-teal-400", preview: "bg-teal-400" },

    // Custom Colors from globals.css (ensure these are defined in your tailwind.config.js)
    { name: "Azul Claro (Custom)", from: "from-light-blue", to: "to-light-blue", preview: "bg-light-blue" },
    { name: "Azul Claro Oscuro (Custom)", from: "from-dark-light-blue", to: "to-dark-light-blue", preview: "bg-dark-light-blue" },
    { name: "Verde Claro (Custom)", from: "from-light-green", to: "to-light-green", preview: "bg-light-green" },
    { name: "Verde Claro Oscuro (Custom)", from: "from-dark-light-green", to: "to-dark-light-green", preview: "bg-dark-light-green" },
    { name: "Naranja Claro (Custom)", from: "from-light-orange", to: "to-light-orange", preview: "bg-light-orange" },
    { name: "Naranja Claro Oscuro (Custom)", from: "from-dark-light-orange", to: "to-dark-light-orange", preview: "bg-dark-light-orange" },
    { name: "Azul Principal (Custom)", from: "from-blue", to: "to-blue", preview: "bg-blue" },
    { name: "Azul Oscuro Principal (Custom)", from: "from-dark-blue", to: "to-dark-blue", preview: "bg-dark-blue" },
    { name: "Guinda (Custom)", from: "from-guinda", to: "to-guinda", preview: "bg-guinda" },
    { name: "Vino (Custom)", from: "from-vino", to: "to-vino", preview: "bg-vino" },
];

const SECTION_TITLE_COLOR_OPTIONS = BASE_COLORS.map(color => ({
    name: color.name,
    bgColorClass: color.preview, // Use the 'preview' class for the solid background
    gradientToClass: color.to,   // Use the 'to' class for the gradient part
}));

interface SectionTitleColorPickerProps {
    value?: { bgColor: string; gradientTo: string };
    onChange?: (value: { bgColor: string; gradientTo: string }) => void;
    idPrefix?: string;
}

export default function SectionTitleColorPicker({ value, onChange, idPrefix = "section-title-color" }: SectionTitleColorPickerProps) {
    const [bgColor, setBgColor] = useState(value?.bgColor || SECTION_TITLE_COLOR_OPTIONS[0].bgColorClass);
    const [gradientTo, setGradientTo] = useState(value?.gradientTo || SECTION_TITLE_COLOR_OPTIONS[0].gradientToClass);

    useEffect(() => {
        if (value) {
            setBgColor(value.bgColor);
            setGradientTo(value.gradientTo);
        }
    }, [value]);

    const handleBgColorChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newBgColor = e.target.value;
        setBgColor(newBgColor);
        onChange?.({ bgColor: newBgColor, gradientTo });
    };

    const handleGradientToChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newGradientTo = e.target.value;
        setGradientTo(newGradientTo);
        onChange?.({ bgColor, gradientTo: newGradientTo });
    };

    return (
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-end">
             <div className="flex-1 w-full sm:w-auto">
                <label htmlFor={`${idPrefix}-gradient`} className="block text-xs font-medium text-gray-600 mb-1">Desde</label>
                <select
                    id={`${idPrefix}-gradient`}
                    className="block w-full text-sm border-gray-300 rounded px-2 py-1 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    value={gradientTo}
                    onChange={handleGradientToChange}
                >
                    {SECTION_TITLE_COLOR_OPTIONS.map((color) => (
                        <option key={`grad-${color.gradientToClass}`} value={color.gradientToClass}>
                            {color.name}
                        </option>
                    ))}
                </select>
            </div>

            <div className="flex-1 w-full sm:w-auto">
                <label htmlFor={`${idPrefix}-bg`} className="block text-xs font-medium text-gray-600 mb-1">Hasta</label>
                <select
                    id={`${idPrefix}-bg`}
                    className="block w-full text-sm border-gray-300 rounded px-2 py-1 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    value={bgColor}
                    onChange={handleBgColorChange}
                >
                    {SECTION_TITLE_COLOR_OPTIONS.map((color) => (
                        <option key={`bg-${color.bgColorClass}`} value={color.bgColorClass}>
                            {color.name}
                        </option>
                    ))}
                </select>
            </div>
           

            {/* Preview mimicking SectionTitle */}
            <div className="mt-2 sm:mt-0">
                <label className="block text-xs font-medium text-gray-600 mb-1 text-center">Vista Previa</label>
                <div className="flex flex-row w-48 h-12 rounded-lg overflow-hidden border border-gray-300 shadow">
                    <div className={`w-2/5 h-full bg-gradient-to-r from-white/10 ${gradientTo}`}></div>
                    <div className={`w-3/5 h-full flex items-center justify-center ${bgColor}`}>
                        <span className="text-xs text-white/70">Título</span>
                    </div>
                </div>
            </div>
        </div>
    );
}