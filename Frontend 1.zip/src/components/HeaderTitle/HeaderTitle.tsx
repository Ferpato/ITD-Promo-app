import React from "react";

interface HeaderTitleProps {
    children?: React.ReactNode;
}
export default function HeaderTitle({ children }: HeaderTitleProps) {
    return (
        <div className="pl-10 pb-4 lg:p-10 flex items-center lg:ml-100 font-semibold">
            <p className="text-2xl lg:text-6xl font-bold text-left lg:leading-18">{children}</p>
        </div>
    );
}