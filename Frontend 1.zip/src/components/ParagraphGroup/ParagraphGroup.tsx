interface ParagraphGroupProps {
    children?: React.ReactNode;
    hasCarousel?: boolean;
}

export default function ParagraphGroup({ children, hasCarousel }: ParagraphGroupProps) {
    return (
        <div className={`flex flex-row flex-wrap items-start gap-x-20 *:flex-1  ${
            hasCarousel ?? false ? "mr-10" : "mr-10 lg:mr-80"}`}>
            {children}
        </div>
    );
}