interface CommentProps {
    children?: React.ReactNode;
    title: string;
    gradientFrom: string;
    gradientTo: string;
}

export default function Comment({ children, title, gradientFrom, gradientTo }: CommentProps) {
    return (
        <div className="flex flex-col items-center h-full w-full min-w-fit min-h-fit rounded-[5rem] p-6 lg:p-10 rounded-bl-none bg-white drop-shadow-xl">
            <div className={"text-xl lg:text-2xl font-semibold text-white p-2 w-full text-center rounded-full" +
                " bg-gradient-to-r " + gradientFrom + " " + gradientTo
            }>
                {title}
            </div>
            <div className="flex items-center justify-center m-auto p-1 lg:p-5 lg:text-xl font-medium italic">
                {children}
            </div>
        </div>
    );
}