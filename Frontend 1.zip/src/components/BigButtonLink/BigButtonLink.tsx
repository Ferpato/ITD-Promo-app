"use client";

import React from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";

interface BigButtonLinkProps {
    text: string;
    route: string;
    icon: string;
    gradientFrom: string;
    gradientTo: string;
}

export default function BigButtonLink({ text, route, icon, gradientFrom, gradientTo }: BigButtonLinkProps) {
    const router = useRouter();
    return (
        <div className={
            "rounded-[2.2rem] text-white font-semibold text-base lg:text-2xl p-8 lg:p-14 lg:pt-12 lg:pb-12 flex justify-between cursor-pointer" +
            " bg-gradient-to-r " + gradientFrom + " " + gradientTo
        }
            onClick={() => {
                if (route.startsWith('http')) {
                    window.open(route, '_blank');
                } else {
                    router.push(route);
                }
            }
            }>
            {text}
            <Image src={icon} alt="icono" className="w-6 lg:w-8" height={1} width={1} />
        </div >
    );

}