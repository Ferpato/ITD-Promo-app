import React from "react";
import Image from "next/image";
import ButtonLink from "../ButtonLink/ButtonLink";

interface ButtonConfig {
    text: string;
    route: string;
    icon: string;
    gradientFrom: string;
    gradientTo: string;
    underlined?: boolean;
}

interface FooterSectionProps {
    text: string;
    buttonConfigs: ButtonConfig[];
}

export default function FooterSection({ text, buttonConfigs }: FooterSectionProps) {
    return (
        <div className="flex flex-wrap flex-col items-center lg:items-start -ml-1 w-fit md:lg:last:whitespace-nowrap">
            <div className="flex justify-start gap-5 items-center lg:mb-0 mb-10">
                <div className="relative w-20 h-20 self-stretch">
                    <Image src={"/assets/svg/more-vertical.svg"} alt={"icono"} fill objectFit="contain"></Image>
                </div>
                <p className="font-semibold text-3xl">{text}</p>
            </div>
            <div className="flex flex-col lg:flex-row flex-wrap items-start gap-5
            *:not-first:w-full lg:*:not-first:w-84">
                <div className="relative w-20 h-20 lg:mt-14 -ml-7 lg:-ml-0 order-last lg:order-first ">
                    <Image src={"/assets/svg/arrow-down.svg"} alt={"icono"} fill objectFit="contain"></Image>
                </div>
                {buttonConfigs.map((config, index) => (
                    <ButtonLink
                        key={index}
                        text={config.text}
                        route={config.route}
                        icon={config.icon}
                        gradientFrom={config.gradientFrom}
                        gradientTo={config.gradientTo}
                        underlined={config.underlined ?? false} ></ButtonLink>
                ))}
            </div>
        </div>
    );
}