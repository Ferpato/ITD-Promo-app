import Image from "next/image";


export default function PageLogo() {
    return (
        <div className="lg:hidden flex flex-row p-10 items-center justify-center gap-2">
            <div className="relative w-16 h-16 bg-white rounded-3xl">
                <Image className="p-1" src="/assets/img/TecNM-logo.png" alt="TecNM logo" fill objectFit="contain" />
            </div>
            <p className="font-semibold text-2xl text-left">Tecnológico<br />Nacional de México</p>
        </div>
    );
}