import React from "react";
import Image from "next/image";
import ParagraphTitle from "../ParagraphTitle/ParagraphTitle";

interface ParagraphProps {
    children?: React.ReactNode;
    title: string;
    // text: string | undefined;
    icon: string | undefined;
    gradientFrom: string;
    gradientTo: string;
    lineDecoration?: boolean;
    overLined?: boolean;
}

export default function Paragraph({ children, title, icon,
    gradientFrom, gradientTo, lineDecoration, overLined }: ParagraphProps) {
    return (        <div className={"flex gap-20 items-center"}>
            <div>
                <ParagraphTitle title={title} gradientFrom={gradientFrom} gradientTo={gradientTo}></ParagraphTitle>
                {(overLined ?? false) && <div className={"absolute w-full h-[5.45rem] -mt-22 ml-10 hidden lg:block " +
                    " bg-gradient-to-r  " + gradientFrom + " " + "to-black/20"}></div>}
                <div className="flex items-center gap-4">
                    {(lineDecoration ?? false) && (
                    <div className="relative w-20 h-40 ml-8 hidden lg:block">
                            <Image
                                src="/assets/svg/line.svg"
                                alt="line icon"
                                fill
                                objectFit="contain"
                            />
                        </div>)}
                    <p className="text-black text-lg lg:text-2xl p-15 pr-0">{children}</p>
                </div>
            </div>
            {icon && (
                <div className="relative w-50 h-50 flex-shrink-0 hidden sm:block">
                    <Image
                        src={icon}
                        alt="icono"
                        fill
                        objectFit="contain"
                    />
                </div>
            )}
        </div>
    );
}