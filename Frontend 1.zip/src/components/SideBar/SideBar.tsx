import React, { } from "react"; // Added useEffect
import { useRouter } from "next/navigation";
import { NaviBarClass } from "@/interfaces/NaviBar/NaviBar-class";
import { SideBarClass } from "@/interfaces/SideBar/SideBar-class";

export default function SideBar({ selectedIndex = 0 }: { selectedIndex?: number }) {
    const router = useRouter();

    return (
        <>
            {/* Desktop Sidebar */}
            <aside className="fixed top-0 left-0 h-full w-64 bg-gradient-to-b from-blue-700 to-blue-900 shadow-2xl flex-col justify-between z-50 hidden md:flex">
                <div className="flex flex-col gap-2 mt-10">
                    {/* Static Dashboard element at the top */}
                    <div
                        className={
                            `group flex items-center px-6 py-4 transition-colors relative cursor-pointer ` +
                            (selectedIndex === 0 ? "bg-blue-800" : "hover:bg-blue-800")
                        }
                        onClick={() => router.push(`/admin/dashboard`)}
                    >
                        {/* Selected bar */}
                        <div className={`absolute left-0 top-2 bottom-2 w-2 rounded-r-lg transition-all ${selectedIndex === 0 ? "bg-white" : "bg-transparent"}`}></div>
                        <span className="flex-1 text-white text-lg font-semibold select-none ml-2">Dashboard</span>
                    </div>                    {/* Dynamic elements */}
                    {NaviBarClass.titles.map((title, idx) => (
                        <div
                            key={`desktop-${idx}`}
                            className={
                                `group flex items-center px-6 py-4 transition-colors relative cursor-pointer ` +
                                (selectedIndex === idx + 1 ? "bg-blue-800" : "hover:bg-blue-800")
                            }
                            onClick={() => router.push(`/admin/dashboard${SideBarClass.routes[idx]}`)}
                        >
                            {/* Selected bar */}
                            <div className={`absolute left-0 top-2 bottom-2 w-2 rounded-r-lg transition-all ${selectedIndex === idx + 1 ? "bg-white" : "bg-transparent"}`}></div>
                            <span className="flex-1 text-white text-lg font-semibold select-none ml-2">
                                {title}
                            </span>
                        </div>
                    ))}                </div>
            </aside>

            {/* Mobile Bottom Navigation Bar */}
            <nav className="fixed bottom-0 left-0 right-0 h-16 bg-blue-800 shadow-lg flex justify-around items-stretch z-50 md:hidden border-t border-blue-700 ">
                {/* Dashboard Item */}
                <button
                    onClick={() => router.push(`/admin/dashboard`)}
                    className={`flex flex-col items-center justify-center p-1 rounded-none transition-colors h-full flex-1 text-center focus:outline-none ${selectedIndex === 0 ? "bg-blue-900" : "hover:bg-blue-700"}`}
                >
                    <span className={`text-white text-xs break-words ${selectedIndex === 0 ? "font-bold" : ""}`}>Dashboard</span>
                </button>

                {/* Dynamic Items */}
                {NaviBarClass.titles.map((title, idx) => (
                    <button
                        key={`mobile-${idx}`}
                        onClick={() => router.push(`/admin/dashboard${SideBarClass.routes[idx]}`)}
                        className={`flex flex-col items-center justify-center p-1 rounded-none transition-colors h-full flex-1 text-center focus:outline-none ${selectedIndex === idx + 1 ? "bg-blue-900" : "hover:bg-blue-700"}`}
                    >
                        <span className={`text-white text-xs break-words leading-tight ${selectedIndex === idx + 1 ? "font-bold" : ""}`}>
                            {title}
                        </span>
                    </button>
                ))}
            </nav>
        </>
    );
}
