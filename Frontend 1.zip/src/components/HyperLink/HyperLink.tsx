"use client";

import React from "react";
import Image from "next/image";

interface HyperLinkProps {
    link: string;
}

export default function HyperLink({ link }: HyperLinkProps) {

    return (
        <div className="flex justify-center gap-2 fixed bottom-23 left-14 right-14 xl:bottom-2 xl:left-8 xl:right-auto p-2 px-4 rounded-2xl
        lg:text-xl text-[0.6rem] underline text-black bg-[#EFEDED] cursor-pointer z-100"
            onClick={() => window.open(link, "_blank")}>
            <Image className="w-4 lg:w-6" src="/assets/svg/globe.svg" alt="globe icon" height={1} width={1}/>
            {link}
        </div>
    );
}