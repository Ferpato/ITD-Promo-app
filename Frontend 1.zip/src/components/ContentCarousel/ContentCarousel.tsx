"use client";

import React, { useState } from "react";
import Image from "next/image";

interface ContentCarouselProps {
    items: string[];
}

export default function ContentCarousel({ items }: ContentCarouselProps) {
    const [current, setCurrent] = useState(0);
    const [isFullScreen, setIsFullScreen] = useState(false);
    const count = items.length;
    const countToShow = Math.min(3, count);

    // Normal (non-fullscreen) cycling (top item clicks)
    const handleCycle = () => {
        if (count > 0) {
            setCurrent((prev) => (prev + 1) % count);
        }
    };

    // Cycle backward for non-fullscreen version
    const handlePrev = () => {
        if (count > 0) {
            setCurrent((prev) => (prev - 1 + count) % count);
        }
    };

    // In full screen modal, cycle backward
    const handleModalPrev = () => {
        if (count > 0) {
            setCurrent((prev) => (prev - 1 + count) % count);
        }
    };

    // In full screen modal, cycle forward
    const handleModalNext = () => {
        if (count > 0) {
            setCurrent((prev) => (prev + 1) % count);
        }
    };

    // Render one media item (either an image or a YouTube iframe)
    const renderMedia = (item: string, extraClasses = "") => {
        const isYoutube = item.includes("youtube") || item.includes("youtu.be");
        return isYoutube ? (
            <iframe
                className={`w-full h-full border-4 border-black rounded-[2.5rem] ${extraClasses}`}
                src={item}
                title="YouTube Video"
                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
            ></iframe>
        ) : (
            <Image
                className={`border-4 border-black rounded-[2.5rem] ${extraClasses}`}
                src={item}
                alt={`Carousel media`}
                fill
                objectFit="contain"
            />
        );
    };

    return (
        <>
            {/* Main carousel container */}
            <div className="relative w-full min-w-[25rem] items-center flex gap-35 aspect-video">
                {/* For larger screens, show the left arrow button as before */}
                <button onClick={handlePrev} className="hidden lg:block cursor-pointer">
                    <Image
                        src="/assets/svg/direction-left.svg"
                        alt="Previous"
                        width={48}
                        height={48}
                    />
                </button>
                {/* For small screens, show a full screen button instead */}
                <button
                    onClick={() => setIsFullScreen(true)}
                    className="lg:hidden cursor-pointer"
                >
                    {/* Replace with your custom full screen icon */}
                    <Image
                        src="/assets/svg/fullscreen.svg"
                        alt="Full Screen"
                        width={64}
                        height={64}
                    />
                </button>
                <div className="relative w-full h-full">
                    {Array.from({ length: countToShow }, (_, i) => {
                        const idx = (current + i) % count;
                        const currentItem = items[idx];
                        // Offset each subsequent item
                        const offset = i * -60;
                        // Top item clickable for cycling if not in fullscreen
                        const zIndex = 100 - i;
                        return (
                            <div
                                key={idx}
                                className="bg-cyan-800 rounded-[2.5rem]"
                                onClick={i === 0 && !isFullScreen ? handleCycle : undefined}
                                style={{
                                    position: "absolute",
                                    top: 0,
                                    left: `${offset}px`,
                                    zIndex,
                                    width: "100%",
                                    height: "100%",
                                    cursor: i === 0 && !isFullScreen ? "pointer" : "default",
                                }}
                            >
                                {renderMedia(currentItem)}
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* Full screen modal for mobile */}
            {isFullScreen && (
                <div className="fixed inset-0 z-200 bg-black flex flex-col items-center justify-center">
                    {/* Close button in top-right corner */}
                    <button
                        onClick={() => setIsFullScreen(false)}
                        className="absolute top-4 right-4 text-white text-4xl z-50 cursor-pointer"
                    >
                        &times;
                    </button>
                    {/* Centered media */}
                    <div className="relative w-full h-full flex items-center justify-center">
                        <div className="relative w-full h-full max-w-xl max-h-[80vh]">
                            {renderMedia(items[current], "rounded-[2.5rem]")}
                        </div>
                    </div>
                    {/* Arrow buttons below the content */}
                    <div className="flex justify-center items-center gap-10 mt-4">
                        <button onClick={handleModalPrev} className="p-2 cursor-pointer">
                            <Image
                                src="/assets/svg/arrow-left-white.svg"
                                alt="Previous"
                                width={48}
                                height={48}
                            />
                        </button>
                        <button onClick={handleModalNext} className="p-2 cursor-pointer">
                            <Image
                                className=""
                                src="/assets/svg/arrow-right-white.svg"
                                alt="Next"
                                width={48}
                                height={48}
                            />
                        </button>
                    </div>
                </div>
            )}
        </>
    );
}