import Image from "next/image";

interface CommentSectionProps {
    children?: React.ReactNode;
}

export default function CommentSection({ children }: CommentSectionProps) {
    return (
        <div className="flex flex-row *:not-first:items-center lg:gap-10 -ml-4 lg:-ml-0 m-10 lg:mr-90 pl-10">
            <div className="hidden lg:flex flex-col">
                <div className="relative w-20 h-20 self-stretch mx-auto">
                    <Image src={"/assets/svg/more-vertical.svg"} alt={"icono"} fill></Image>
                </div>
                <div className="relative m-auto w-25 h-60 self-stretch">
                    <Image src={"/assets/svg/line.svg"} alt={"icono"} fill></Image>
                </div>
           </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 w-full h-full">
                {children}
            </div>
        </div>
    );
}