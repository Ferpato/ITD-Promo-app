/* eslint-disable @typescript-eslint/no-explicit-any */
"use client"; // ¡Importante: Esto lo convierte en un Client Component!

import NaviBar from "@/components/NaviBar/NaviBar";
import { NaviBarClass } from "@/interfaces/NaviBar/NaviBar-class";
import ButtonLink from "@/components/ButtonLink/ButtonLink";
import HyperLink from "@/components/HyperLink/HyperLink";
import BigButtonLink from "@/components/BigButtonLink/BigButtonLink";
import HeaderTitle from "@/components/HeaderTitle/HeaderTitle";
import PageLogo from "@/components/PageLogo/PageLogo";

import React, { useState, useEffect, useCallback } from "react";

// URL base de tu backend NestJS
const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:3001';

// Interfaz para la configuración principal (debe coincidir con la entidad/DTO del backend)
interface MainConfigData {
    Titulo: string;
    TextoBotonSuperior: string;
    LinkBotonSuperior: string | null;
    Color1BotonSuperior: string;
    Color2BotonSuperior: string;
    TextoBotonInferior: string;
    LinkBotonInferior: string | null;
    Color1BotonInferior: string;
    Color2BotonInferior: string;
    subdominio: string; // Incluimos subdominio para consistencia con la respuesta del backend
}

// Función para obtener el subdominio desde la URL del navegador
const getSubdomainFromWindow = () => {
    if (typeof window === 'undefined') {
        return 'default'; // Por si se renderiza en el servidor o no hay ventana
    }
    const hostname = window.location.hostname;
    const parts = hostname.split('.');
    let detectedSubdomain = 'default';

    // Lógica para detectar subdominio en localhost o dominios reales
    if (parts.length === 2 && parts[1] === 'localhost' && parts[0] !== 'www') {
        detectedSubdomain = parts[0];
    } else if (parts.length > 2 && parts[0] !== 'www') {
        detectedSubdomain = parts[0];
    }
    return detectedSubdomain;
};

export default function Home() {
    // Estado para almacenar la configuración de la página principal
    const [mainConfig, setMainConfig] = useState<MainConfigData>({
        // Valores por defecto iniciales (los mismos que el backend devolvería si no encuentra nada)
        Titulo: '¿Pronto a la universidad?',
        TextoBotonSuperior: 'Quiero ser guinda',
        LinkBotonSuperior: 'https://www.itdurango.edu.mx/aspirantes/',
        Color1BotonSuperior: 'from-guinda',
        Color2BotonSuperior: 'to-vino',
        TextoBotonInferior: 'Todas las novedades aquí',
        LinkBotonInferior: 'https://www.facebook.com/ITDgoOficial',
        Color1BotonInferior: 'from-guinda',
        Color2BotonInferior: 'to-vino',
        subdominio: getSubdomainFromWindow(), // Asigna el subdominio detectado al inicio
    });
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    // Función para cargar la configuración
    const loadMainConfig = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        const currentSubdomain = getSubdomainFromWindow();

        try {
            const response = await fetch(`${API_BASE_URL}/admin/dashboard/inicio`, {
                headers: {
                    'X-Subdomain': currentSubdomain,
                },
                cache: 'no-store', 
            });

            if (!response.ok) {
                const errorData = await response.json();
                console.error('Error al cargar la configuración:', errorData);
                throw new Error(`Failed to load config: ${response.status} ${response.statusText}`);
            }

            const data: MainConfigData = await response.json();
            setMainConfig(data);

        } catch (err: any) {
            console.error('Error fetching main config:', err);
            setError(`No se pudo cargar la configuración de la página principal: ${err.message}`);
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        loadMainConfig();
    }, [loadMainConfig]);


    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <p>Cargando configuración de la página...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex flex-col justify-center items-center h-screen text-red-600">
                <p>{error}</p>
                <button
                    onClick={loadMainConfig}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700"
                >
                    Reintentar
                </button>
            </div>
        );
    }

    return (
        <div className="bg-[url('/assets/svg/bg/bg-mob-inicio.svg')] md:lg:bg-[url('/assets/svg/bg/bg-desk-inicio.svg')]
    bg-size-[width:100%] min-h-screen overflow-y-hidden pb-32 md:pb-0">
         <PageLogo />
            <NaviBar selectedIndex={0} titles={NaviBarClass.titles} routes={NaviBarClass.routes} icons={NaviBarClass.icons} />
            <div className="grid lg:justify-end items-center lg:pr-36 px-16 lg:*:*:first:text-6xl lg:*:m-6 lg:max-w-[70%] lg:ml-auto">
                {/* Título dinámico */}
                <HeaderTitle>{mainConfig.Titulo}</HeaderTitle>

                <div className="flex flex-col lg:flex-row *:flex-1 gap-5 my-12 lg:my-0">
                    {/* Este ButtonLink parece ser estático */}
                    <ButtonLink text="Tomar el tour" route="/oferta" icon="/assets/svg/arrow-right.svg" gradientFrom="from-blue" gradientTo="to-dark-blue" underlined />
                    
                    {/* ButtonLink superior dinámico */}
                    {mainConfig.TextoBotonSuperior && (
                        <ButtonLink
                            text={mainConfig.TextoBotonSuperior}
                            route={mainConfig.LinkBotonSuperior || '#'}
                            icon="/assets/svg/external-link.svg"
                            gradientFrom={mainConfig.Color1BotonSuperior}
                            gradientTo={mainConfig.Color2BotonSuperior}
                        />
                    )}
                </div>
                
                {/* BigButtonLink inferior dinámico */}
                {mainConfig.TextoBotonInferior && (
                    <BigButtonLink
                        text={mainConfig.TextoBotonInferior}
                        route={mainConfig.LinkBotonInferior || '#'}
                        icon="/assets/svg/external-link.svg"
                        gradientFrom={mainConfig.Color1BotonInferior}
                        gradientTo={mainConfig.Color2BotonInferior}
                    />
                )}
            </div>
            <HyperLink link="https://www.itdurango.edu.mx/" />
        </div>
    );
}