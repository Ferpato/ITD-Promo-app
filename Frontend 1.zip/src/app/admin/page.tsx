/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";

// Define la URL base de tu backend de NestJS
const API_BASE_URL = "http://localhost:3001"; // Asegúrate de que este sea el puerto correcto de tu backend

export default function AdminLogin() { // Renombré a AdminLogin para mayor claridad
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const router = useRouter();

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError("");

        try {
            const response = await fetch(`${API_BASE_URL}/auth/login`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ usuario: username, contrasena: password }),
            });

            if (!response.ok) {
                // Si la respuesta no es 2xx, leer el mensaje de error del backend
                const errorData = await response.json();
                throw new Error(errorData.message || "Error al iniciar sesión.");
            }

            const data = await response.json();
            // Suponiendo que tu backend devuelve { accessToken: "...", message: "..." }
            const token = data.accessToken;

            // Almacenar el token en localStorage (o cookies HTTP-only para mayor seguridad)
            localStorage.setItem("jwt_token", token);
            
            // Redirigir al dashboard de administración
            router.push("/admin/dashboard");

        } catch (err: any) { // Usamos 'any' por si el error no es una instancia de Error
            setError(err.message || "Ocurrió un error inesperado. Intenta de nuevo.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4 ">
            <form onSubmit={handleLogin} className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg w-full max-w-sm flex flex-col gap-6">
                <h2 className="text-2xl font-bold text-center text-blue-900">Login</h2>
                <div>
                    <label className="block text-gray-700 mb-2" htmlFor="username">Usuario</label>
                    <input
                        id="username"
                        type="text"
                        placeholder="Usuario"
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                        value={username}
                        onChange={e => setUsername(e.target.value)}
                        autoComplete="username"
                    />
                </div>
                <div>
                    <label className="block text-gray-700 mb-2" htmlFor="password">Contraseña</label>
                    <input
                        id="password"
                        type="password"
                        placeholder="••••••••"
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        autoComplete="current-password"
                    />
                </div>
                {error && <div className="text-red-500 text-sm text-center">{error}</div>}
                <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-lg transition-colors duration-200 disabled:opacity-50"
                    disabled={loading}
                >
                    {loading ? "Ingresando..." : "Entrar"}
                </button>
            </form>
        </div>
    );
}