/* eslint-disable react/no-unescaped-entities */
/* eslint-disable @typescript-eslint/no-explicit-any */
// src/app/admin/dashboard/proyectos/page.tsx
"use client";

import SideBar from "@/components/SideBar/SideBar";
import SectionTitleColorPicker from "@/components/SectionTitleColorPicker/SectionTitleColorPicker";
import React, { useState, useEffect, useCallback, ChangeEvent, FormEvent, useRef } from "react";
import Image from 'next/image';
import { useRouter } from "next/navigation";

// Helper para generar IDs temporales para nuevos elementos en el frontend
const usedIds = new Set<string>();
const generateId = () => {
  let id: string;
  do {
    id = `temp-${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;
  } while (usedIds.has(id));
  usedIds.add(id);
  return id;
};

// --- Data Structures for the CMS Frontend Form ---
interface CarouselMediaItemFormData {
    id: string;
    url: string;
}

interface CommentFormData {
    title: string;
    content: string;
    gradientFrom: string;
    gradientTo: string;
}

interface CarouselFormData {
    items: CarouselMediaItemFormData[];
}

type CommentSectionItemType = 'comment' | 'carousel';

interface CommentSectionItemFormData {
    id: string;
    type: CommentSectionItemType;
    commentData?: CommentFormData;
    carouselData?: CarouselFormData;
}

interface SectionFormData {
    id: string;
    text: string;
    icon: string | null;
    color1: string;
    color2: string;
    subdominio?: string;
    items: CommentSectionItemFormData[];
}

interface ProyectosPageFormData {
    headerTitle: string;
    sections: SectionFormData[];
}

// --- Data Structures for the Backend DTOs ---
interface BackendCarouselMediaItemDto {
    url: string;
}

interface BackendCommentDto {
    title: string;
    content: string;
    gradientFrom: string;
    gradientTo: string;
}

interface BackendCarouselDto {
    items: BackendCarouselMediaItemDto[];
}

interface BackendCommentSectionItemDto {
    id?: string;
    type: 'comment' | 'carousel';
    commentData?: BackendCommentDto;
    carouselData?: BackendCarouselDto;
}

interface BackendSectionDto {
    id?: string;
    text: string;
    icon: string | null;
    color1: string;
    color2: string;
    subdominio?: string;
    items: BackendCommentSectionItemDto[];
}

interface BackendProyectosPageDto {
    headerTitle: string;
    sections: BackendSectionDto[];
}

const API_BASE_URL = "http://localhost:3001";

const getSubdomainFromWindow = (): string => {
    if (typeof window !== 'undefined') {
        const hostname = window.location.hostname;
        const parts = hostname.split('.');
        if (parts.length > 2) {
            if (parts[0] === 'www') {
                return parts[1];
            }
            return parts[0];
        }
    }
    return 'default';
};

const isValidImageUrlForNextImage = (url: string | null): boolean => {
    if (!url || typeof url !== 'string' || url.trim() === '') {
        return false;
    }
    return url.startsWith('/') || url.startsWith('http://') || url.startsWith('https://');
};

const ProyectosPage: React.FC = () => {
     const router = useRouter();
    const [formData, setFormData] = useState<ProyectosPageFormData>({
        headerTitle: "",
        sections: [],
    });
     useEffect(() => {
        const token = localStorage.getItem('jwt_token');
        if (!token) {
            console.warn("OfertaDashboardPage: No JWT token found. Redirecting to login.");
            router.push('/admin');
        } else {
            console.log("OfertaDashboardPage: Token found. Proceeding with data loading.");
        }
    }, [router]);
    const [originalFormData, setOriginalFormData] = useState<ProyectosPageFormData | null>(null);
    const [isSaving, setIsSaving] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const isAddingRef = useRef(false);

    const currentSubdomain = getSubdomainFromWindow();
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const isDirty = originalFormData ? JSON.stringify(formData) !== JSON.stringify(originalFormData) : false;

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            setError(null);
            try {
                const response = await fetch(`${API_BASE_URL}/admin/dashboard/proyectos`, {
                    headers: {
                        'X-Subdomain': currentSubdomain,
                    },
                });
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();

                const processedData: ProyectosPageFormData = {
                    headerTitle: data.headerTitle,
                    sections: data.sections.map((sec: BackendSectionDto) => {
                        const processedSection: SectionFormData = {
                            id: String(sec.id),
                            text: sec.text,
                            icon: sec.icon,
                            color1: sec.color1, 
                            color2: sec.color2,   
                            subdominio: sec.subdominio,
                            items: sec.items.map((item: BackendCommentSectionItemDto) => {
                                const processedItem: CommentSectionItemFormData = {
                                    id: String(item.id),
                                    type: item.type,
                                };
                                if (processedItem.type === 'comment' && item.commentData) {
                                    processedItem.commentData = {
                                        title: item.commentData.title,
                                        content: item.commentData.content,
                                        gradientFrom: item.commentData.gradientFrom,
                                        gradientTo: item.commentData.gradientTo,
                                    };
                                }
                                if (processedItem.type === 'carousel' && item.carouselData) {
                                    processedItem.carouselData = {
                                        items: item.carouselData.items.map(mediaItem => ({
                                            id: generateId(),
                                            url: mediaItem.url,
                                        })),
                                    };
                                }
                                return processedItem;
                            })
                        };
                        return processedSection;
                    })
                };

                setFormData(processedData);
                setOriginalFormData(processedData);
            } catch (err: any) {
                console.error("Error fetching data:", err);
                setError("No se pudieron cargar los datos de la página. Intente de nuevo más tarde.");
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, [currentSubdomain]);

    // --- Manejadores de cambios ---
    const handleHeaderTitleChange = useCallback((e: ChangeEvent<HTMLInputElement>) => {
        setFormData(prev => ({ ...prev, headerTitle: e.target.value }));
    }, []);

    const handleSectionTextOrIconChange = useCallback(
        (index: number, field: keyof SectionFormData, value: string | null) => {
            setFormData(prev => {
                const newSections = [...prev.sections];
                if (field === 'text' || field === 'icon' || field === 'subdominio') {
                    (newSections[index] as any)[field] = value;
                }
                return { ...prev, sections: newSections };
            });
        },
        [],
    );

    const handleSectionColorChange = useCallback(
        (index: number, value: { bgColor: string; gradientTo: string }) => {
            setFormData(prev => {
                const newSections = [...prev.sections];
                newSections[index].color1 = value.bgColor;
                newSections[index].color2 = value.gradientTo;
                return { ...prev, sections: newSections };
            });
        },
        [],
    );

    const handleCommentTextChange = useCallback(
        (sectionIndex: number, itemIndex: number, field: 'title' | 'content', value: string) => {
            setFormData(prev => {
                const newSections = [...prev.sections];
                const item = newSections[sectionIndex].items[itemIndex];
                if (item.type === 'comment' && item.commentData) {
                    item.commentData[field] = value;
                }
                return { ...prev, sections: newSections };
            });
        },
        [],
    );

    const handleCommentGradientChange = useCallback(
        (sectionIndex: number, itemIndex: number, field: 'gradientFrom' | 'gradientTo', value: string) => {
            setFormData(prev => {
                const newSections = [...prev.sections];
                const item = newSections[sectionIndex].items[itemIndex];
                if (item.type === 'comment' && item.commentData) {
                    if (field === 'gradientFrom') {
                        item.commentData.gradientFrom = value;
                    } else {
                        item.commentData.gradientTo = value;
                    }
                }
                return { ...prev, sections: newSections };
            });
        },
        [],
    );

    const handleCarouselMediaItemChange = useCallback(
        (sectionIndex: number, itemIndex: number, mediaItemIndex: number, value: string) => {
            setFormData(prev => {
                const newSections = [...prev.sections];
                const item = newSections[sectionIndex].items[itemIndex];
                if (item.type === 'carousel' && item.carouselData) {
                    const newMediaItems = [...item.carouselData.items];
                    newMediaItems[mediaItemIndex].url = value;
                    item.carouselData.items = newMediaItems;
                }
                return { ...prev, sections: newSections };
            });
        },
        [],
    );

    const handleAddSection = useCallback(() => {
        if (isAddingRef.current) return;
        isAddingRef.current = true;
        
        setFormData(prev => ({
            ...prev,
            sections: [
                ...prev.sections,
                {
                    id: generateId(),
                    text: "Nueva Sección",
                    icon: "/assets/svg/health-group.svg",
                    color1: "bg-blue-500",
                    color2: "to-blue-500",
                    subdominio: currentSubdomain,
                    items: [],
                },
            ],
        }));

        setTimeout(() => {
            isAddingRef.current = false;
        }, 0);
    }, [currentSubdomain]);

    const handleRemoveSection = useCallback((index: number) => {
        setFormData(prev => {
            const newSections = prev.sections.filter((_, i) => i !== index);
            return { ...prev, sections: newSections };
        });
    }, []);

    const handleAddSectionItem = useCallback((sectionIndex: number, type: CommentSectionItemType) => {
        if (isAddingRef.current) return;
        isAddingRef.current = true;

        setFormData(prev => {
            const newSections = [...prev.sections];
            const targetSection = newSections[sectionIndex];
            
            let newItem: CommentSectionItemFormData;
            if (type === 'comment') {
                newItem = {
                    id: generateId(),
                    type: 'comment',
                    commentData: {
                        title: "Nuevo Comentario",
                        content: "Contenido del comentario...",
                        gradientFrom: "from-fuchsia-500",
                        gradientTo: "to-red-500",
                    },
                };
            } else {
                newItem = {
                    id: generateId(),
                    type: 'carousel',
                    carouselData: {
                        items: [{ id: generateId(), url: "https://www.youtube.com/embed/dQw4w9WgXcQ?si=03SkCZ3VAwYtzTvG" }],
                    },
                };
            }
            targetSection.items.push(newItem);
            return { ...prev, sections: newSections };
        });

        setTimeout(() => {
            isAddingRef.current = false;
        }, 0);
    }, []);

    const handleRemoveSectionItem = useCallback((sectionIndex: number, itemIndex: number) => {
        setFormData(prev => {
            const newSections = [...prev.sections];
            newSections[sectionIndex].items = newSections[sectionIndex].items.filter(
                (_, i) => i !== itemIndex,
            );
            return { ...prev, sections: newSections };
        });
    }, []);

    const handleAddCarouselMediaItem = useCallback((sectionIndex: number, itemIndex: number) => {
        if (isAddingRef.current) return;
        isAddingRef.current = true;

        setFormData(prev => {
            const newSections = [...prev.sections];
            const item = newSections[sectionIndex].items[itemIndex];
            if (item.type === 'carousel' && item.carouselData) {
                item.carouselData.items.push({ id: generateId(), url: "" });
            }
            return { ...prev, sections: newSections };
        });

        setTimeout(() => {
            isAddingRef.current = false;
        }, 0);
    }, []);

    const handleRemoveCarouselMediaItem = useCallback((sectionIndex: number, itemIndex: number, mediaItemIndex: number) => {
        setFormData(prev => {
            const newSections = [...prev.sections];
            const item = newSections[sectionIndex].items[itemIndex];
            if (item.type === 'carousel' && item.carouselData) {
                item.carouselData.items = item.carouselData.items.filter((_, i) => i !== mediaItemIndex);
            }
            return { ...prev, sections: newSections };
        });
    }, []);

    // --- Guardar cambios en el backend ---
    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        setError(null);
         const currentToken = localStorage.getItem('jwt_token');
        if (!currentToken) {
        router.push('/admin/login'); // Redirigir si no hay token
        setIsSaving(false); // Detener el spinner de guardado
        return;
    }

        const dataToSend: BackendProyectosPageDto = {
            headerTitle: formData.headerTitle,
            sections: formData.sections.map(s => ({
                id: s.id.startsWith('temp-') ? undefined : s.id,
                text: s.text,
                icon: s.icon,
                color1: s.color1, 
                color2: s.color2,   
                subdominio: currentSubdomain,
                items: s.items.map(item => {
                    const baseItem: BackendCommentSectionItemDto = {
                        id: item.id.startsWith('temp-') ? undefined : item.id,
                        type: item.type,
                    };
                    if (item.type === 'comment' && item.commentData) {
                        baseItem.commentData = {
                            title: item.commentData.title,
                            content: item.commentData.content,
                            gradientFrom: item.commentData.gradientFrom,
                            gradientTo: item.commentData.gradientTo,
                        };
                    } else if (item.type === 'carousel' && item.carouselData) {
                        baseItem.carouselData = {
                            items: item.carouselData.items.map(mediaItem => ({
                                url: mediaItem.url,
                            })),
                        };
                    }
                    return baseItem;
                }),
            })),
        };

        try {
            const response = await fetch(`${API_BASE_URL}/admin/dashboard/proyectos`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Subdomain': currentSubdomain,
                     'Authorization': `Bearer ${currentToken}`,
                },
                body: JSON.stringify(dataToSend),
            });

              if (!response.ok) {
            if (response.status === 401 || response.status === 403) {
                // Token inválido o expirado, redirigir al login
                localStorage.removeItem('jwt_token'); // Limpia el token inválido
                router.push('/admin');
            }
            throw new Error(`Error al guardar los datos: ${response.statusText}`);
        }

            alert("Cambios guardados exitosamente!");

            const refreshResponse = await fetch(`${API_BASE_URL}/admin/dashboard/proyectos`, {
                headers: {
                    'X-Subdomain': currentSubdomain,
                },
            });
            if (!refreshResponse.ok) throw new Error("Failed to refresh data after save.");
            const refreshedData = await refreshResponse.json();

            const processedRefreshedData: ProyectosPageFormData = {
                headerTitle: refreshedData.headerTitle,
                sections: refreshedData.sections.map((sec: BackendSectionDto) => {
                    const processedSection: SectionFormData = {
                        id: String(sec.id),
                        text: sec.text,
                        icon: sec.icon,
                        color1: sec.color1, 
                        color2: sec.color2,   
                        subdominio: sec.subdominio,
                        items: sec.items.map((item: BackendCommentSectionItemDto) => {
                            const processedItem: CommentSectionItemFormData = {
                                id: String(item.id),
                                type: item.type,
                            };
                            if (processedItem.type === 'comment' && item.commentData) {
                                processedItem.commentData = {
                                    title: item.commentData.title,
                                    content: item.commentData.content,
                                    gradientFrom: item.commentData.gradientFrom,
                                    gradientTo: item.commentData.gradientTo,
                                };
                            }
                            if (processedItem.type === 'carousel' && item.carouselData) {
                                processedItem.carouselData = {
                                    items: item.carouselData.items.map(mediaItem => ({
                                        id: generateId(),
                                        url: mediaItem.url,
                                    })),
                                };
                            }
                            return processedItem;
                        })
                    };
                    return processedSection;
                })
            };

            setFormData(processedRefreshedData);
            setOriginalFormData(processedRefreshedData);
        } catch (err: any) {
            console.error("Error saving data:", err);
            setError(`Error al guardar: ${err.message || 'Error desconocido'}`);
            alert(`Error al guardar cambios: ${err.message || 'Error desconocido'}`);
        } finally {
            setIsSaving(false);
        }
    };

    if (isLoading) {
        return (
            <div className="flex">
                <SideBar selectedIndex={4} />
                <main className="flex-1 p-6 bg-gray-100 min-h-screen md:ml-64">
                    <h1 className="text-3xl font-bold text-gray-800 mb-6">Cargando Configuración de Proyectos...</h1>
                    <p className="text-gray-600">Por favor, espera.</p>
                </main>
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex">
                <SideBar selectedIndex={4} />
                <main className="flex-1 p-6 bg-gray-100 min-h-screen md:ml-64">
                    <h1 className="text-3xl font-bold text-red-600 mb-6">Error al Cargar</h1>
                    <p className="text-red-500">{error}</p>
                </main>
            </div>
        );
    }

    return (
        <div className="flex mb-20 md:mb-0">
            <SideBar selectedIndex={4} />

            <main className="flex-1 p-6 bg-gray-100 min-h-screen md:ml-64 overflow-y-auto">
                <h1 className="text-3xl font-bold text-gray-800 mb-6">Configuración de Página de Proyectos</h1>

                <form onSubmit={handleSubmit} className="space-y-8 p-4 sm:p-6 bg-white rounded-lg shadow-md">
                    {/* Título Principal de la Página */}
                    <section className="mb-8 p-4 border border-gray-200 rounded-lg shadow-sm">
                        <h2 className="text-2xl font-semibold text-gray-700 mb-4">Título Principal de la Página</h2>
                        <div className="flex flex-col sm:flex-row items-center gap-4">
                            <label htmlFor="headerTitle" className="block text-sm font-medium text-gray-700 sm:w-1/4">
                                Título:
                            </label>
                            <input
                                type="text"
                                id="headerTitle"
                                name="headerTitle"
                                value={formData.headerTitle}
                                onChange={handleHeaderTitleChange}
                                className="mt-1 block w-full sm:w-3/4 p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                placeholder="Ej: Nuestros Proyectos Destacados"
                            />
                        </div>
                    </section>

                    {/* Secciones de la Página */}
                    <section className="space-y-6">
                        <h2 className="text-2xl font-semibold text-gray-700 mb-4">Secciones</h2>
                        <button
                            type="button"
                            onClick={handleAddSection}
                            className="mb-4 px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors"
                        >
                            + Añadir Nueva Sección
                        </button>

                        {formData.sections.map((section, sectionIndex) => (
                            <div key={section.id} className="p-4 border border-blue-200 rounded-lg bg-blue-50 shadow-md">
                                <div className="flex justify-between items-center mb-4">
                                    <h3 className="text-xl font-semibold text-blue-700">Sección {sectionIndex + 1}</h3>
                                    <button
                                        type="button"
                                        onClick={() => handleRemoveSection(sectionIndex)}
                                        className="px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600 transition-colors"
                                    >
                                        Eliminar Sección
                                    </button>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                    {/* Texto de la Sección */}
                                    <div>
                                        <label htmlFor={`section_text_${section.id}`} className="block text-sm font-medium text-gray-700">Texto:</label>
                                        <input
                                            type="text"
                                            id={`section_text_${section.id}`}
                                            value={section.text}
                                            onChange={(e) => handleSectionTextOrIconChange(sectionIndex, 'text', e.target.value)}
                                            className="mt-1 block w-full p-2 border border-gray-300 rounded-md"
                                            placeholder="Ej: Conoce nuestros logros..."
                                        />
                                    </div>
                                    {/* Icono de la Sección */}
                                    <div>
                                        <label htmlFor={`section_icon_${section.id}`} className="block text-sm font-medium text-gray-700">URL del Icono (SVG):</label>
                                        <input
                                            type="text"
                                            id={`section_icon_${section.id}`}
                                            value={section.icon || ''}
                                            onChange={(e) => handleSectionTextOrIconChange(sectionIndex, 'icon', e.target.value || null)}
                                            className="mt-1 block w-full p-2 border border-gray-300 rounded-md"
                                            placeholder="/assets/svg/health-group.svg"
                                        />
                                        {isValidImageUrlForNextImage(section.icon) && (
                                            <Image src={section.icon as string} alt="Icono" width={32} height={32} className="mt-2" />
                                        )}
                                        {!isValidImageUrlForNextImage(section.icon) && (section.icon && section.icon.trim() !== '') && (
                                            <p className="text-xs text-red-500 mt-1">URL inválida o incompleta. Debe empezar con '/' o 'http(s)://'.</p>
                                        )}
                                        {!isValidImageUrlForNextImage(section.icon) && (!section.icon || section.icon.trim() === '') && (
                                            <p className="text-xs text-gray-500 mt-1">No hay icono para previsualizar. Escriba una URL válida.</p>
                                        )}
                                    </div>
                                </div>

                                {/* Selectores de Color de la Sección */}
                                <div className="mb-4">
                                    <h4 className="text-sm font-medium text-gray-700 mb-2">Colores del Título de la Sección:</h4>
                                    <SectionTitleColorPicker
                                        idPrefix={`section_title_colors_${section.id}`}
                                        value={{ bgColor: section.color1, gradientTo: section.color2 }}
                                        onChange={(colors) => handleSectionColorChange(sectionIndex, colors)}
                                    />
                                </div>

                                {/* Ítems de la Sección */}
                                <div className="mt-6 p-4 border border-gray-300 rounded-lg bg-white">
                                    <h4 className="text-lg font-semibold text-gray-700 mb-3">Contenido de la Sección</h4>
                                    <div className="flex gap-3 mb-4">
                                        <button
                                            type="button"
                                            onClick={() => handleAddSectionItem(sectionIndex, 'comment')}
                                            className="px-3 py-1 bg-purple-500 text-white rounded-md hover:bg-purple-600 transition-colors text-sm"
                                        >
                                            + Añadir Comentario
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => handleAddSectionItem(sectionIndex, 'carousel')}
                                            className="px-3 py-1 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors text-sm"
                                        >
                                            + Añadir Carrusel
                                        </button>
                                    </div>

                                    {section.items.map((item, itemIndex) => (
                                        <div key={item.id} className="p-3 border border-gray-200 rounded-md mb-3 last:mb-0 relative">
                                            <div className="flex justify-between items-center mb-2">
                                                <h5 className="font-medium text-gray-800">
                                                    {item.type === 'comment' ? `Comentario ${itemIndex + 1}` : `Carrusel ${itemIndex + 1}`}
                                                </h5>
                                                <button
                                                    type="button"
                                                    onClick={() => handleRemoveSectionItem(sectionIndex, itemIndex)}
                                                    className="p-1 bg-red-400 text-white rounded-full hover:bg-red-500 transition-colors w-6 h-6 flex items-center justify-center text-xs"
                                                >
                                                    X
                                                </button>
                                            </div>

                                            {item.type === 'comment' && item.commentData && (
                                                <div className="space-y-2">
                                                    <div>
                                                        <label htmlFor={`comment_title_${item.id}`} className="block text-xs sm:text-sm font-medium text-gray-700">Título:</label>
                                                        <input
                                                            type="text"
                                                            id={`comment_title_${item.id}`}
                                                            value={item.commentData.title}
                                                            onChange={(e) => handleCommentTextChange(sectionIndex, itemIndex, 'title', e.target.value)}
                                                            className="mt-1 block w-full p-1 sm:p-2 border border-gray-300 rounded-md text-sm"
                                                            placeholder="Título del Comentario"
                                                        />
                                                    </div>
                                                    <div>
                                                        <label htmlFor={`comment_content_${item.id}`} className="block text-xs sm:text-sm font-medium text-gray-700">Contenido:</label>
                                                        <textarea
                                                            id={`comment_content_${item.id}`}
                                                            value={item.commentData.content}
                                                            onChange={(e) => handleCommentTextChange(sectionIndex, itemIndex, 'content', e.target.value)}
                                                            rows={3}
                                                            className="mt-1 block w-full p-1 sm:p-2 border border-gray-300 rounded-md text-sm"
                                                            placeholder="Contenido del Comentario"
                                                        ></textarea>
                                                    </div>
                                                    
                                                    {/* Color Pickers para Comentarios */}
                                                    <div className="mb-4">
                                                        <h4 className="text-xs sm:text-sm font-medium text-gray-700 mb-2">Colores del Gradiente del Comentario:</h4>
                                                        <SectionTitleColorPicker
                                                            idPrefix={`comment_gradient_colors_${item.id}`}
                                                            value={{
                                                                bgColor: item.commentData.gradientFrom.replace('from-', 'bg-'),
                                                                gradientTo: item.commentData.gradientTo
                                                            }}
                                                            onChange={(colors) => {
                                                                handleCommentGradientChange(
                                                                    sectionIndex,
                                                                    itemIndex,
                                                                    'gradientFrom',
                                                                    colors.bgColor.replace('bg-', 'from-')
                                                                );
                                                                handleCommentGradientChange(
                                                                    sectionIndex,
                                                                    itemIndex,
                                                                    'gradientTo',
                                                                    colors.gradientTo
                                                                );
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            )}

                                            {item.type === 'carousel' && item.carouselData && (
                                                <div className="space-y-2">
                                                    <h6 className="font-medium text-gray-700 text-sm">Items del Carrusel:</h6>
                                                    <button
                                                        type="button"
                                                        onClick={() => handleAddCarouselMediaItem(sectionIndex, itemIndex)}
                                                        className="px-3 py-1 bg-sky-500 text-white rounded-md hover:bg-sky-600 transition-colors text-xs mb-2"
                                                    >
                                                        + Añadir Item de Carrusel
                                                    </button>
                                                    {item.carouselData.items.map((mediaItem, mediaItemIndex) => (
                                                        <div key={mediaItem.id} className="flex items-center gap-2 border border-gray-200 p-2 rounded-md bg-gray-50">
                                                            <label htmlFor={`carousel_media_url_${mediaItem.id}`} className="sr-only">URL del Item de Carrusel</label>
                                                            <input
                                                                type="text"
                                                                id={`carousel_media_url_${mediaItem.id}`}
                                                                value={mediaItem.url}
                                                                onChange={(e) => handleCarouselMediaItemChange(sectionIndex, itemIndex, mediaItemIndex, e.target.value)}
                                                                className="flex-grow p-1 border border-gray-300 rounded-md text-xs sm:text-sm"
                                                                placeholder="https://www.youtube.com/embed/dQw4w9WgXcQ?si=ALvXuTpUnccubgBW"
                                                            />
                                                            <button
                                                                type="button"
                                                                onClick={() => handleRemoveCarouselMediaItem(sectionIndex, itemIndex, mediaItemIndex)}
                                                                className="p-1 rounded-full bg-red-500 text-white hover:bg-red-600 text-2xs sm:text-xs"
                                                            >X</button>
                                                        </div>
                                                    ))}
                                                    {item.carouselData.items.length === 0 && <p className="text-2xs sm:text-xs text-gray-500 mt-1 sm:mt-2">No hay items en el carrusel.</p>}
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </section>

                    {/* Botón Guardar Cambios */}
                    <div className="mt-6 sm:mt-10 flex justify-end">
                        <button
                            type="submit"
                            className="px-6 sm:px-8 py-2 sm:py-3 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 text-sm sm:text-base"
                            disabled={ isSaving}
                        >
                            {isSaving ? "Guardando..." : "Guardar Cambios"}
                        </button>
                    </div>
                </form>
            </main>
        </div>
    );
}

export default ProyectosPage;