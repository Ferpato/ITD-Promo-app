
// src/app/admin/dashboard/oferta/page.tsx
"use client";

import SideBar from "@/components/SideBar/SideBar";
import ColorComboBox from "@/components/ColorComboBox/ColorComboBox";
import React, { useState, useEffect, useCallback, ChangeEvent, FormEvent } from "react";
import { useRouter } from "next/navigation";

// Helper para generar IDs temporales para nuevos párrafos en el frontend
const generateTempId = () => `temp-${Math.random().toString(36).substr(2, 9)}`;

interface ParagraphFormData {
    id: number | string; // 'id' puede ser number (de DB) o string (temporal)
    title: string;
    content: string;
    icon: string;
    gradientFrom: string;
    gradientTo: string;
    lineDecoration: boolean;
    overLined: boolean;
    subdominio?: string; // Asegurar que el subdominio también esté en el frontend si se va a enviar/mostrar
}

interface OfertaPageFormData {
    headerTitle: string;
    paragraphs: ParagraphFormData[];
}

const PREDEFINED_ICONS = [
    "/assets/svg/info-group.svg",
    "/assets/svg/health-group.svg",
    "/assets/svg/medal-group.svg",
];

const API_BASE_URL = "http://localhost:3001";

// Función para obtener el subdominio de la URL del navegador (MODIFICADO AQUÍ)
const getSubdomainFromWindow = () => {
  if (typeof window === 'undefined') {
    console.log("[Frontend getSubdomainFromWindow] Running on server (SSR), returning 'default'");
    return 'default'; // Valor predeterminado para el lado del servidor o si no se puede determinar
  }

  const hostname = window.location.hostname;
  console.log(`[Frontend getSubdomainFromWindow] Current hostname: "${hostname}"`);

  const parts = hostname.split('.');
  let detectedSubdomain = 'default';

  // Lógica para detectar subdominios en el formato "subdominio.localhost" (ej. marketing.localhost)
  // Aquí, `parts` sería ['marketing', 'localhost']. parts.length es 2.
  if (parts.length === 2 && parts[1] === 'localhost' && parts[0] !== 'www') {
      detectedSubdomain = parts[0];
      console.log(`[Frontend getSubdomainFromWindow] Detected .localhost subdomain: "${detectedSubdomain}"`);
  }
  // Lógica para subdominios en dominios reales (ej. "admin.tudominio.com")
  // o si el hostname tiene más de dos partes (ej. "sub.sub.localhost" - menos común para .localhost)
  else if (parts.length > 2 && parts[0] !== 'www') {
      detectedSubdomain = parts[0];
      console.log(`[Frontend getSubdomainFromWindow] Detected standard subdomain: "${detectedSubdomain}"`);
  }

  // **Importante:** Si tenías alguna lógica que mapeaba 'sistemas' a 'default' o algo similar,
  // asegúrate de que no esté sobrescribiendo 'marketing' aquí.
  // Ejemplo (si fuera necesario):
  // if (detectedSubdomain === 'sistemas') {
  //   detectedSubdomain = 'default';
  // }

  console.log(`[Frontend getSubdomainFromWindow] Final detected subdomain: "${detectedSubdomain}"`);
  return detectedSubdomain;
};


export default function OfertaDashboardPage() {
     const router = useRouter();
    const [formData, setFormData] = useState<OfertaPageFormData>({
        headerTitle: "",
        paragraphs: [],
    });
    const [dbParagraphs, setDbParagraphs] = useState<ParagraphFormData[]>([]);
    const [isDirty, setIsDirty] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [currentSubdomain, setCurrentSubdomain] = useState<string>('default'); // Nuevo estado para el subdominio

     useEffect(() => {
        const token = localStorage.getItem('jwt_token');
        if (!token) {
            console.warn("OfertaDashboardPage: No JWT token found. Redirecting to login.");
            router.push('/admin');
        } else {
            console.log("OfertaDashboardPage: Token found. Proceeding with data loading.");
        }
    }, [router]);
    // --- General Handlers ---
    const makeDirty = () => setIsDirty(true);

    // Ajustamos la firma para que sea más específica
    const handleInputChange = (
        e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
        index: number,
        field: 'title' | 'content' // Solo campos de texto
    ) => {
        makeDirty();
        setFormData(prev => {
            const updatedParagraphs = [...prev.paragraphs];
            updatedParagraphs[index] = {
                ...updatedParagraphs[index],
                [field]: e.target.value
            };
            return { ...prev, paragraphs: updatedParagraphs };
        });
    };

    // Ajustamos la firma para checkbox
    const handleCheckboxChange = (
        e: ChangeEvent<HTMLInputElement>,
        index: number,
        field: 'lineDecoration' | 'overLined' // Solo campos booleanos
    ) => {
        makeDirty();
        setFormData(prev => {
            const updatedParagraphs = [...prev.paragraphs];
            updatedParagraphs[index] = {
                ...updatedParagraphs[index],
                [field]: e.target.checked
            };
            return { ...prev, paragraphs: updatedParagraphs };
        });
    };

    const handleColorChange = (colors: { from: string; to: string }, index: number) => {
        makeDirty();
        setFormData(prev => {
            const updatedParagraphs = [...prev.paragraphs];
            updatedParagraphs[index] = {
                ...updatedParagraphs[index],
                gradientFrom: colors.from,
                gradientTo: colors.to,
            };
            return { ...prev, paragraphs: updatedParagraphs };
        });
    };

    const handleIconChange = (e: ChangeEvent<HTMLSelectElement>, index: number) => {
        makeDirty();
        setFormData(prev => {
            const updatedParagraphs = [...prev.paragraphs];
            updatedParagraphs[index].icon = e.target.value;
            return { ...prev, paragraphs: updatedParagraphs };
        });
    };

    // --- Paragraph Handlers ---
    const addParagraph = () => {
        makeDirty();
        setFormData(prev => ({
            ...prev,
            paragraphs: [
                ...prev.paragraphs,
                {
                    id: generateTempId(), // ID temporal para el frontend
                    title: "",
                    content: "",
                    icon: PREDEFINED_ICONS[0],
                    gradientFrom: "from-gray-200",
                    gradientTo: "to-gray-400",
                    lineDecoration: false,
                    overLined: false,
                    subdominio: currentSubdomain, // Añadir el subdominio al nuevo párrafo
                },
            ],
        }));
    };

    const removeParagraph = (idToRemove: string | number) => {
        makeDirty();
        setFormData(prev => ({
            ...prev,
            paragraphs: prev.paragraphs.filter(p => p.id !== idToRemove),
        }));
    };

    // --- Cargar datos al montar el componente (título y párrafos) ---
    const loadOfertaData = useCallback(async () => {
        setIsLoading(true);
        // Obtener el subdominio al cargar la página
        const subdomain = getSubdomainFromWindow();
        setCurrentSubdomain(subdomain); // Actualizar el estado del subdominio

        try {
            // 1. Cargar Título Principal
            const titleResponse = await fetch(`${API_BASE_URL}/admin/dashboard/titulos/0`, { // Asumo que el ID para el título es 0 o fijo
                headers: { 'X-Subdomain': subdomain }, // Enviar subdominio en el encabezado
            });
            if (!titleResponse.ok) {
                if (titleResponse.status === 404) {
                    setFormData(prev => ({ ...prev, headerTitle: "" }));
                } else {
                    throw new Error(`Error al cargar título: ${titleResponse.status}`);
                }
            }
            const titleData = await titleResponse.json();
            setFormData(prev => ({ ...prev, headerTitle: titleData.titulo || "" }));


            // 2. Cargar Párrafos de Oferta
            const paragraphsResponse = await fetch(`${API_BASE_URL}/admin/dashboard/oferta`, {
                headers: { 'X-Subdomain': subdomain }, // Enviar subdominio en el encabezado
            });
            if (!paragraphsResponse.ok) throw new Error(`Error al cargar párrafos: ${paragraphsResponse.status}`);
            const paragraphsData: any[] = await paragraphsResponse.json(); // eslint-disable-line @typescript-eslint/no-explicit-any

            // Mapear los nombres de las propiedades del backend (entidad) a los del frontend
            const mappedParagraphs: ParagraphFormData[] = paragraphsData.map(p => ({
                id: p.id, // ID numérico de la base de datos
                title: p.Titulo, // <-- Corregido: Mapea de 'Titulo' (DB) a 'title' (frontend)
                content: p.Contenido, // <-- Corregido: Mapea de 'Contenido' (DB) a 'content' (frontend)
                icon: p.Icono, // <-- Corregido: Mapea de 'Icono' (DB) a 'icon' (frontend)
                gradientFrom: p.Color1, // <-- Corregido: Mapea de 'Color1' (DB) a 'gradientFrom' (frontend)
                gradientTo: p.Color2, // <-- Corregido: Mapea de 'Color2' (DB) a 'gradientTo' (frontend)
                lineDecoration: p.DecoracionLinea, // <-- Corregido: Mapea de 'DecoracionLinea' (DB) a 'lineDecoration' (frontend)
                overLined: p.TituloSuperpuesto, // <-- Corregido: Mapea de 'TituloSuperpuesto' (DB) a 'overLined' (frontend)
                subdominio: p.subdominio, // Añadir el subdominio si viene del backend
            }));

            setFormData(prev => ({ ...prev, paragraphs: mappedParagraphs }));
            setDbParagraphs(mappedParagraphs); // Guardar una copia de los párrafos tal como vienen de la DB

        } catch (error) {
            console.error("Error al cargar los datos de la página de Oferta:", error);
            alert("Error al cargar la información. Por favor, intente recargar la página.");
            setFormData({ headerTitle: "Error al cargar.", paragraphs: [] });
            setDbParagraphs([]);
        } finally {
            setIsLoading(false);
            setIsDirty(false); // No está sucio al cargar
        }
    }, []); // Dependencia vacía para que se ejecute solo al montar

    useEffect(() => {
        loadOfertaData();
    }, [loadOfertaData]);

    // --- Submit y Guardado ---
    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
         const token = localStorage.getItem('jwt_token'); // <-- Obtén el token aquí
        if (!token) {
            console.error("No JWT token found. Cannot save changes.");
            alert("Tu sesión ha expirado o no estás autenticado. Por favor, inicia sesión de nuevo.");
            router.push('/admin'); // Redirige al login
            setIsSaving(false);
            return;
        }
        try {
            // 1. Guardar el título principal
            const titleSaveResponse = await fetch(`${API_BASE_URL}/admin/dashboard/titulos`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Subdomain': currentSubdomain, // Enviar subdominio en el encabezado
                     'Authorization': `Bearer ${token}`,
                },
                body: JSON.stringify({
                    numPagina: 0, // Asumo que 0 es el ID para el título principal
                    titulo: formData.headerTitle,
                    subdominio: currentSubdomain, // Enviar subdominio en el cuerpo
                }),
            });
            if (!titleSaveResponse.ok) {
                // Manejo de errores de autenticación/autorización
                if (titleSaveResponse.status === 401 || titleSaveResponse.status === 403) {
                    localStorage.removeItem('jwt_token');
                    router.push('/admin');
                    throw new Error("Sesión expirada o no autorizado para guardar el título.");
                }
                throw new Error(`Error al guardar título: ${titleSaveResponse.status} - ${await titleSaveResponse.text()}`);
            }

            // 2. Sincronizar Párrafos (Eliminar, Crear/Actualizar)
            const currentDbIds = new Set(dbParagraphs.filter(p => typeof p.id === 'number').map(p => p.id as number));
            const formDbIds = new Set(formData.paragraphs.filter(p => typeof p.id === 'number').map(p => p.id as number));

            // Identificar párrafos a eliminar de la DB
            const idsToDelete = Array.from(currentDbIds).filter(id => !formDbIds.has(id));

            for (const id of idsToDelete) {
    const deleteResponse = await fetch(`${API_BASE_URL}/admin/dashboard/oferta/${id}`, { // <-- ASÍ ES CORRECTO
        method: 'DELETE',
        headers: { 'X-Subdomain': currentSubdomain , 'Authorization': `Bearer ${token}` }, // Correcto, incluye el token aquí
    });
                if (!deleteResponse.ok) {
                    if (deleteResponse.status === 401 || deleteResponse.status === 403) {
                        localStorage.removeItem('jwt_token');
                        router.push('/admin');
                        throw new Error("Sesión expirada o no autorizado para eliminar párrafos.");
                    }
                    throw new Error(`Error al eliminar párrafo con ID ${id}: ${deleteResponse.status} - ${await deleteResponse.text()}`);
                }
            }

            // Crear/Actualizar párrafos en la DB
            const updatedParagraphsState: ParagraphFormData[] = [];
            for (const p of formData.paragraphs) {
                const isNew = typeof p.id === 'string' && p.id.startsWith('temp-');

                const paragraphDto = {
                    id: isNew ? undefined : (p.id as number), // Enviar ID solo si es numérico (existente en DB)
                    // Mapea de los nombres del frontend a los nombres de la DB/DTO del backend (¡Aquí está el cambio crucial!)
                    Titulo: p.title, // <-- Corregido: Mapea de 'title' (frontend) a 'Titulo' (backend/DB)
                    Contenido: p.content, // <-- Corregido: Mapea de 'content' (frontend) a 'Contenido' (backend/DB)
                    Icono: p.icon, // <-- Corregido: Mapea de 'icon' (frontend) a 'Icono' (backend/DB)
                    Color1: p.gradientFrom, // <-- Corregido: Mapea de 'gradientFrom' (frontend) a 'Color1' (backend/DB)
                    Color2: p.gradientTo, // <-- Corregido: Mapea de 'gradientTo' (frontend) a 'Color2' (backend/DB)
                    DecoracionLinea: p.lineDecoration, // <-- Corregido: Mapea de 'lineDecoration' (frontend) a 'DecoracionLinea' (backend/DB)
                    TituloSuperpuesto: p.overLined, // <-- Corregido: Mapea de 'overLined' (frontend) a 'TituloSuperpuesto' (backend/DB)
                    subdominio: currentSubdomain, // Enviar subdominio en el cuerpo
                };

                const response = await fetch(`${API_BASE_URL}/admin/dashboard/oferta`, {
                    method: 'POST', // Tu backend ya maneja el upsert con POST
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                        'X-Subdomain': currentSubdomain, // Enviar subdominio en el encabezado
                    },
                    body: JSON.stringify(paragraphDto),
                });

                if (!response.ok) {
                    if (response.status === 401 || response.status === 403) {
                        localStorage.removeItem('jwt_token');
                        router.push('/admin');
                        throw new Error("Sesión expirada o no autorizado para guardar/actualizar párrafos.");
                    }
                    const errorBody = await response.text();
                    throw new Error(`Error al guardar el párrafo "${p.title || 'nuevo'}": ${response.status} - ${errorBody}`);
                }
                const savedP = await response.json();
                // Si es un nuevo párrafo, actualiza su ID con el ID de la base de datos
                updatedParagraphsState.push({ ...p, id: savedP.id });
            }

            // Actualiza el estado de `formData` y `dbParagraphs` con los IDs de la base de datos
            setFormData(prev => ({ ...prev, paragraphs: updatedParagraphsState }));
            setDbParagraphs(updatedParagraphsState); // Sincroniza también los párrafos "originales"

            alert('Cambios guardados exitosamente!');
            setIsDirty(false);

        } catch (error) {
            console.error('Error al guardar los cambios:', error);
            alert('Error al guardar los cambios. Por favor, inténtelo de nuevo: ' + (error as Error).message);
        } finally {
            setIsSaving(false);
        }
    };

    // --- Manejo de alerta antes de salir si hay cambios sin guardar ---
    useEffect(() => {
        const handleBeforeUnload = (e: BeforeUnloadEvent) => {
            if (isDirty) {
                e.preventDefault();
                e.returnValue = "";
            }
        };
        window.addEventListener("beforeunload", handleBeforeUnload);
        return () => window.removeEventListener("beforeunload", handleBeforeUnload);
    }, [isDirty]);

    // Manejador para el título principal que estaba faltando
    const handleHeaderTitleChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
        makeDirty();
        setFormData(prev => ({ ...prev, headerTitle: e.target.value }));
    };

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <p>Cargando información...</p>
            </div>
        );
    }

    return (
        <div className="flex mb-20 md:mb-0">
            <SideBar selectedIndex={2} />
            <main className="flex-1 ml-0 md:ml-64 p-4 sm:p-8">
                <form onSubmit={handleSubmit} className="space-y-6 sm:space-y-8">
                    {/* Sección Título Principal */}
                    <section className="p-4 sm:p-6 border border-gray-300 rounded-lg shadow">
                        <h2 className="text-lg sm:text-xl font-semibold mb-3 sm:mb-4 text-blue-700">
                            Título Principal de Oferta ({currentSubdomain})
                        </h2>
                        <div>
                            <label htmlFor="headerTitle" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Texto del Título</label>
                            <textarea
                                name="headerTitle"
                                id="headerTitle"
                                value={formData.headerTitle}
                                onChange={handleHeaderTitleChange}
                                rows={3}
                                placeholder="Ej: Profesionistas especializados en diseño..."
                                className="block w-full mt-1 border border-gray-300 rounded px-2 sm:px-3 py-1 sm:py-2 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                            />
                        </div>
                    </section>

                    {/* Sección Párrafos Dinámicos */}
                    <section className="p-4 sm:p-6 border border-gray-300 rounded-lg shadow space-y-4 sm:space-y-6">
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-0">
                            <h2 className="text-lg sm:text-xl font-semibold text-green-700">Párrafos de Contenido</h2>
                            <button type="button" onClick={addParagraph} className="px-3 sm:px-4 py-1.5 sm:py-2 bg-green-500 text-white rounded hover:bg-green-600 text-xs sm:text-sm self-end sm:self-auto">
                                + Añadir Párrafo
                            </button>
                        </div>
                        {formData.paragraphs.map((p, index) => (
                            <div key={p.id} className="p-3 sm:p-4 border border-gray-200 rounded-md space-y-3 sm:space-y-4 relative">
                                <button type="button" onClick={() => removeParagraph(p.id)} className="absolute top-1 right-1 sm:top-2 sm:right-2 px-1.5 sm:px-2 py-0.5 sm:py-1 bg-red-500 text-white rounded hover:bg-red-600 text-xs">
                                    - Eliminar
                                </button>
                                <h3 className="text-base sm:text-lg font-medium text-gray-800">Párrafo #{index + 1}</h3>
                                <div>
                                    <label htmlFor={`p_title_${p.id}`} className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Título del Párrafo</label>
                                    <input type="text" name={`p_title_${p.id}`} id={`p_title_${p.id}`} value={p.title} onChange={(e) => handleInputChange(e, index, 'title')} placeholder="Ej: ¿Qué es una ingeniería?" className="block w-full mt-1 border border-gray-300 rounded px-2 sm:px-3 py-1 sm:py-2 text-sm sm:text-base" />
                                </div>
                                <div>
                                    <label htmlFor={`p_content_${p.id}`} className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Contenido</label>
                                    <textarea name={`p_content_${p.id}`} id={`p_content_${p.id}`} value={p.content} onChange={(e) => handleInputChange(e, index, 'content')} rows={3} placeholder="Contenido detallado del párrafo..." className="block w-full mt-1 border border-gray-300 rounded px-2 sm:px-3 py-1 sm:py-2 text-sm sm:text-base" />
                                </div>
                                <div>
                                    <label htmlFor={`p_icon_${p.id}`} className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Icono</label>
                                    <select name={`p_icon_${p.id}`} id={`p_icon_${p.id}`} value={p.icon} onChange={(e) => handleIconChange(e, index)} className="block w-full mt-1 border border-gray-300 rounded px-2 sm:px-3 py-1 sm:py-2 text-sm sm:text-base">
                                        {PREDEFINED_ICONS.map(iconPath => (
                                            <option key={iconPath} value={iconPath}>{iconPath.split('/').pop()}</option>
                                        ))}
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Colores del Título del Párrafo</label>
                                    <ColorComboBox value={{ from: p.gradientFrom, to: p.gradientTo }} onChange={(colors) => handleColorChange(colors, index)} />
                                </div>
                                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-4">
                                    <label htmlFor={`p_lineDeco_${p.id}`} className="flex items-center text-xs sm:text-sm font-medium text-gray-700">
                                        <input type="checkbox" name={`p_lineDeco_${p.id}`} id={`p_lineDeco_${p.id}`} checked={p.lineDecoration} onChange={(e) => handleCheckboxChange(e, index, 'lineDecoration')} className="mr-2 h-3.5 w-3.5 sm:h-4 sm:w-4 text-blue-600 border-gray-300 rounded" />
                                        Decoración de Línea
                                    </label>
                                    <label htmlFor={`p_overLined_${p.id}`} className="flex items-center text-xs sm:text-sm font-medium text-gray-700">
                                        <input type="checkbox" name={`p_overLined_${p.id}`} id={`p_overLined_${p.id}`} checked={p.overLined} onChange={(e) => handleCheckboxChange(e, index, 'overLined')} className="mr-2 h-3.5 w-3.5 sm:h-4 sm:w-4 text-blue-600 border-gray-300 rounded" />
                                        Título Superpuesto (OverLined)
                                    </label>
                                </div>
                            </div>
                        ))}
                    </section>

                    {/* Botón Guardar Cambios */}
                    <div className="mt-6 sm:mt-10 flex justify-end">
                        <button
                            type="submit"
                            className="px-6 sm:px-8 py-2 sm:py-3 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 text-sm sm:text-base"
                            disabled={!isDirty || isSaving}
                        >
                            {isSaving ? "Guardando..." : "Guardar Cambios"}
                        </button>
                    </div>
                </form>
            </main>
        </div>
    );
}