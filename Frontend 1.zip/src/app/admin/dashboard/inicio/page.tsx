/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import SideBar from "@/components/SideBar/SideBar";
import ColorComboBox from "@/components/ColorComboBox/ColorComboBox";
import React, { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation"; 

// Asegúrate de que esta URL base coincide con la de tu backend
const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:3001';

// Interfaz para los datos del formulario (refleja los campos requeridos y opcionales del DTO)
interface FormData {
    Titulo: string; 
    TextoBotonSuperior: string; 
    LinkBotonSuperior?: string | null; 
    Color1BotonSuperior?: string;
    Color2BotonSuperior?: string;
    TextoBotonInferior: string; 
    LinkBotonInferior?: string | null; 
    Color1BotonInferior?: string;
    Color2BotonInferior?: string;
    subdominio?: string;
}

const getSubdomainFromWindow = () => {
    if (typeof window === 'undefined') {
        return 'default';
    }
    const hostname = window.location.hostname;
    const parts = hostname.split('.');
    let detectedSubdomain = 'default';

    if (parts.length === 2 && parts[1] === 'localhost' && parts[0] !== 'www') {
        detectedSubdomain = parts[0];
    } else if (parts.length > 2 && parts[0] !== 'www') {
        detectedSubdomain = parts[0];
    }
    return detectedSubdomain;
};

export default function Dashboard() {
     const router = useRouter(); // Inicializa el router
    const [formData, setFormData] = useState<FormData>({
        // Inicializamos los campos requeridos con cadena vacía, no null
        Titulo: "",
        TextoBotonSuperior: "",
        LinkBotonSuperior: null,
        Color1BotonSuperior: "from-guinda",
        Color2BotonSuperior: "to-vino",
        TextoBotonInferior: "",
        LinkBotonInferior: null,
        Color1BotonInferior: "from-guinda",
        Color2BotonInferior: "to-vino",
        subdominio: 'default',
    });
    
    const [initialFormData, setInitialFormData] = useState<FormData>({
        Titulo: "",
        TextoBotonSuperior: "",
        TextoBotonInferior: "",
        // Los otros campos pueden ser undefined o null si son opcionales en la interfaz,
        // pero es buena práctica inicializarlos para reflejar el estado "vacío" o "por defecto".
        LinkBotonSuperior: null,
        Color1BotonSuperior: "from-guinda",
        Color2BotonSuperior: "to-vino",
        LinkBotonInferior: null,
        Color1BotonInferior: "from-guinda",
        Color2BotonInferior: "to-vino",
        subdominio: 'default', // O el subdominio que el getSubdomainFromWindow() devolvería por defecto
    });
    // FIN DE LA CORRECCIÓN

    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isDirty, setIsDirty] = useState(false);

    const mapBackendToFrontend = (backendData: any): FormData => {
        return {
            // Aseguramos que los campos requeridos siempre sean strings
            Titulo: backendData.Titulo || "",
            TextoBotonSuperior: backendData.TextoBotonSuperior || "",
            // Manejamos undefined/null para enlaces
            LinkBotonSuperior: backendData.LinkBotonSuperior === undefined ? null : backendData.LinkBotonSuperior,
            Color1BotonSuperior: backendData.Color1BotonSuperior || "from-guinda",
            Color2BotonSuperior: backendData.Color2BotonSuperior || "to-vino",
            TextoBotonInferior: backendData.TextoBotonInferior || "",
            LinkBotonInferior: backendData.LinkBotonInferior === undefined ? null : backendData.LinkBotonInferior,
            Color1BotonInferior: backendData.Color1BotonInferior || "from-guinda",
            Color2BotonInferior: backendData.Color2BotonInferior || "to-vino",
            subdominio: backendData.subdominio || getSubdomainFromWindow(),
        };
    };

    const mapFrontendToBackend = (frontendData: FormData): FormData => {
        return {
            Titulo: frontendData.Titulo,
            TextoBotonSuperior: frontendData.TextoBotonSuperior,
            // Convertimos string vacío a null para los enlaces antes de enviar al backend
            LinkBotonSuperior: frontendData.LinkBotonSuperior === "" ? null : frontendData.LinkBotonSuperior,
            Color1BotonSuperior: frontendData.Color1BotonSuperior,
            Color2BotonSuperior: frontendData.Color2BotonSuperior,
            TextoBotonInferior: frontendData.TextoBotonInferior,
            LinkBotonInferior: frontendData.LinkBotonInferior === "" ? null : frontendData.LinkBotonInferior,
            Color1BotonInferior: frontendData.Color1BotonInferior,
            Color2BotonInferior: frontendData.Color2BotonInferior,
        };
    };

    const loadConfigData = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        const currentSubdomain = getSubdomainFromWindow();

        try {
            const response = await fetch(`${API_BASE_URL}/admin/dashboard/inicio`, {
                headers: {
                    'X-Subdomain': currentSubdomain,
                },
            });

            if (!response.ok) {
                const errorData = await response.json();
                console.error('Error al cargar la configuración:', errorData);
                throw new Error(`Failed to load config: ${response.status} ${response.statusText}`);
            }

            const data: FormData = await response.json();
            const mappedData = mapBackendToFrontend(data);

            setFormData(mappedData);
            setInitialFormData(mappedData);
            setIsDirty(false);
        } catch (err: any) {
            console.error('Error fetching config:', err);
            setError(`No se pudo cargar la configuración para este subdominio. ${err.message}`);
        } finally {
            setIsLoading(false);
        }
    }, []);
     useEffect(() => {
        const token = localStorage.getItem('jwt_token');
        if (!token) {
            console.warn("HomeCMSPage: No JWT token found. Redirecting to login.");
            router.push('/admin');
        } else {
            console.log("HomeCMSPage: Token found. Proceeding to load data.");
            // Aquí puedes dejar la lógica de carga de datos inicial (fetchInitialData)
            // ya que el GET /admin/dashboard/inicio es público.
        }
    }, [router]);

    useEffect(() => {
        loadConfigData();
    }, [loadConfigData]);


    useEffect(() => {
        if (!isLoading && Object.keys(initialFormData).length > 0) {
            const hasChanges = Object.keys(formData).some(key => {
                // Manejo especial para los enlaces que pueden ser null o "" para isDirty
                if (key === 'LinkBotonSuperior' || key === 'LinkBotonInferior') {
                    // Ambos null o ambos "" son iguales
                    if (formData[key] === null && initialFormData[key] === null) return false;
                    if (formData[key] === "" && initialFormData[key] === "") return false;
                    // Uno null y el otro "" son iguales
                    if ((formData[key] === null && initialFormData[key] === "") || (formData[key] === "" && initialFormData[key] === null)) return false;
                    // Cualquier otra diferencia
                    return formData[key] !== initialFormData[key];
                }
                return (formData as any)[key] !== (initialFormData as any)[key];
            });
            setIsDirty(hasChanges);
        }
    }, [formData, initialFormData, isLoading]);


    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleColorChange = (section: 'guindaButton' | 'inferiorButton', colors: { from: string; to: string }) => {
        setFormData(prev => {
            if (section === 'guindaButton') {
                return {
                    ...prev,
                    Color1BotonSuperior: colors.from,
                    Color2BotonSuperior: colors.to,
                };
            } else if (section === 'inferiorButton') {
                return {
                    ...prev,
                    Color1BotonInferior: colors.from,
                    Color2BotonInferior: colors.to,
                };
            }
            return prev;
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError(null);
          const token = localStorage.getItem('jwt_token'); // <-- Obtén el token aquí
    if (!token) {
        // Esto es una medida de seguridad extra, aunque el useEffect debería haber redirigido
        setError("No estás autenticado. Por favor, inicia sesión de nuevo.");
        router.push('/admin');
        setIsLoading(false); // Asegúrate de restablecer el estado de carga
        return;
    }

        const currentSubdomain = getSubdomainFromWindow();
        const dataToSend = mapFrontendToBackend(formData);

        try {
            const response = await fetch(`${API_BASE_URL}/admin/dashboard/inicio`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Subdomain': currentSubdomain,
                    'Authorization': `Bearer ${token}`,
                },
                body: JSON.stringify(dataToSend),
            });

             if (!response.ok) {
            const errorData = await response.json();
            if (response.status === 401 || response.status === 403) {
                localStorage.removeItem('jwt_token'); // Limpia el token expirado/inválido
                router.push('/admin'); // Redirige al login
                setError(errorData.message || "Tu sesión ha expirado o no estás autorizado.");
            } else {
                throw new Error(errorData.message || `Error del servidor: ${response.status}`);
            }
        }

            const savedData = await response.json();
            const mappedSavedData = mapBackendToFrontend(savedData);
            setFormData(mappedSavedData);
            setInitialFormData(mappedSavedData);
            setIsDirty(false);
            alert("Cambios guardados con éxito!");
        } catch (err: any) {
            console.error("Error al guardar:", err);
            setError(`Error al guardar los cambios: ${err.message}`);
            alert(`Error al guardar los cambios: ${err.message}`);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        const handleBeforeUnload = (e: BeforeUnloadEvent) => {
            if (isDirty) {
                e.preventDefault();
                e.returnValue = "";
            }
        };

        window.addEventListener("beforeunload", handleBeforeUnload);
        return () => {
            window.removeEventListener("beforeunload", handleBeforeUnload);
        };
    }, [isDirty]);

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <p>Cargando configuración...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex flex-col justify-center items-center h-screen text-red-600">
                <p>{error}</p>
                <button
                    onClick={loadConfigData}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700"
                >
                    Reintentar
                </button>
            </div>
        );
    }

    return (
        <div className="flex mb-20 md:mb-0">
            <SideBar selectedIndex={1} />
            <main className="flex-1 ml-0 md:ml-64 p-4 sm:p-8">
                <form onSubmit={handleSubmit} className="space-y-6 sm:space-y-8">
                    {/* Sección Título */}
                    <section className="p-4 sm:p-6 border border-gray-300 rounded-lg shadow">
                        <h2 className="text-lg sm:text-xl font-semibold mb-3 sm:mb-4 text-blue-700">Título Principal</h2>
                        <div>
                            <label htmlFor="headerTitle" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Texto del Título de Encabezado</label>
                            <input
                                type="text"
                                name="Titulo"
                                id="headerTitle"
                                value={formData.Titulo}
                                onChange={handleChange}
                                placeholder="Ej: ¿Pronto a la universidad?"
                                className="block w-full mt-1 border border-gray-300 rounded px-2 sm:px-3 py-1 sm:py-2 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                required
                            />
                        </div>
                    </section>

                    {/* Sección Botón Guinda (Superior) */}
                    <section className="p-4 sm:p-6 border border-gray-300 rounded-lg shadow">
                        <h2 className="text-lg sm:text-xl font-semibold mb-3 sm:mb-4 text-rose-700">Botón Superior</h2>
                        <div className="space-y-3 sm:space-y-4">
                            <div>
                                <label htmlFor="guindaButtonText" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Texto del Botón</label>
                                <input
                                    type="text"
                                    name="TextoBotonSuperior"
                                    id="guindaButtonText"
                                    value={formData.TextoBotonSuperior}
                                    onChange={handleChange}
                                    placeholder="Ej: Quiero ser guinda"
                                    className="block w-full mt-1 border border-gray-300 rounded px-2 sm:px-3 py-1 sm:py-2 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Colores del Botón</label>
                                <ColorComboBox
                                    value={{ from: formData.Color1BotonSuperior || "from-guinda", to: formData.Color2BotonSuperior || "to-vino" }}
                                    onChange={(colors) => handleColorChange('guindaButton', colors)}
                                />
                            </div>
                            <div>
                                <label htmlFor="guindaButtonLink" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Enlace que abre</label>
                                <input
                                    type="text"
                                    name="LinkBotonSuperior"
                                    id="guindaButtonLink"
                                    value={formData.LinkBotonSuperior || ""}
                                    onChange={handleChange}
                                    placeholder="Ej: https://www.itdurango.edu.mx/aspirantes/"
                                    className="block w-full mt-1 border border-gray-300 rounded px-2 sm:px-3 py-1 sm:py-2 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                />
                            </div>
                        </div>
                    </section>

                    {/* Sección Botón Inferior */}
                    <section className="p-4 sm:p-6 border border-gray-300 rounded-lg shadow">
                        <h2 className="text-lg sm:text-xl font-semibold mb-3 sm:mb-4 text-gray-700">Botón Inferior</h2>
                        <div className="space-y-3 sm:space-y-4">
                            <div>
                                <label htmlFor="inferiorButtonText" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Texto del Botón</label>
                                <input
                                    type="text"
                                    name="TextoBotonInferior"
                                    id="inferiorButtonText"
                                    value={formData.TextoBotonInferior}
                                    onChange={handleChange}
                                    placeholder="Ej: Todas las novedades aquí"
                                    className="block w-full mt-1 border border-gray-300 rounded px-2 sm:px-3 py-1 sm:py-2 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Colores del Botón</label>
                                <ColorComboBox
                                    value={{ from: formData.Color1BotonInferior || "from-guinda", to: formData.Color2BotonInferior || "to-vino" }}
                                    onChange={(colors) => handleColorChange('inferiorButton', colors)}
                                />
                            </div>
                            <div>
                                <label htmlFor="inferiorButtonLink" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Enlace que abre</label>
                                <input
                                    type="text"
                                    name="LinkBotonInferior"
                                    id="inferiorButtonLink"
                                    value={formData.LinkBotonInferior || ""}
                                    onChange={handleChange}
                                    placeholder="Ej: https://www.facebook.com/ITDgoOficial"
                                    className="block w-full mt-1 border border-gray-300 rounded px-2 sm:px-3 py-1 sm:py-2 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                />
                            </div>
                        </div>
                    </section>

                    <div className="mt-6 sm:mt-8 flex justify-end">
                        <button
                            type="submit"
                            className="px-4 py-2 sm:px-6 sm:py-2 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 text-sm sm:text-base"
                            disabled={!isDirty || isLoading}
                        >
                            {isLoading ? "Guardando..." : "Guardar Cambios"}
                        </button>
                    </div>
                </form>
            </main>
        </div>
    );
}