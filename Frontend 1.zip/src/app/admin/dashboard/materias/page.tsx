/* eslint-disable react/no-unescaped-entities */
/* eslint-disable @typescript-eslint/no-explicit-any */
//* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
"use client";

import SideBar from "@/components/SideBar/SideBar";
import ColorComboBox from "@/components/ColorComboBox/ColorComboBox";
import React, { useState, useEffect, useCallback, ChangeEvent, FormEvent, useRef } from "react";

import { useRouter } from "next/navigation";

interface CarouselItemConfig {
    id: string;
    url: string; // Image path or YouTube embed URL
}

interface ParagraphConfig {
    id: string;
    title: string;
    content: string;
    iconPath: string; // Will always be ""
    gradientFrom: string;
    gradientTo: string;
    lineDecoration: boolean;
    overLined: boolean;
}

interface ParagraphGroupConfig {
    id: string;
    firstItem: ParagraphConfig;
    secondItemType: 'none' | 'paragraph' | 'carousel';
    secondItemParagraph?: ParagraphConfig;
    secondItemCarouselItems?: CarouselItemConfig[];
}

interface MateriasPageCMSData {
    headerTitle: string;
    paragraphGroups: ParagraphGroupConfig[];
}

// --- Constants ---
const API_BASE_URL = "http://localhost:3001";
const PAGE_NUMBER_FOR_MATERIAS = 1; // ID de página para "Materias"

// Helper function to get subdomain from window.location
const getSubdomainFromWindow = (): string => {
    if (typeof window === 'undefined') {
        return 'default';
        // Default for SSR or environments without window
    }
    const hostname = window.location.hostname;
    // Example: if hostname is 'sub.example.com', returns 'sub'
    // if hostname is 'localhost', returns 'localhost' (or you can set a default)
    const parts = hostname.split('.');
    if (parts.length > 2) {
        return parts[0];
        // subdomain part
    }
    // Handle localhost or direct IP, assign a default subdomain
    return 'default';
};

// Helper para generar IDs temporales para nuevos elementos en el frontend
const generateTempId = () => `temp-${Math.random().toString(36).substr(2, 9)}`;
// Helper para eliminar items del carrusel por ID
const removeTempId = (id: string) => {
    // Aquí puedes limpiar IDs temporales si los generas para elementos que se eliminan
    // En el contexto de este formulario, es más crítico al añadir que al eliminar
};
const MateriasPage: React.FC = () => {
    const currentSubdomain = useRef<string>('');
    // Usar useRef para el subdominio
    const router = useRouter();
  useEffect(() => {
        console.log("MateriasPageCMS: useEffect ejecutado. Verificando token..."); // DEBUG 1
        const token = localStorage.getItem('jwt_token');
        console.log("MateriasPageCMS: Token de localStorage:", token); // DEBUG 2

        if (!token) {
            console.log("MateriasPageCMS: No hay token, intentando redirigir a /admin/login..."); // DEBUG 3
            router.push('/admin');
        } else {
            console.log("MateriasPageCMS: Token encontrado. No se redirige."); // DEBUG 4
            // Aquí puedes añadir tu lógica de carga de datos inicial si es protegida
        }
    }, [router])
    const [formData, setFormData] = useState<MateriasPageCMSData>({
        headerTitle: "",
        paragraphGroups: [],
    });
    const [isDirty, setIsDirty] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);
    // --- Data Fetching ---
    const fetchData = useCallback(async (subdomain: string) => {
        setIsSaving(true); // Usar isSaving para indicar carga inicial también
        setError(null);
        try {
            // Fetch Title
            const titleResponse = await fetch(`${API_BASE_URL}/admin/dashboard/titulos/${PAGE_NUMBER_FOR_MATERIAS}`, {
                headers: { 'X-Subdomain': subdomain }
            });

            let headerTitle = "";
            if (titleResponse.ok) {
                const titleData = await titleResponse.json();
                headerTitle = titleData.titulo || ""; // Asegúrate de que coincida con la propiedad del backend
            } else if (titleResponse.status === 404) {
                console.log(`Título para la página ${PAGE_NUMBER_FOR_MATERIAS} y subdominio ${subdomain} no encontrado. Se usará un título vacío.`);
                headerTitle = "";
            } else {
                const errorData = await titleResponse.json();
                console.error("Error fetching title:", errorData.message || titleResponse.statusText);
                throw new Error(`Error al cargar el título: ${errorData.message || titleResponse.statusText}`);
            }

            // Fetch Paragraph Groups
            const pgResponse = await fetch(`${API_BASE_URL}/materias/paragraph-groups`, {
                headers: { 'X-Subdomain': subdomain }
            });
            let paragraphGroups: ParagraphGroupConfig[] = [];
            if (pgResponse.ok) {
                const pgData = await pgResponse.json();
                // Mapea los datos del backend a la estructura del frontend
                paragraphGroups = pgData.map((group: any) => ({
                    id: group.id,
                    firstItem: {
                        id: generateTempId(), // Estos IDs son solo para el frontend
                        title: group.firstItemTitle,
                        content: group.firstItemContent,
                        iconPath: "", // Siempre vacío para materias
                        gradientFrom: group.firstItemGradientFrom,
                        gradientTo: group.firstItemGradientTo,
                        lineDecoration: group.firstItemLineDecoration,
                        overLined: group.firstItemOverLined,
                    },
                    secondItemType: group.secondItemContent || group.secondItemTitle || group.secondItemCarouselItems?.length > 0
                        ? (group.secondItemContent || group.secondItemTitle ? 'paragraph' : 'carousel')
                        : 'none',
                    secondItemParagraph: group.secondItemContent || group.secondItemTitle ?
                        {
                            id: generateTempId(),
                            title: group.secondItemTitle || '',
                            content: group.secondItemContent || '',
                            iconPath: "",
                            gradientFrom: group.secondItemGradientFrom || '',
                            gradientTo: group.secondItemGradientTo || '',
                            lineDecoration: group.secondItemLineDecoration || false,
                            overLined: group.secondItemOverLined || false,
                        } : undefined,
                    secondItemCarouselItems: group.carouselUrls?.length > 0 ?
                        group.carouselUrls.map((url: string) => ({ id: generateTempId(), url })) : undefined,
                }));
            } else if (pgResponse.status === 404) {
                console.log("No paragraph groups found for this subdomain. Starting with empty.");
                paragraphGroups = [];
            } else {
                const errorData = await pgResponse.json();
                console.error("Error fetching paragraph groups:", errorData.message || pgResponse.statusText);
                throw new Error(`Error al cargar los grupos de párrafos: ${errorData.message || pgResponse.statusText}`);
            }

            setFormData({ headerTitle, paragraphGroups });
        } catch (err: any) {
            setError(err.message || "Error al cargar los datos.");
            console.error("Fetch data error:", err);
        } finally {
            setIsSaving(false);
            setIsDirty(false); // Reset dirty state after initial load
        }
    }, []);
    useEffect(() => {
        currentSubdomain.current = getSubdomainFromWindow();
        fetchData(currentSubdomain.current);
    }, [fetchData]);
    // --- Form Handlers ---
    const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData((prev) => {
            const newState = {
                ...prev,
                [name]: value,
            };
            setIsDirty(true);
            return newState;
        });
    };

    const handleParagraphItemChange = useCallback((
        groupIndex: number,
        itemType: 'firstItem' | 'secondItemParagraph',
        field: keyof ParagraphConfig,
        value: string | boolean | { from: string; to: string } // Permite pasar objetos para ColorComboBox
    ) => {
        setFormData((prev) => {
            const updatedParagraphGroups = [...prev.paragraphGroups];
            const targetItem = updatedParagraphGroups[groupIndex][itemType];

            if (targetItem) {
                if (field === 'gradientFrom' || field === 'gradientTo') {
                    // Si el campo es gradientFrom o gradientTo, y el valor es un objeto {from, to}
                    if (typeof value === 'object' && 'from' in value && 'to' in value) {
                        if (field === 'gradientFrom') {
                            targetItem.gradientFrom = value.from;
                            targetItem.gradientTo = value.to; // Actualiza ambos si viene de ColorComboBox
                        } else {
                            targetItem.gradientFrom = value.from; // Asegura que se actualiza si el componente envía ambos
                            targetItem.gradientTo = value.to;
                        }
                    } else if (typeof value === 'string') {
                        // Si el valor es un string (e.g., de un input de texto directo)
                        (targetItem as any)[field] = value;
                    }
                } else {
                    // Para otros campos (title, content, lineDecoration, overLined)
                    (targetItem as any)[field] = value;
                }
            }

            setIsDirty(true);
            return { ...prev, paragraphGroups: updatedParagraphGroups };
        });
    }, []);


    const handleSecondItemTypeChange = useCallback((groupIndex: number, type: 'none' | 'paragraph' | 'carousel') => {
        setFormData((prev) => {
            const updatedGroups = [...prev.paragraphGroups];
            const group = updatedGroups[groupIndex];

            group.secondItemType = type;
            if (type === 'paragraph' && !group.secondItemParagraph) {
                group.secondItemParagraph = {
                    id: generateTempId(),
                    title: '', content: '', iconPath: '', gradientFrom: '', gradientTo: '', lineDecoration: false, overLined: false
                };
                group.secondItemCarouselItems = undefined; // Clear carousel if switching to paragraph
            } else if (type === 'carousel' && !group.secondItemCarouselItems) {
                group.secondItemCarouselItems = [];
                group.secondItemParagraph = undefined; // Clear paragraph if switching to carousel
            } else if (type === 'none') {
                group.secondItemParagraph = undefined;
                group.secondItemCarouselItems = undefined;
            }
            setIsDirty(true);
            return { ...prev, paragraphGroups: updatedGroups };
        });
    }, []);

    const addCarouselItem = useCallback((groupId: string, url: string) => {
        setFormData((prev) => {
            const updatedGroups = prev.paragraphGroups.map((pg) => {
                if (pg.id === groupId) {
                    const newItems = pg.secondItemCarouselItems ? [...pg.secondItemCarouselItems, { id: generateTempId(), url }] : [{ id: generateTempId(), url }];
                    return { ...pg, secondItemCarouselItems: newItems };
                }
                return pg;
            });
            setIsDirty(true);
            return { ...prev, paragraphGroups: updatedGroups };
        });
    }, []);
    const removeCarouselItem = useCallback((groupId: string, itemId: string) => {
        setFormData((prev) => {
            const updatedGroups = prev.paragraphGroups.map((pg) => {
                if (pg.id === groupId) {
                    const filteredItems = pg.secondItemCarouselItems?.filter((item) => item.id !== itemId);
                    return { ...pg, secondItemCarouselItems: filteredItems };
                }
                return pg;
            });
            setIsDirty(true);
            return { ...prev, paragraphGroups: updatedGroups };
        });
    }, []);
    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        setError(null);
        const token = localStorage.getItem('jwt_token'); 
    if (!token) {
        // Esto es una medida de seguridad extra, aunque el useEffect debería haber redirigido
        setError("No estás autenticado. Por favor, inicia sesión de nuevo.");
        router.push('/admin');
        setIsSaving(false);
        return;
    }
    
        try {
            // 1. Enviar el título principal [cite: 66]
            const titlePayload = {
                numPagina: PAGE_NUMBER_FOR_MATERIAS, // Esto es 1 (o el número de página para Materias) [cite: 66]
                subdominio: currentSubdomain.current, // [cite: 66]
                titulo: formData.headerTitle, // [cite: 66]
            };

            const titleSaveResponse = await fetch(`${API_BASE_URL}/admin/dashboard/titulos`, { // <--- RUTA CORRECTA [cite: 67]
                method: 'PUT', // [cite: 67]
                headers: {
                    'Content-Type': 'application/json', // [cite: 68]
                    
                },
                body: JSON.stringify(titlePayload), // [cite: 69]
            });
            if (!titleSaveResponse.ok) {
                const errorData = await titleSaveResponse.json();
                throw new Error(`Error al guardar el título: ${errorData.message || titleSaveResponse.statusText}`);
            }

            // 2. Eliminar todos los grupos de párrafos existentes para este subdominio
            const deleteResponse = await fetch(`${API_BASE_URL}/materias/admin/paragraph-groups/delete-all`, {
                method: 'DELETE',
                headers: {
                    'X-Subdomain': currentSubdomain.current,
                    'Authorization': `Bearer ${token}`,
                },
            });

            if (!deleteResponse.ok) {
                const errorData = await deleteResponse.json();
                 if (deleteResponse.status === 401 || deleteResponse.status === 403) { // Manejar 401 y 403
        localStorage.removeItem('jwt_token'); // Eliminar token inválido
        router.push('/admin'); // Redirigir al login
        setError(errorData.message || "Tu sesión ha expirado o no estás autorizado.");
    } else {
        throw new Error(errorData.message || `Error del servidor: ${deleteResponse.status}`);
    }
            }

            // 3. Insertar cada grupo de párrafo uno por uno
            for (const pg of formData.paragraphGroups) {
                const paragraphGroupPayload = {
                    subdominio: currentSubdomain.current,
                    firstItemTitle: pg.firstItem.title,
                    firstItemContent: pg.firstItem.content,
                    firstItemGradientFrom: pg.firstItem.gradientFrom,
                    firstItemGradientTo: pg.firstItem.gradientTo,
                    firstItemLineDecoration: pg.firstItem.lineDecoration,
                    firstItemOverLined: pg.firstItem.overLined,
                    secondItemType: pg.secondItemType,
                    secondItemTitle: pg.secondItemParagraph?.title || null,
                    secondItemContent: pg.secondItemParagraph?.content || null,
                    secondItemGradientFrom: pg.secondItemParagraph?.gradientFrom || null,
                    secondItemGradientTo: pg.secondItemParagraph?.gradientTo || null,
                    secondItemLineDecoration: pg.secondItemParagraph?.lineDecoration || false,
                    secondItemOverLined: pg.secondItemParagraph?.overLined || false,
                    carouselUrls: pg.secondItemCarouselItems?.map(item => item.url) || [],
                };

                const pgSaveResponse = await fetch(`${API_BASE_URL}/materias/admin/paragraph-groups`, { // Assuming this is the POST endpoint for a single group
                    method: 'POST', // Use POST for insertion
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
//'X-Subdomain': currentSubdomain.current,
                    },
                    body: JSON.stringify(paragraphGroupPayload),
                });

                if (!pgSaveResponse.ok) {
                    const errorData = await pgSaveResponse.json();
                     if (pgSaveResponse.status === 401 || pgSaveResponse.status === 403) { // Manejar 401 y 403
        localStorage.removeItem('jwt_token'); // Eliminar token inválido
        router.push('/admin'); // Redirigir al login
        setError(errorData.message || "Tu sesión ha expirado o no estás autorizado.");
    } else {
         alert('Rellene todos los campos y seleccione colores para todos las secciones!.');
        throw new Error(errorData.message || `Error del servidor: ${pgSaveResponse.status}`);
    }
                }
            }


            alert("Cambios guardados exitosamente!");
            // Considera re-fetch data para obtener IDs reales si se crearon nuevos elementos [cite: 85]
            fetchData(currentSubdomain.current); // Vuelve a cargar los datos para obtener IDs reales si se crearon nuevos elementos [cite: 86]
        } catch (err: any) {
            console.error("Error al guardar los cambios:", err); // [cite: 87]
            setError(err.message || "Error al guardar los cambios. Inténtalo de nuevo."); // [cite: 87]
        } finally {
            setIsSaving(false); 
        }
    };
    const addParagraphGroup = useCallback(() => {
        setFormData((prev) => {
            const newGroup: ParagraphGroupConfig = {
                id: generateTempId(),
                firstItem: {
                    id: generateTempId(),
                    title: '', content: '', iconPath: '', gradientFrom: '', gradientTo: '', lineDecoration: false, overLined: false
                },
                secondItemType: 'none',
                secondItemParagraph: undefined,
                secondItemCarouselItems: undefined,
            };
            setIsDirty(true); 
            return {
                ...prev,
                paragraphGroups: [...prev.paragraphGroups, newGroup],
            };
        });
    }, []);
    const removeParagraphGroup = useCallback(async (id: string) => {
        if (confirm("¿Estás seguro de que quieres eliminar este grupo de párrafo?")) { 
            setIsSaving(true); 
            try {
                // Si el ID es temporal, solo lo eliminamos del frontend
              //  if (id.startsWith('temp-')) {
                    setFormData((prev) => ({
                        ...prev,
                        paragraphGroups: prev.paragraphGroups.filter((pg) => pg.id !== id),
                    }));
                    setIsDirty(true); 
                    setIsSaving(false); 
                    return;
               // }

                // Si tiene un ID real, lo eliminamos del backend
                const response = await fetch(`${API_BASE_URL}/materias/paragraph-groups/${id}`, { 
                    method: 'DELETE', 
                    headers: {
                        'X-Subdomain': currentSubdomain.current, 
                    },
                });
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(`Error al eliminar el grupo de párrafo: ${errorData.message || response.statusText}`);
                }

                setFormData((prev) => ({
                    ...prev,
                    paragraphGroups: prev.paragraphGroups.filter((pg) => pg.id !== id),
                }));
                setIsDirty(true); 
                alert("Grupo de párrafo eliminado exitosamente."); 
            } catch (err: any) {
                console.error("Error al eliminar el grupo de párrafo:", err); 
                setError(err.message || "Error al eliminar el grupo de párrafo. Inténtalo de nuevo."); 
            } finally {
                setIsSaving(false); 
            }
        }
    }, []);
    return (
        <div className="flex mb-20 md:mb-0"> {/* Contenedor principal con flex para side-by-side */}
            <SideBar selectedIndex={3} /> {/* El Sidebar debe tener su propio ancho definido internamente */}

            {/* Contenedor principal del formulario, ocupa el resto del espacio */}
            <main className="flex-1 ml-0 md:ml-64 p-4 sm:p-8">
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-6 sm:mb-8">Administrar Contenido de la Página de Materias</h1>

                {error && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                        <strong className="font-bold">¡Error!</strong>
                        <span className="block sm:inline"> {error}</span>
                    </div>
                )}

                <form onSubmit={handleSubmit} className="bg-white p-6 sm:p-8 rounded-lg shadow-md">
                    {/* Sección Título Principal */}
                    <section className="mb-6 sm:mb-8 border-b pb-6 sm:pb-8">
                        <h2 className="text-xl sm:text-2xl font-semibold text-gray-700 mb-4">Título Principal de la Página</h2>
                        <div className="mb-4">
                            <label htmlFor="headerTitle" className="block text-sm sm:text-base font-medium text-gray-700 mb-1">Título</label>
                            <input
                                type="text"
                                id="headerTitle"
                                name="headerTitle"
                                value={formData.headerTitle}
                                onChange={handleInputChange}
                                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                placeholder="Escribe el título principal de la página"
                            />
                        </div>
                    </section>

                    {/* Sección Grupos de Párrafos */}
                    <section>
                        <div className="flex justify-between items-center mb-6 sm:mb-8">
                            <h2 className="text-xl sm:text-2xl font-semibold text-gray-700">Grupos de Párrafos</h2>
                            <button
                                type="button"
                                onClick={addParagraphGroup}
                                className="px-4 sm:px-5 py-2 sm:py-2.5 bg-green-600 text-white font-semibold rounded-lg shadow hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 text-sm sm:text-base"
                            >
                                Añadir Grupo de Párrafo
                            </button>
                        </div>

                        {formData.paragraphGroups.length === 0 && (
                            <p className="text-gray-600 italic text-center py-4">No hay grupos de párrafos. Haz clic en "Añadir Grupo de Párrafo" para empezar.</p>
                        )}

                        {formData.paragraphGroups.map((pg, groupIndex) => (
                            <div key={pg.id} className="border border-gray-300 rounded-lg p-4 sm:p-6 mb-6 sm:mb-8 bg-gray-50 relative">
                                <button
                                    type="button"
                                    onClick={() => removeParagraphGroup(pg.id)}
                                    className="absolute top-2 right-2 px-3 py-1 bg-red-500 text-white rounded-full text-xs font-bold hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                                    aria-label="Eliminar grupo de párrafo"
                                >
                                    X
                                </button>

                                <h3 className="text-lg sm:text-xl font-semibold text-gray-700 mb-4 border-b pb-3">Grupo de Párrafo #{groupIndex + 1}</h3>

                                {/* Primer Párrafo (firstItem) */}
                                <div className="mb-6 sm:mb-8 p-4 sm:p-5 border border-blue-200 rounded-md bg-blue-50">
                                    <h4 className="text-md sm:text-lg font-semibold text-blue-800 mb-3">Primer Item del Grupo</h4>
                                    <div className="mb-3">
                                        <label htmlFor={`pg${groupIndex}-first-title`} className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Título</label>
                                        <input
                                            type="text"
                                            id={`pg${groupIndex}-first-title`}
                                            name={`pg${groupIndex}-first-title`}
                                            value={pg.firstItem.title}
                                            onChange={(e) => handleParagraphItemChange(groupIndex, 'firstItem', 'title', e.target.value)}
                                            className="mt-1 block w-full px-3 py-1.5 sm:py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                            placeholder="Título del primer párrafo"
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor={`pg${groupIndex}-first-content`} className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Contenido</label>
                                        <textarea
                                            id={`pg${groupIndex}-first-content`}
                                            name={`pg${groupIndex}-first-content`}
                                            value={pg.firstItem.content}
                                            onChange={(e) => handleParagraphItemChange(groupIndex, 'firstItem', 'content', e.target.value)}
                                            rows={3}
                                            className="mt-1 block w-full px-3 py-1.5 sm:py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                            placeholder="Contenido del primer párrafo"
                                        ></textarea>
                                    </div>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3 mb-3">
                                        <div>
                                            <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Color de Fondo (Inicio)</label>
                                            {/* Eliminada la prop className del ColorComboBox, ya que no la acepta. */}
                                            <ColorComboBox
                                                idPrefix={`pg${groupIndex}-first-gradientFrom`} // Asegura un ID único para los internos
                                                value={{ from: pg.firstItem.gradientFrom, to: pg.firstItem.gradientTo }} // Pasa el objeto completo
                                                onChange={(val) => handleParagraphItemChange(groupIndex, 'firstItem', 'gradientFrom', val)} // Pasa el objeto completo al handler
                                            />
                                        </div>
                                       
                                    </div>
                                    <div className="flex flex-wrap gap-x-6 gap-y-2 mt-4">
                                        <label htmlFor={`pg${groupIndex}-first-lineDecoration`} className="flex items-center text-xs sm:text-sm font-medium text-gray-700">
                                            <input
                                                type="checkbox"
                                                id={`pg${groupIndex}-first-lineDecoration`}
                                                name={`pg${groupIndex}-first-lineDecoration`}
                                                checked={pg.firstItem.lineDecoration}
                                                onChange={(e) => handleParagraphItemChange(groupIndex, 'firstItem', 'lineDecoration', e.target.checked)}
                                                className="mr-2 h-3.5 w-3.5 sm:h-4 sm:w-4 text-blue-600 border-gray-300 rounded"
                                            />
                                            Subrayado (Line Decoration)
                                        </label>
                                        <label htmlFor={`pg${groupIndex}-first-overLined`} className="flex items-center text-xs sm:text-sm font-medium text-gray-700">
                                            <input
                                                type="checkbox"
                                                id={`pg${groupIndex}-first-overLined`}
                                                name={`pg${groupIndex}-first-overLined`}
                                                checked={pg.firstItem.overLined}
                                                onChange={(e) => handleParagraphItemChange(groupIndex, 'firstItem', 'overLined', e.target.checked)}
                                                className="mr-2 h-3.5 w-3.5 sm:h-4 sm:w-4 text-blue-600 border-gray-300 rounded"
                                            />
                                            Título Superpuesto (OverLined)
                                        </label>
                                    </div>
                                </div>

                                {/* Segundo Item del Grupo (secondItemType, secondItemParagraph, secondItemCarouselItems) */}
                                <div className="p-4 sm:p-5 border border-purple-200 rounded-md bg-purple-50">
                                    <h4 className="text-md sm:text-lg font-semibold text-purple-800 mb-3">Segundo Item del Grupo</h4>
                                    <div className="mb-4">
                                        <label htmlFor={`pg${groupIndex}-secondItemType`} className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Tipo de Segundo Item:</label>
                                        <select
                                            id={`pg${groupIndex}-secondItemType`}
                                            name={`pg${groupIndex}-secondItemType`}
                                            value={pg.secondItemType}
                                            onChange={(e) => handleSecondItemTypeChange(groupIndex, e.target.value as 'none' | 'paragraph' | 'carousel')}
                                            className="mt-1 block w-full px-3 py-1.5 sm:py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500 text-sm sm:text-base"
                                        >
                                            <option value="none">Ninguno</option>
                                            <option value="paragraph">Párrafo</option>
                                            <option value="carousel">Carrusel</option>
                                        </select>
                                    </div>

                                    {pg.secondItemType === 'paragraph' && pg.secondItemParagraph && (
                                        <div className="mt-4 p-3 sm:p-4 border border-gray-300 rounded-md bg-white">
                                            <h5 className="text-md font-semibold text-gray-700 mb-3">Contenido del Segundo Párrafo</h5>
                                            <div className="mb-3">
                                                <label htmlFor={`pg${groupIndex}-second-title`} className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Título</label>
                                                <input
                                                    type="text"
                                                    id={`pg${groupIndex}-second-title`}
                                                    name={`pg${groupIndex}-second-title`}
                                                    value={pg.secondItemParagraph.title}
                                                    onChange={(e) => handleParagraphItemChange(groupIndex, 'secondItemParagraph', 'title', e.target.value)}
                                                    className="mt-1 block w-full px-3 py-1.5 sm:py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                                    placeholder="Título del segundo párrafo"
                                                />
                                            </div>
                                            <div className="mb-3">
                                                <label htmlFor={`pg${groupIndex}-second-content`} className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Contenido</label>
                                                <textarea
                                                    id={`pg${groupIndex}-second-content`}
                                                    name={`pg${groupIndex}-second-content`}
                                                    value={pg.secondItemParagraph.content}
                                                    onChange={(e) => handleParagraphItemChange(groupIndex, 'secondItemParagraph', 'content', e.target.value)}
                                                    rows={3}
                                                    className="mt-1 block w-full px-3 py-1.5 sm:py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                                    placeholder="Contenido del segundo párrafo"
                                                ></textarea>
                                            </div>
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3 mb-3">
                                                <div>
                                                    <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Color de Fondo (Inicio)</label>
                                                    {/* Eliminada la prop className del ColorComboBox, ya que no la acepta. */}
                                                    <ColorComboBox
                                                        idPrefix={`pg${groupIndex}-second-gradientFrom`}
                                                        value={{ from: pg.secondItemParagraph.gradientFrom, to: pg.secondItemParagraph.gradientTo }}
                                                        onChange={(val) => handleParagraphItemChange(groupIndex, 'secondItemParagraph', 'gradientFrom', val)}
                                                    />
                                                </div>
                                                
                                            </div>
                                            <div className="flex flex-wrap gap-x-6 gap-y-2 mt-4">
                                                <label htmlFor={`pg${groupIndex}-second-lineDecoration`} className="flex items-center text-xs sm:text-sm font-medium text-gray-700">
                                                    <input
                                                        type="checkbox"
                                                        id={`pg${groupIndex}-second-lineDecoration`}
                                                        name={`pg${groupIndex}-second-lineDecoration`}
                                                        checked={pg.secondItemParagraph.lineDecoration}
                                                        onChange={(e) => handleParagraphItemChange(groupIndex, 'secondItemParagraph', 'lineDecoration', e.target.checked)}
                                                        className="mr-2 h-3.5 w-3.5 sm:h-4 sm:w-4 text-blue-600 border-gray-300 rounded"
                                                    />
                                                    Subrayado (Line Decoration)
                                                </label>
                                                <label htmlFor={`pg${groupIndex}-second-overLined`} className="flex items-center text-xs sm:text-sm font-medium text-gray-700">
                                                    <input
                                                        type="checkbox"
                                                        id={`pg${groupIndex}-second-overLined`}
                                                        name={`pg${groupIndex}-second-overLined`}
                                                        checked={pg.secondItemParagraph.overLined}
                                                        onChange={(e) => handleParagraphItemChange(groupIndex, 'secondItemParagraph', 'overLined', e.target.checked)}
                                                        className="mr-2 h-3.5 w-3.5 sm:h-4 sm:w-4 text-blue-600 border-gray-300 rounded"
                                                    />
                                                    Título Superpuesto (OverLined)
                                                </label>
                                            </div>
                                        </div>
                                    )}

                                    {pg.secondItemType === 'carousel' && (
                                        <div className="mt-4 p-3 sm:p-4 border border-gray-300 rounded-md bg-white">
                                            <h5 className="text-md font-semibold text-gray-700 mb-3">Items del Carrusel</h5>
                                            <button
                                                type="button"
                                                onClick={() => addCarouselItem(pg.id, "")} // Deja la URL vacía para que el usuario la introduzca
                                                className="mb-3 px-3 sm:px-4 py-1.5 sm:py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 text-xs sm:text-sm"
                                            >
                                                Añadir Item a Carrusel
                                            </button>
                                            {(pg.secondItemCarouselItems || []).map((item, itemIndex) => (
                                                <div key={item.id} className="flex items-center gap-2 sm:gap-3 mb-2">
                                                    <input
                                                        type="text"
                                                        value={item.url}
                                                        onChange={(e) => setFormData((prev) => {
                                                            const updatedGroups = prev.paragraphGroups.map((group) => {
                                                                if (group.id === pg.id && group.secondItemCarouselItems) {
                                                                    const updatedItems = group.secondItemCarouselItems.map((ci) =>
                                                                        ci.id === item.id ? { ...ci, url: e.target.value } : ci
                                                                    );
                                                                    return { ...group, secondItemCarouselItems: updatedItems };
                                                                }
                                                                return group;
                                                            });
                                                            setIsDirty(true);
                                                            return { ...prev, paragraphGroups: updatedGroups };
                                                        })}
                                                        className="flex-1 px-2 py-1 sm:py-1.5 border border-gray-300 rounded-md shadow-sm text-xs sm:text-sm"
                                                        placeholder="URL del carrusel (imagen o video)"
                                                    />
                                                    <button type="button" onClick={() => removeCarouselItem(pg.id, item.id)} className="px-1.5 sm:px-2 py-0.5 sm:py-1 bg-red-500 text-white rounded hover:bg-red-600 text-2xs sm:text-xs">X</button>
                                                </div>
                                            ))}
                                            {(!pg.secondItemCarouselItems || pg.secondItemCarouselItems.length === 0) && <p className="text-2xs sm:text-xs text-gray-500 mt-1.5 sm:mt-2">No hay items en el carrusel.</p>}
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </section>

                    <div className="mt-6 sm:mt-10 flex justify-end">
                        <button
                            type="submit"
                            disabled={!isDirty || isSaving} // Deshabilitar si no hay cambios o está guardando
                            className="px-6 sm:px-8 py-2 sm:py-3 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 text-sm sm:text-base"
                        >
                            {isSaving ? "Guardando..." : "Guardar Cambios"}
                        </button>
                    </div>
                </form>
            </main>
        </div>
    );
}

export default MateriasPage;