/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import SideBar from "@/components/SideBar/SideBar";
import { useRouter } from "next/navigation";
import React, { useState, useEffect, FormEvent, useCallback } from "react";

// Interfaces para el frontend
interface SubdomainFormData {
    id: string; // ID de la base de datos
    nombre: string; // Nombre del subdominio
}

// Interfaces para los DTOs del backend (lo que el API espera/devuelve)
interface BackendSubdomainDto {
    id: string;
    nombre: string;
    // 'isPublic' ya no es necesario aquí si se elimina del frontend
}

const API_BASE_URL = "http://localhost:3001"; // Asegúrate de que esta URL sea correcta para tu backend

export default function SubdominiosPage() {
    const router = useRouter(); // Inicializa el router
    const [newSubdomainName, setNewSubdomainName] = useState("");
    const [subdomains, setSubdomains] = useState<SubdomainFormData[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [isSaving, setIsSaving] = useState<boolean>(false); // Para el botón de añadir y las operaciones
    const [error, setError] = useState<string | null>(null);
    const [isBaseDomain, setIsBaseDomain] = useState<boolean>(false); // Nuevo estado para controlar si estamos en el dominio base

    useEffect(() => {
        const token = localStorage.getItem('jwt_token');
        if (!token) {
            console.warn("HomeCMSPage: No JWT token found. Redirecting to login.");
            router.push('/admin');
        } else {
            console.log("HomeCMSPage: Token found. Proceeding to load data.");
        }

        // *** Lógica para identificar el subdominio ***
        // Obtener el hostname de la URL actual
        const hostname = window.location.hostname;
        // La lógica es: si el hostname es 'localhost' O no contiene puntos (es decir, no es un subdominio como 'marketing.localhost'),
        // entonces estamos en el dominio base.
        // Si el hostname es 'localhost', entonces 'localhost:3000' es el dominio base.
        // Si tienes un dominio real, como 'tudominio.com', entonces 'tudominio.com' sería el base.
        // Un subdominio sería 'marketing.tudominio.com'.
        // Aquí asumimos que si no hay puntos en el hostname (ej. 'localhost') o si es 'localhost',
        // estamos en el dominio base.
        const isCurrentlyBaseDomain = hostname === 'localhost' || hostname.split('.').length <= 1;
        setIsBaseDomain(isCurrentlyBaseDomain);
        // ********************************************

    }, [router]);

    // Función para obtener los subdominios del backend
    const fetchSubdomains = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(`${API_BASE_URL}/subdomains`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data: BackendSubdomainDto[] = await response.json();
            const processedData: SubdomainFormData[] = data.map(sd => ({
                id: sd.id,
                nombre: sd.nombre,
            }));
            setSubdomains(processedData);
        } catch (err: any) {
            console.error("Error fetching subdomains:", err);
            setError("No se pudieron cargar los subdominios. Intente de nuevo más tarde.");
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchSubdomains();
    }, [fetchSubdomains]);

    // Manejar el envío del formulario para añadir un nuevo subdominio
    const handleAddSubdomain = async (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setError(null);

        // Bloquear si no estamos en el dominio base
        if (!isBaseDomain) {
            setError("No puedes añadir subdominios desde un subdominio existente. Por favor, accede desde el dominio principal.");
            return;
        }

        if (!newSubdomainName.trim()) {
            setError("El nombre del subdominio no puede estar vacío.");
            return;
        }
        if (subdomains.some(sd => sd.nombre.toLowerCase() === newSubdomainName.trim().toLowerCase())) {
            setError("Ya existe un subdominio con este nombre.");
            return;
        }

        setIsSaving(true);
        try {
            const response = await fetch(`${API_BASE_URL}/subdomains`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ nombre: newSubdomainName.trim() }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }

            setNewSubdomainName('');
            await fetchSubdomains();
            alert("Subdominio añadido exitosamente!");
        } catch (err: any) {
            console.error("Error adding subdomain:", err);
            setError(`Error al añadir el subdominio: ${err.message || 'Error desconocido'}`);
            alert(`Error al añadir el subdominio: ${err.message || 'Error desconocido'}`);
        } finally {
            setIsSaving(false);
        }
    };

    // Manejar la eliminación de un subdominio
    const handleDeleteSubdomain = async (subdomainId: string) => {
        // Bloquear si no estamos en el dominio base
        if (!isBaseDomain) {
            setError("No puedes eliminar subdominios desde un subdominio existente. Por favor, accede desde el dominio principal.");
            return;
        }

        if (!confirm("¿Estás seguro de que quieres eliminar este subdominio? Esta acción es irreversible.")) {
            return;
        }

        setIsSaving(true);
        setError(null);
        try {
            const response = await fetch(`${API_BASE_URL}/subdomains/${subdomainId}`, {
                method: 'DELETE',
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }

            await fetchSubdomains();
            alert("Subdominio eliminado exitosamente!");
        } catch (err: any) {
            console.error("Error deleting subdomain:", err);
            setError(`Error al eliminar el subdominio: ${err.message || 'Error desconocido'}`);
            alert(`Error al eliminar el subdominio: ${err.message || 'Error desconocido'}`);
        } finally {
            setIsSaving(false);
        }
    };

    if (isLoading) {
        return (
            <div className="flex">
                <SideBar selectedIndex={0} /> {}
                <main className="flex-1 ml-0 md:ml-64 p-4 sm:p-8">
                    <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-6">Cargando Subdominios...</h1>
                    <p className="text-gray-600">Por favor, espera.</p>
                </main>
            </div>
        );
    }

    return (
        <div className="flex mb-20 md:mb-0">
            <SideBar selectedIndex={0} /> {}
            <main className="flex-1 ml-0 md:ml-64 p-4 sm:p-8 ">
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-6">Gestión de Subdominios</h1>

                {error && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                        <strong className="font-bold">¡Error!</strong>
                        <span className="block sm:inline"> {error}</span>
                    </div>
                )}

                {/* Formulario para añadir nuevo subdominio */}
                <section className="bg-white p-4 sm:p-6 rounded-lg shadow-md mb-8">
                    <h2 className="text-xl sm:text-2xl font-semibold text-gray-700 mb-4">Añadir Nuevo Subdominio</h2>
                    {!isBaseDomain && (
                        <p className="text-orange-600 mb-4">
                            Solo puedes añadir subdominios desde el dominio principal. Contacta a su administrador para añadir un subdominio.
                        </p>
                    )}
                    <form onSubmit={handleAddSubdomain} className="space-y-4">
                        <div>
                            <label htmlFor="newSubdomainName" className="block text-sm font-medium text-gray-700">Nombre del Subdominio:</label>
                            <input
                                type="text"
                                id="newSubdomainName"
                                value={newSubdomainName}
                                onChange={(e) => setNewSubdomainName(e.target.value)}
                                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm sm:text-base"
                                placeholder="ej. mi-subdominio"
                                required
                                disabled={!isBaseDomain || isSaving} // Deshabilita si no es el dominio base
                            />
                        </div>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-md shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 text-sm sm:text-base"
                            disabled={isSaving || !isBaseDomain} // Deshabilita si no es el dominio base
                        >
                            {isSaving ? "Añadiendo..." : "Añadir Subdominio"}
                        </button>
                    </form>
                </section>

                {/* Lista de subdominios existentes */}
                <section className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
                    <h2 className="text-xl sm:text-2xl font-semibold text-gray-700 mb-4">Subdominios Existentes</h2>
                    {!isBaseDomain && (
                        <p className="text-orange-600 mb-4">
                            Solo puedes eliminar subdominios desde el dominio principal. Contacte al administrador para añadir un subdominio.
                        </p>
                    )}
                    {subdomains.length === 0 ? (
                        <p className="text-gray-500 text-sm sm:text-base">No hay subdominios creados.</p>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {subdomains.map((subdomain) => (
                                <div
                                    key={subdomain.id}
                                    className="border border-gray-200 rounded-lg p-4 flex flex-col justify-between shadow-sm bg-gray-50"
                                >
                                    <div className="mb-3">
                                        <span className="block text-gray-800 font-medium text-base break-all mb-1">
                                            {subdomain.nombre}
                                        </span>
                                    </div>
                                    <div className="flex gap-2">
                                        <button
                                            onClick={() => handleDeleteSubdomain(subdomain.id)}
                                            disabled={isSaving || !isBaseDomain} // Deshabilita si no es el dominio base
                                            className={`flex-1 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 transition-colors ${
                                                isBaseDomain
                                                    ? 'bg-red-500 text-white hover:bg-red-600 focus:ring-red-500'
                                                    : 'bg-gray-300 text-gray-600 cursor-not-allowed'
                                            }`}
                                        >
                                            Eliminar
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </section>
            </main>
        </div>
    );
}