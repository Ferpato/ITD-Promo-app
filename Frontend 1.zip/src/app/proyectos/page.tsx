/* eslint-disable react/no-unescaped-entities */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React, { useState, useEffect } from 'react';
import NaviBar from "@/components/NaviBar/NaviBar";
import { NaviBarClass } from "@/interfaces/NaviBar/NaviBar-class";
import HeaderTitle from "@/components/HeaderTitle/HeaderTitle";
import SectionTitle from "@/components/SectionTitle/SectionTitle";
import Comment from "@/components/Comment/Comment";
import CommentSection from "@/components/CommentSection/CommentSection";
import FooterSection from "@/components/FooterSection/FooterSection";
import ContentCarousel from "@/components/ContentCarousel/ContentCarousel";
import HyperLink from "@/components/HyperLink/HyperLink";
import PageLogo from "@/components/PageLogo/PageLogo";

// --- Data Structures from CMS Frontend Form ---
interface CarouselMediaItemFormData {
    id: string;
    url: string;
}

interface CommentFormData {
    title: string;
    content: string;
    gradientFrom: string;
    gradientTo: string;
}

interface CarouselFormData {
    items: CarouselMediaItemFormData[];
}

type CommentSectionItemType = 'comment' | 'carousel';

interface CommentSectionItemFormData {
    id: string;
    type: CommentSectionItemType;
    commentData?: CommentFormData;
    carouselData?: CarouselFormData;
}

interface SectionFormData {
    id: string;
    text: string;
    icon: string | null;
    color1: string; // This will be the bgColor
    color2: string; // This will be the gradientTo
    subdominio?: string; // Asegúrate de que esta propiedad esté en tus interfaces y datos
    items: CommentSectionItemFormData[];
}

interface ProyectosPageFormData {
    headerTitle: string;
    sections: SectionFormData[];
}

// Helper to get the current subdomain - REVISED LOGIC FOR CLIENT-SIDE ACCURACY
// src/app/proyectos/page.tsx
// ... (imports y interfaces existentes) ...

const getSubdomainFromWindow = () => {
    if (typeof window === 'undefined') {
        return 'default_ssr'; // Valor distintivo para cuando se renderiza en el servidor
    }
    const hostname = window.location.hostname;
    // Elimina el puerto si existe (ej: "a.localhost:3000" -> "a.localhost")
    const hostWithoutPort = hostname.split(':')[0]; 
    const parts = hostWithoutPort.split('.');

    // Lógica para subdominios en localhost (ej: a.localhost)
    if (hostWithoutPort.endsWith('.localhost')) {
        if (parts.length > 1 && parts[0] !== 'www' && parts[0] !== 'localhost') {
            return parts[0]; // Retorna 'a' de "a.localhost"
        }
        return 'default'; // Para "localhost" o "www.localhost"
    }

    // Lógica para subdominios en dominios reales (ej: sub.midominio.com, www.sub.midominio.com)
    if (parts.length >= 3) {
        if (parts[0] !== 'www') {
            return parts[0]; // Retorna 'sub' de "sub.midominio.com"
        }
        if (parts.length >= 4 && parts[0] === 'www') {
            return parts[1]; // Retorna 'sub' de "www.sub.midominio.com"
        }
    }

    return 'default'; // Para "midominio.com" o "www.midominio.com"
};

// ... (el resto de tu código, incluyendo los dos useEffects que ya implementaste) ...


const API_BASE_URL = "http://localhost:3001"; // Consistent with your CMS code

export default function Proyectos() {
    const [pageData, setPageData] = useState<ProyectosPageFormData | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    // Inicializamos currentSubdomain con un valor que indica que aún no se ha determinado en el cliente
    const [currentSubdomain, setCurrentSubdomain] = useState<string>('initial_client_check'); 

    // Efecto 1: Se ejecuta SOLAMENTE en el cliente para determinar el subdominio real
    useEffect(() => {
        setCurrentSubdomain(getSubdomainFromWindow());
    }, []); // El array de dependencias vacío asegura que se ejecuta una sola vez en el montaje del cliente

    // Efecto 2: Se ejecuta cuando currentSubdomain cambia de su valor inicial o cuando cambia a un subdominio diferente
    useEffect(() => {
        // Evitamos hacer la petición si el subdominio aún está en su estado inicial (SSR)
        if (currentSubdomain === 'initial_client_check' || currentSubdomain === 'default_ssr') {
            return; 
        }

        let isMounted = true;

        const fetchData = async () => {
            setLoading(true);
            setError(null);
            try {
                // LOG PARA DEPURACIÓN: Verifica qué subdominio se está enviando
                console.log(`Fetching data for subdomain: '${currentSubdomain}'`);

                const response = await fetch(`${API_BASE_URL}/admin/dashboard/proyectos`, {
                    headers: {
                        'X-Subdomain': currentSubdomain, // <-- Asegúrate que esta cabecera esté aquí
                    },
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data: ProyectosPageFormData = await response.json(); 
                
                if (isMounted) {
                    setPageData(data);
                }
            } catch (err: any) {
                if (isMounted) {
                    console.error("Error fetching data:", err);
                    setError("No se pudieron cargar los datos de la página. Intente de nuevo más tarde.");
                }
            } finally {
                if (isMounted) {
                    setLoading(false);
                }
            }
        };

        fetchData();

        return () => {
            isMounted = false;
        };
    }, [currentSubdomain]); // Este useEffect depende de `currentSubdomain` y se re-ejecuta cuando cambia

    // Mostramos un estado de carga mientras el subdominio se está determinando o los datos se están cargando
    if (loading || currentSubdomain === 'initial_client_check' || currentSubdomain === 'default_ssr') {
        return <div className="min-h-screen flex items-center justify-center bg-gray-100 text-gray-700">Cargando contenido de Proyectos...</div>;
    }

    if (error) {
        return <div className="min-h-screen flex items-center justify-center bg-red-100 text-red-700">Error al cargar el contenido: {error}</div>;
    }

    // Si pageData es null, o no tiene secciones relevantes para el subdominio, mostramos el mensaje de no encontrado
    const hasRelevantSections = pageData?.sections.some(s => s.subdominio === currentSubdomain);

    if (!pageData || !hasRelevantSections) { // Cambiado para verificar si hay secciones relevantes
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-100 text-gray-700">
                No se encontró contenido para este subdominio ('{currentSubdomain}').
            </div>
        );
    }

    // Filtrar secciones por el subdominio actual para renderizar solo las relevantes
    const relevantSections = pageData.sections.filter(
        (section) => section.subdominio === currentSubdomain
    );

    const buttonConfigs = [
        {
            text: "Quiero ser guinda",
            route: "https://www.itdurango.edu.mx/aspirantes/",
            icon: "/assets/svg/external-link.svg",
            gradientFrom: "from-guinda",
            gradientTo: "to-vino",
            underlined: true
        }, {
            text: "Reiniciar el tour",
            route: "/",
            icon: "/assets/svg/reload.svg",
            gradientFrom: "from-blue",
            gradientTo: "to-blue",
            underlined: false
        },
    ];

    return (
        <div className="bg-[url('/assets/svg/bg/bg-mob.svg')] md:lg:bg-[url('/assets/svg/bg/bg-desk-proyectos.svg')]
         bg-size-[width:100%] min-h-screen overflow-y-hidden pb-32">
            <PageLogo />
            <NaviBar selectedIndex={3} titles={NaviBarClass.titles} routes={NaviBarClass.routes}
                icons={NaviBarClass.icons} />

            <HeaderTitle>
                {pageData.headerTitle}
            </HeaderTitle>

            {/* Mapear sobre las secciones RELEVANTES (filtradas por subdominio) */}
            {relevantSections.map((section, sectionIndex) => (
                <React.Fragment key={section.id}>
                    <SectionTitle 
                        icon={section.icon || " "} // Pass undefined if icon is null
                        bgColor={section.color1} 
                        gradientTo={section.color2}>
                        {section.text}
                    </SectionTitle>
                    <CommentSection>
                        {section.items.map((item) => (
                            <React.Fragment key={item.id}>
                                {item.type === 'comment' && item.commentData && (
                                    <Comment
                                        title={item.commentData.title}
                                        gradientFrom={item.commentData.gradientFrom}
                                        gradientTo={item.commentData.gradientTo}
                                    >
                                        {item.commentData.content}
                                    </Comment>
                                )}
                                {item.type === 'carousel' && item.carouselData && item.carouselData.items.length > 0 && (
                                    <div className="mt-4">
                                        <ContentCarousel items={item.carouselData.items.map(media => media.url)} />
                                    </div>
                                )}
                            </React.Fragment>
                        ))}
                    </CommentSection>
                </React.Fragment>
            ))}

            <div className="flex flex-col ml-10 mr-2 lg:mr-0 lg:ml-16 mt-10 gap-10">
                <FooterSection text={"¿Qué estás esperando?"} buttonConfigs={buttonConfigs} />
            </div>
            <HyperLink link="https://www.itdurango.edu.mx/" />
        </div>
    );
}