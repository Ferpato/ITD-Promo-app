'use client';

import React, { useState, useEffect, useCallback } from 'react';
import NaviBar from "@/components/NaviBar/NaviBar";
import { NaviBarClass } from "@/interfaces/NaviBar/NaviBar-class";
import HeaderTitle from "@/components/HeaderTitle/HeaderTitle";
import HyperLink from "@/components/HyperLink/HyperLink";
import Paragraph from "@/components/Paragraph/Paragraph";
import FooterSection from "@/components/FooterSection/FooterSection";
import Image from "next/image";
import PageLogo from "@/components/PageLogo/PageLogo";

// Definiciones de tipos (asegúrate de que coincidan con tu backend)
interface TituloPagina {
  id?: number;
  numPagina: number;
  titulo: string;
  subdominio: string;
}

interface ParrafoOferta {
  id?: number;
  Titulo: string;
  Contenido: string;
  Icono?: string;
  Color1?: string;
  Color2?: string;
  DecoracionLinea?: boolean;
  TituloSuperpuesto?: boolean;
  subdominio?: string;
}

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:3001';

const getSubdomainFromWindow = () => {
  if (typeof window === 'undefined') {
    return 'default';
  }
  const hostname = window.location.hostname;
  const parts = hostname.split('.');
  let detectedSubdomain = 'default';

  if (parts.length === 2 && parts[1] === 'localhost' && parts[0] !== 'www') {
      detectedSubdomain = parts[0];
  } else if (parts.length > 2 && parts[0] !== 'www') {
      detectedSubdomain = parts[0];
  }
  return detectedSubdomain;
};


export default function Oferta() {
    const [headerTitle, setHeaderTitle] = useState<string>('');
    const [paragraphs, setParagraphs] = useState<ParrafoOferta[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const loadOfertaData = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        const currentSubdomain = getSubdomainFromWindow(); // Subdominio de la URL actual

        try {
            // Intentar cargar datos para el subdominio actual
            await fetchAndSetContent(currentSubdomain);

        } catch (err) {
            console.error(`Error al cargar datos para ${currentSubdomain}:`, err);
            // Si falla la carga del subdominio actual, intentar cargar el 'default'
            console.log(`Intentando cargar contenido 'default' como fallback.`);
            try {
                await fetchAndSetContent('default'); // <--- Intentar con el subdominio 'default'
            } catch (defaultErr) {
                console.error('Error al cargar contenido default:', defaultErr);
                setError('No se pudo cargar la información para este subdominio ni la predeterminada.');
                setIsLoading(false);
            }
        } finally {
            // La bandera isLoading se manejará dentro de fetchAndSetContent o el catch final
        }
    }, []);

    // Función auxiliar para realizar el fetch y establecer el estado
    const fetchAndSetContent = async (subdomain: string) => {
        setIsLoading(true); // Restablecer isLoading para cada intento de fetch

        // 1. Cargar Título Principal (numPagina 0)
        const titleResponse = await fetch(`${API_BASE_URL}/admin/dashboard/titulos/0`, {
            headers: {
                'X-Subdomain': subdomain, // Envía el subdominio (actual o default)
            },
        });

        if (!titleResponse.ok) {
            const errorData = await titleResponse.json();
            console.error(`Error al cargar título para subdominio "${subdomain}":`, errorData);
            // Si el backend devuelve 404 o similar y no crea el default, throw para el catch superior
            throw new Error(`Título no encontrado o error en backend para ${subdomain}`);
        } else {
            const titleData: TituloPagina = await titleResponse.json();
            setHeaderTitle(titleData.titulo);
        }

        // 2. Cargar Párrafos de Oferta
        const paragraphsResponse = await fetch(`${API_BASE_URL}/admin/dashboard/oferta`, {
            headers: {
                'X-Subdomain': subdomain, // Envía el subdominio (actual o default)
            },
        });

        if (!paragraphsResponse.ok) {
            const errorData = await paragraphsResponse.json();
            console.error(`Error al cargar párrafos para subdominio "${subdomain}":`, errorData);
            // Si el backend devuelve 404 o similar, throw para el catch superior
            throw new Error(`Párrafos no encontrados o error en backend para ${subdomain}`);
        } else {
            const paragraphsData: ParrafoOferta[] = await paragraphsResponse.json();
            setParagraphs(paragraphsData);
        }
        setIsLoading(false); // Solo se desactiva isLoading si el fetch fue exitoso
    };


    useEffect(() => {
        loadOfertaData();
    }, [loadOfertaData]);


    const buttonConfigs = [{
        text: "Ir a materias",
        route: "/materias",
        icon: "/assets/svg/arrow-right.svg",
        gradientFrom: "from-blue",
        gradientTo: "to-blue",
        underlined: true
    },
    {
        text: "Quiero ser guinda",
        route: "https://www.itdurango.edu.mx/aspirantes/",
        icon: "/assets/svg/external-link.svg",
        gradientFrom: "from-guinda",
        gradientTo: "to-vino",
        underlined: false
    }];

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <p>Cargando información de oferta...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex justify-center items-center h-screen text-red-600">
                <p>{error}</p>
            </div>
        );
    }

    return (
        <div className="bg-[url('/assets/svg/bg/bg-mob.svg')] md:lg:bg-[url('/assets/svg/bg/bg-desk-oferta.svg')]
         bg-size-[width:100%] min-h-screen overflow-y-hidden pb-32">
            <PageLogo></PageLogo>
            <NaviBar selectedIndex={1} titles={NaviBarClass.titles} routes={NaviBarClass.routes}
                icons={NaviBarClass.icons}></NaviBar>

            <HeaderTitle>{headerTitle}</HeaderTitle>

            <div className="flex flex-col ml-10 mr-2 lg:ml-40 mt-10 lg:max-w-[70%] ">
                <div className="relative -ml-3 w-22 h-24 self-stretch">
                    <Image src={"/assets/svg/more-vertical.svg"} alt={"icono"} fill></Image>
                </div>

                {paragraphs.length > 0 ? (
                    paragraphs.map((paragraph, index) => (
                        <Paragraph
                            key={paragraph.id || index}
                            title={paragraph.Titulo}
                            gradientFrom={paragraph.Color1 || 'from-gray-300'}
                            gradientTo={paragraph.Color2 || 'to-gray-500'}
                            icon={paragraph.Icono || '/assets/svg/info-group.svg'}
                            lineDecoration={paragraph.DecoracionLinea || false}
                            overLined={paragraph.TituloSuperpuesto || false}
                        >
                            {paragraph.Contenido}
                        </Paragraph>
                    ))
                ) : (
                    // Este mensaje solo se mostraría si incluso el fallback a 'default' no encuentra contenido
                    <p className="text-center text-gray-500">No hay contenido de oferta disponible.</p>
                )}

                <FooterSection text="¿Quieres saber más?"
                    buttonConfigs={buttonConfigs}></FooterSection>
            </div>
            <HyperLink link="https://www.itdurango.edu.mx/"></HyperLink>
        </div>
    );
}