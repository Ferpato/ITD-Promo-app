/* eslint-disable @typescript-eslint/no-explicit-any */
"use client"; // Asegúrate de que esta línea esté al inicio

import NaviBar from "@/components/NaviBar/NaviBar";
import { NaviBarClass } from "@/interfaces/NaviBar/NaviBar-class";
import HeaderTitle from "@/components/HeaderTitle/HeaderTitle";
import Image from "next/image";
import Paragraph from "@/components/Paragraph/Paragraph";
import ParagraphGroup from "@/components/ParagraphGroup/ParagraphGroup";
import FooterSection from "@/components/FooterSection/FooterSection";
import ContentCarousel from "@/components/ContentCarousel/ContentCarousel";
import HyperLink from "@/components/HyperLink/HyperLink";
import PageLogo from "@/components/PageLogo/PageLogo";
import React, { useState, useEffect } from "react";


// --- Interfaces de datos (Actualizadas para coincidir con el JSON de tu Backend) ---

// Interfaz para la estructura de un párrafo aplanado (firstItem o secondItemParagraph)
// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface FetchedParagraphItemData {
    title: string;
    content: string;
    iconPath: string | null; // Puede ser null si no hay icono
    gradientFrom: string;
    gradientTo: string;
    lineDecoration: boolean;
    overLined: boolean;
}

// Interfaz para la estructura completa de un grupo de párrafos aplanado del backend
interface FetchedParagraphGroupConfig {
    id: number; // El ID es number en tu JSON
    subdominio: string;

    // Campos para el firstItem
    firstItemTitle: string;
    firstItemContent: string;
    firstItemIconPath: string | null;
    firstItemGradientFrom: string;
    firstItemGradientTo: string;
    firstItemLineDecoration: boolean;
    firstItemOverLined: boolean;

    // Campos para el secondItem (si secondItemType es 'paragraph')
    // Nota: Estos pueden ser null si secondItemType no es 'paragraph'
    secondItemTitle: string | null;
    secondItemContent: string | null;
    secondItemIconPath: string | null;
    secondItemGradientFrom: string | null;
    secondItemGradientTo: string | null;
    secondItemLineDecoration: boolean;
    secondItemOverLined: boolean;

    secondItemType: 'none' | 'paragraph' | 'carousel';
    carouselUrls: string[] | null; // Array de URLs para el carrusel, o null
}

// Interfaz para el DTO que recibimos del backend para el título principal
interface TituloData {
    numPagina: number;
    titulo: string;
    subdominio: string;
}

// --- Constantes ---
const API_BASE_URL = "http://localhost:3001"; // Asegúrate de que esta URL base sea correcta
const PAGE_NUM = 1; // ID de página para "Materias"

// --- Función para obtener el subdominio de la URL del navegador ---
const getSubdomainFromWindow = (): string => {
    if (typeof window !== 'undefined') {
        const hostname = window.location.hostname;
        const parts = hostname.split('.');
        if (parts.length > 2) {
            if (parts[0] === 'www') {
                return parts[1];
            }
            return parts[0];
        }
    }
    return 'default'; // Fallback
};

export default function Materias() {
     
    // --- ESTADO PARA EL TÍTULO (SIN CAMBIOS) ---
    const [headerTitle, setHeaderTitle] = useState("Cargando título...");
    const [loadingTitle, setLoadingTitle] = useState(true);
    const [errorTitle, setErrorTitle] = useState<string | null>(null);

    // --- ESTADOS PARA LOS GRUPOS DE PÁRRAFOS (Actualizado el tipo de `paragraphGroups`) ---
    const [paragraphGroups, setParagraphGroups] = useState<FetchedParagraphGroupConfig[]>([]);
    const [loadingGroups, setLoadingGroups] = useState(true);
    const [errorGroups, setErrorGroups] = useState<string | null>(null);

    const currentSubdomain = getSubdomainFromWindow();

    // --- EFECTO PARA CARGAR EL TÍTULO (SIN CAMBIOS) ---
    useEffect(() => {
        let isMounted = true;

        const fetchHeaderTitle = async () => {
            setLoadingTitle(true);
            setErrorTitle(null);
            try {
                const response = await fetch(`${API_BASE_URL}/admin/dashboard/titulos/${PAGE_NUM}`, {
                    headers: {
                        'X-Subdomain': currentSubdomain,
                    },
                });

                if (!response.ok) {
                    if (response.status === 404) {
                        if (isMounted) {
                            setHeaderTitle("Título no disponible para este subdominio.");
                        }
                        return;
                    }
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data: TituloData = await response.json();
                if (isMounted) {
                    setHeaderTitle(data.titulo);
                }
            } catch (err: any) {
                if (isMounted) {
                    console.error("Error al cargar el título de Materias:", err);
                    setErrorTitle("Error al cargar el título. Intente de nuevo.");
                    setHeaderTitle("Error al cargar el título.");
                }
            } finally {
                if (isMounted) {
                    setLoadingTitle(false);
                }
            }
        };

        fetchHeaderTitle();

        return () => {
            isMounted = false;
        };
    }, [currentSubdomain]); // Recargar el título si el subdominio cambia

    // --- EFECTO PARA CARGAR LOS GRUPOS DE PÁRRAFOS (Asegura el tipo de la respuesta) ---
    useEffect(() => {
        let isMounted = true;

        const fetchParagraphGroups = async () => {
            setLoadingGroups(true);
            setErrorGroups(null);
            try {
                const response = await fetch(`${API_BASE_URL}/materias/paragraph-groups`, {
                    headers: {
                        // Aunque tu decorador @GetSubdomain debería funcionar,
                        // puedes añadir 'X-Subdomain' explícitamente aquí si es necesario
                        // para asegurar que el backend reciba el subdominio correcto.
                        // 'X-Subdomain': currentSubdomain,
                    },
                });

                if (!response.ok) {
                    if (response.status === 404) {
                        if (isMounted) {
                            setParagraphGroups([]); // No hay grupos, no es un error fatal
                            console.warn(`No se encontraron grupos de párrafos para el subdominio: ${currentSubdomain}`);
                        }
                        return;
                    }
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                // El tipo de `data` debe coincidir con `FetchedParagraphGroupConfig[]`
                const data: FetchedParagraphGroupConfig[] = await response.json();
                if (isMounted) {
                    setParagraphGroups(data);
                }
            } catch (err: any) {
                if (isMounted) {
                    console.error("Error al cargar los grupos de párrafos:", err);
                    setErrorGroups("Error al cargar el contenido. Intente de nuevo.");
                    setParagraphGroups([]); // Vaciar en caso de error para no mostrar datos parciales/antiguos
                }
            } finally {
                if (isMounted) {
                    setLoadingGroups(false);
                }
            }
        };

        fetchParagraphGroups();

        return () => {
            isMounted = false;
        };
    }, [currentSubdomain]); // Recargar si el subdominio cambia

    // --- Configuraciones de botones estáticas (SIN CAMBIOS) ---
    const buttonConfigs = [{
        text: "Ir a proyectos",
        route: "/proyectos",
        icon: "/assets/svg/arrow-right.svg",
        gradientFrom: "from-blue",
        gradientTo: "to-blue",
        underlined: true
    },
    {
        text: "Quiero ser guinda",
        route: "https://www.itdurango.edu.mx/aspirantes/",
        icon: "/assets/svg/external-link.svg",
        gradientFrom: "from-guinda",
        gradientTo: "to-vino",
        underlined: false
    }];

    return (
        <div className="bg-[url('/assets/svg/bg/bg-mob.svg')] md:lg:bg-[url('/assets/svg/bg/bg-desk-materias.svg')]
         bg-size-[width:100%] min-h-screen overflow-y-hidden pb-32">
            <PageLogo />
            <NaviBar selectedIndex={2} titles={NaviBarClass.titles} routes={NaviBarClass.routes}
                icons={NaviBarClass.icons} />
            <HeaderTitle>
                {loadingTitle ? "Cargando título..." : errorTitle ? errorTitle : headerTitle}
            </HeaderTitle>
            <div className="flex flex-col ml-10 mr-2 lg:ml-40 mt-10 gap-10">
                <div className="relative -ml-3 w-22 h-22 self-stretch">
                    <Image src={"/assets/svg/more-vertical.svg"} alt={"icono"} fill />
                </div>

                {/* Mensajes de carga y error para los grupos de párrafos */}
                {loadingGroups && <p>Cargando contenido dinámico...</p>}
                {errorGroups && <p className="text-red-500">{errorGroups}</p>}

                {/* Mensaje si no hay contenido y no está cargando ni hay error */}
                {!loadingGroups && !errorGroups && paragraphGroups.length === 0 && (
                    <p>No hay contenido disponible para este subdominio.</p>
                )}

                {/* Renderizado dinámico de los grupos de párrafos */}
                {!loadingGroups && !errorGroups && paragraphGroups.length > 0 && (
                    paragraphGroups.map((pg) => (
                        <ParagraphGroup key={pg.id} hasCarousel={pg.secondItemType === 'carousel'}>
                            {/* Primer párrafo del grupo */}
                            <Paragraph
                                title={pg.firstItemTitle}
                                gradientFrom={pg.firstItemGradientFrom}
                                gradientTo={pg.firstItemGradientTo}
                                icon={pg.firstItemIconPath || undefined} // Usa `undefined` si es `null` o `""`
                                lineDecoration={pg.firstItemLineDecoration}
                                overLined={pg.firstItemOverLined}
                            >
                                {/* PASA EL CONTENIDO COMO CHILDREN AQUÍ */}
                                {pg.firstItemContent}
                            </Paragraph>

                            {/* Segundo elemento del grupo: Párrafo */}
                            {pg.secondItemType === 'paragraph' && pg.secondItemTitle && pg.secondItemContent && (
                                <Paragraph
                                    title={pg.secondItemTitle}
                                    gradientFrom={pg.secondItemGradientFrom || ""} // Usa "" si es null
                                    gradientTo={pg.secondItemGradientTo || ""}   // Usa "" si es null
                                    icon={pg.secondItemIconPath || undefined}
                                    lineDecoration={pg.secondItemLineDecoration}
                                    overLined={pg.secondItemOverLined}
                                >
                                    {/* PASA EL CONTENIDO COMO CHILDREN AQUÍ */}
                                    {pg.secondItemContent}
                                </Paragraph>
                            )}

                            {/* Segundo elemento del grupo: Carrusel */}
                            {pg.secondItemType === 'carousel' && pg.carouselUrls && pg.carouselUrls.length > 0 && (
                                <ContentCarousel
                                    items={pg.carouselUrls} // `carouselUrls` ya es `string[]`
                                />
                            )}
                        </ParagraphGroup>
                    ))
                )}

                <FooterSection text="Conoce más proyectos" buttonConfigs={buttonConfigs} />
            </div>
            <HyperLink link="https://www.itdurango.edu.mx/" />
        </div>
    );
}