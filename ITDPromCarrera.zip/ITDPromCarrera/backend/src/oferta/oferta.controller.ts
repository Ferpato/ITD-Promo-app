/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unused-vars */


// src/oferta/oferta.controller.ts

import { Controller, Get, Post, Body, Param, Delete, Put, UseGuards, HttpStatus, Request } from '@nestjs/common'; // Importa UseGuards y Request
import { OfertaService } from './oferta.service';
import { CreateUpdateOfertaDto } from './dto/oferta.dto'; // Asegúrate de que esta importación sea correcta
import { GetSubdomain } from '../decorators/get-subdomain.decorator'; // Importa el decorador
import { ApiTags, ApiOperation, ApiResponse, ApiParam, ApiBody, ApiHeader, ApiBearerAuth } from '@nestjs/swagger'; // Importa ApiBearerAuth
import { JwtAuthGuard } from 'src/AuthModule/jwt.auth.guard';


@ApiTags('Párrafos de Oferta') // Ajusta el tag para Swagger
@Controller('admin/dashboard/oferta') // La ruta base para este controlador
export class OfertaController {
  constructor(private readonly ofertaService: OfertaService) {}

  // =========================================================
  // --- Endpoints Públicos (Lectura) ---
  // =========================================================
  @Get()
  @ApiOperation({ summary: 'Obtener todos los párrafos de oferta para un subdominio (Público)' })
  @ApiHeader({
    name: 'X-Subdomain',
    description: 'El subdominio para el cual obtener los párrafos de oferta.',
    required: true,
    example: 'marketing',
  })
  @ApiResponse({ status: HttpStatus.OK, description: 'Lista de párrafos de oferta.' })
  async findAll(@GetSubdomain() subdomain: string) {
    return this.ofertaService.findAll(subdomain);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obtener un párrafo de oferta por ID y subdominio (Público)' })
  @ApiParam({ name: 'id', description: 'ID del párrafo de oferta' })
  @ApiHeader({
    name: 'X-Subdomain',
    description: 'El subdominio para el cual obtener el párrafo de oferta.',
    required: true,
    example: 'marketing',
  })
  @ApiResponse({ status: HttpStatus.OK, description: 'Párrafo de oferta encontrado.' })
  @ApiResponse({ status: HttpStatus.NOT_FOUND, description: 'Párrafo de oferta no encontrado.' })
  async findOne(@Param('id') id: string, @GetSubdomain() subdomain: string) {
    return this.ofertaService.findOne(+id, subdomain); // Asegura que id sea un número
  }

  // =========================================================
  // --- Endpoints Protegidos (Escritura/Actualización/Eliminación) ---
  // =========================================================
  @UseGuards(JwtAuthGuard) // <--- Aplica la guardia JWT
  @ApiBearerAuth() // <--- Indica en Swagger que requiere autenticación
  @Post()
  @ApiOperation({ summary: 'Crear un nuevo párrafo de oferta (Protegido - Admin)' })
  @ApiBody({ type: CreateUpdateOfertaDto, description: 'Datos del párrafo de oferta a crear.' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Párrafo de oferta creado exitosamente.' })
  @ApiResponse({ status: HttpStatus.UNAUTHORIZED, description: 'No autorizado. Token inválido o no proporcionado.' })
  @ApiResponse({ status: HttpStatus.FORBIDDEN, description: 'Prohibido. No tiene permisos para esta acción.' })
  async create(@Body() createOfertaDto: CreateUpdateOfertaDto, @Request() req) {
   // console.log(`Admin ${req.user.username} intentando crear párrafo de oferta.`);
    return this.ofertaService.createOrUpdate(createOfertaDto);
  }

  @UseGuards(JwtAuthGuard) // <--- Aplica la guardia JWT
  @ApiBearerAuth() // <--- Indica en Swagger
  @Put(':id')
  @ApiOperation({ summary: 'Actualizar un párrafo de oferta existente (Protegido - Admin)' })
  @ApiParam({ name: 'id', description: 'ID del párrafo de oferta a actualizar' })
  @ApiBody({ type: CreateUpdateOfertaDto, description: 'Datos del párrafo de oferta a actualizar.' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Párrafo de oferta actualizado exitosamente.' })
  @ApiResponse({ status: HttpStatus.UNAUTHORIZED, description: 'No autorizado. Token inválido o no proporcionado.' })
  @ApiResponse({ status: HttpStatus.FORBIDDEN, description: 'Prohibido. No tiene permisos para esta acción.' })
  @ApiResponse({ status: HttpStatus.NOT_FOUND, description: 'Párrafo de oferta no encontrado.' })
  async update(@Param('id') id: string, @Body() updateOfertaDto: CreateUpdateOfertaDto, @Request() req) {
   // console.log(`Admin ${req.user.username} intentando actualizar párrafo de oferta con ID: ${id}.`);
    // Asegura que el ID del parámetro prevalezca si hay inconsistencia
    updateOfertaDto.id = +id;
    return this.ofertaService.createOrUpdate(updateOfertaDto);
  }

  @UseGuards(JwtAuthGuard) // <--- Aplica la guardia JWT
  @ApiBearerAuth() // <--- Indica en Swagger
  @Delete(':id')
  @ApiOperation({ summary: 'Eliminar un párrafo de oferta por ID y subdominio (Protegido - Admin)' })
  @ApiParam({ name: 'id', description: 'ID del párrafo de oferta a eliminar' })
  @ApiHeader({
    name: 'X-Subdomain',
    description: 'El subdominio del párrafo de oferta a eliminar.',
    required: true,
    example: 'marketing',
  })
  @ApiResponse({ status: HttpStatus.OK, description: 'Párrafo de oferta eliminado exitosamente.' })
  @ApiResponse({ status: HttpStatus.UNAUTHORIZED, description: 'No autorizado. Token inválido o no proporcionado.' })
  @ApiResponse({ status: HttpStatus.FORBIDDEN, description: 'Prohibido. No tiene permisos para esta acción.' })
  @ApiResponse({ status: HttpStatus.NOT_FOUND, description: 'Párrafo de oferta no encontrado.' })
  async remove(@Param('id') id: string, @GetSubdomain() subdomain: string, @Request() req) {
   // console.log(`Admin ${req.user.username} intentando eliminar párrafo de oferta con ID: ${id} para subdominio: ${subdomain}.`);
    return this.ofertaService.remove(+id, subdomain); // Asegura que id sea un número
  }

  @UseGuards(JwtAuthGuard) // <--- Aplica la guardia JWT
  @ApiBearerAuth() // <--- Indica en Swagger
  @Delete('/all') // Nueva ruta para eliminar todos
  @ApiOperation({ summary: 'Eliminar TODOS los párrafos de oferta para un subdominio (Protegido - Admin)' })
  @ApiHeader({
    name: 'X-Subdomain',
    description: 'El subdominio para el cual eliminar TODOS los párrafos de oferta.',
    required: true,
    example: 'marketing',
  })
  @ApiResponse({ status: HttpStatus.OK, description: 'Todos los párrafos de oferta eliminados exitosamente para el subdominio.' })
  @ApiResponse({ status: HttpStatus.UNAUTHORIZED, description: 'No autorizado. Token inválido o no proporcionado.' })
  @ApiResponse({ status: HttpStatus.FORBIDDEN, description: 'Prohibido. No tiene permisos para esta acción.' })
  async removeAll(@GetSubdomain() subdomain: string, @Request() req) {
    //console.log(`Admin ${req.user.username} intentando eliminar TODOS los párrafos de oferta para subdominio: ${subdomain}.`);
    return this.ofertaService.removeAll(subdomain);
  }
}