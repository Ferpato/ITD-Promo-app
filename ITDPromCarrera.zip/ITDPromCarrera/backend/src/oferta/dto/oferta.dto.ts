/* eslint-disable prettier/prettier */
// src/oferta/dto/oferta.dto.ts
import { IsOptional, IsString, IsBoolean, IsNumber, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

// DTO para crear o actualizar un párrafo de Oferta.
export class CreateUpdateOfertaDto {
  @ApiProperty({ example: 1, description: 'ID del párrafo (opcional para creación)' })
  @IsOptional()
  @IsNumber()
  id?: number;

  @ApiProperty({ example: 'Nuevo Título de Párrafo', description: 'Título del párrafo' })
  @IsNotEmpty()
  @IsString()
  Titulo: string; // <-- Cambiado: 'Titulo' con 'T' mayúscula

  @ApiProperty({ example: 'Este es el contenido del nuevo párrafo.', description: 'Contenido del párrafo' })
  @IsString()
  Contenido: string; // <-- Cambiado: 'Contenido' con 'C' mayúscula

  @ApiProperty({ example: '/assets/svg/new-icon.svg', description: 'Ruta del icono del párrafo' })
  @IsNotEmpty()
  @IsString()
  Icono: string; // <-- Cambiado: 'Icono' con 'I' mayúscula

  @ApiProperty({ example: 'from-blue-500', description: 'Clase de Tailwind para el color inicial del gradiente' })
  @IsNotEmpty()
  @IsString()
  Color1: string; // <-- Cambiado: 'Color1' con 'C' mayúscula

  @ApiProperty({ example: 'to-indigo-700', description: 'Clase de Tailwind para el color final del gradiente' })
  @IsNotEmpty()
  @IsString()
  Color2: string; // <-- Cambiado: 'Color2' con 'C' mayúscula

  @ApiProperty({ example: true, description: 'Indica si el párrafo tiene decoración de línea' })
  @IsOptional()
  @IsBoolean()
  DecoracionLinea?: boolean; // <-- Cambiado: 'DecoracionLinea' con 'D' y 'L' mayúscula

  @ApiProperty({ example: false, description: 'Indica si el título del párrafo está superpuesto' })
  @IsOptional()
  @IsBoolean()
  TituloSuperpuesto?: boolean; // <-- Cambiado: 'TituloSuperpuesto' con 'T' y 'S' mayúscula

  @ApiProperty({ description: 'Subdominio al que pertenece este párrafo de oferta', example: 'marketing' })
  @IsString()
  @IsNotEmpty()
  subdominio: string;
}