/* eslint-disable prettier/prettier */
// src/oferta/oferta.service.ts

import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DeleteResult, Repository } from 'typeorm';
import { OfertaParrafo } from './oferta.entity';
import { CreateUpdateOfertaDto } from './dto/oferta.dto';

@Injectable()
export class OfertaService {
  constructor(
    @InjectRepository(OfertaParrafo)
    private readonly ofertaParrafoRepository: Repository<OfertaParrafo>,
  ) {}

  async findAll(subdomain: string): Promise<OfertaParrafo[]> {
    // Buscar todos los párrafos de oferta que pertenezcan al subdominio dado
    return this.ofertaParrafoRepository.find({
      where: { subdominio: subdomain },
      order: { id: 'ASC' }, // Ordenar por id para mantener un orden consistente
    });
  }

  async findOne(id: number, subdomain: string): Promise<OfertaParrafo> {
    // Buscar un párrafo específico por ID y subdominio
    const ofertaParrafo = await this.ofertaParrafoRepository.findOne({
      where: { id: id, subdominio: subdomain },
    });
    if (!ofertaParrafo) {
      throw new NotFoundException(`Párrafo de oferta con ID ${id} no encontrado para el subdominio ${subdomain}`);
    }
    return ofertaParrafo;
  }

  async createOrUpdate(createUpdateOfertaDto: CreateUpdateOfertaDto): Promise<OfertaParrafo> {
    const { id, subdominio, ...dataToSave } = createUpdateOfertaDto;

    let ofertaParrafo: OfertaParrafo | null; // <-- CAMBIO AQUÍ: Permite que sea null

    if (id) {
      // Intentar encontrar y actualizar un párrafo existente
      ofertaParrafo = await this.ofertaParrafoRepository.findOne({
        where: { id: id, subdominio: subdominio },
      });

      if (!ofertaParrafo) {
        throw new NotFoundException(`Párrafo de oferta con ID ${id} no encontrado para el subdominio ${subdominio}`);
      }
      
      // Actualizar propiedades del párrafo existente con los nuevos nombres
      // Es más seguro usar Object.assign o el spread operator aquí.
      // Asegúrate de que las propiedades coincidan exactamente con la entidad y el DTO
      Object.assign(ofertaParrafo, {
        Titulo: dataToSave.Titulo,
        Contenido: dataToSave.Contenido,
        Icono: dataToSave.Icono,
        Color1: dataToSave.Color1,
        Color2: dataToSave.Color2,
        DecoracionLinea: dataToSave.DecoracionLinea,
        TituloSuperpuesto: dataToSave.TituloSuperpuesto,
        subdominio: subdominio
      });

    } else {
      // Crear un nuevo párrafo
      ofertaParrafo = this.ofertaParrafoRepository.create({
        Titulo: dataToSave.Titulo,
        Contenido: dataToSave.Contenido,
        Icono: dataToSave.Icono,
        Color1: dataToSave.Color1,
        Color2: dataToSave.Color2,
        DecoracionLinea: dataToSave.DecoracionLinea,
        TituloSuperpuesto: dataToSave.TituloSuperpuesto,
        subdominio: subdominio
      });
    }

    return this.ofertaParrafoRepository.save(ofertaParrafo);
  }

  async remove(id: number, subdomain: string): Promise<void> {
    // Eliminar un párrafo específico por ID y subdominio
    const result = await this.ofertaParrafoRepository.delete({ id: id, subdominio: subdomain });
    if (result.affected === 0) {
      throw new NotFoundException(`Párrafo de oferta con ID ${id} no encontrado para el subdominio ${subdomain}`);
    }
  }
  async removeAll(subdomain: string): Promise<{ affected?: number | null }> { // <-- CAMBIO AQUÍ: añadir | null
        const result: DeleteResult = await this.ofertaParrafoRepository.delete({ subdominio: subdomain }); 
       
        // Retornamos el objeto con la propiedad 'affected' tal como viene de TypeORM
        return { affected: result.affected };
    }
}