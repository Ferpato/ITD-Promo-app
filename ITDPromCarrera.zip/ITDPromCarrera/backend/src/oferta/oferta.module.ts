/* eslint-disable prettier/prettier */
// src/oferta/oferta.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OfertaController } from './oferta.controller'; // <--- Importa el controlador de Oferta
import { OfertaService } from './oferta.service'; // <--- Importa el servicio de Oferta
import { OfertaParrafo } from './oferta.entity'; // <--- Importa la entidad Oferta

@Module({
  imports: [
    TypeOrmModule.forFeature([OfertaParrafo]), // Importa el repositorio para la entidad Oferta
  ],
  controllers: [OfertaController],
  providers: [OfertaService],
})
export class OfertaModule {} // <--- Nombre de la clase del módulo