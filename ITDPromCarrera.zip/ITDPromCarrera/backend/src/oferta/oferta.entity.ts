/* eslint-disable prettier/prettier */
// src/oferta/entities/oferta-parrafo.entity.ts

import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('ParrafosOferta')
export class OfertaParrafo {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'text' })
  Titulo: string; 

  @Column({ type: 'text' })
  Contenido: string; 

  @Column({ type: 'varchar', length: 255 })
  Icono: string; 

  @Column({ type: 'varchar', length: 50 })
  Color1: string; 

  @Column({ type: 'varchar', length: 50 })
  Color2: string; 

  @Column({ type: 'boolean', default: false })
  DecoracionLinea: boolean; 

  @Column({ type: 'boolean', default: false })
  TituloSuperpuesto: boolean; 

  @Column({ type: 'varchar', length: 255, nullable: false, default: 'default' })
  subdominio: string; 
}