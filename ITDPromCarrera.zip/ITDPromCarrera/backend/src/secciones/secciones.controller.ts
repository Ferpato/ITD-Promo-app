/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { Controller, Get, Body, Put, HttpStatus, HttpCode } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBody } from '@nestjs/swagger';

import { SeccionesService } from './secciones.service';
import { CreateUpdateSeccionesPageDto } from './dto/create-update-secciones-page.dto';
import { GetSubdomain } from '../decorators/get-subdomain.decorator'; // Asegúrate de que esta ruta sea correcta

@ApiTags('Secciones de Pagina (Proyectos)') // Etiqueta para agrupar en Swagger
@Controller('admin/dashboard/proyectos') // Ruta base para este controlador
export class SeccionesController {
  constructor(private readonly seccionesService: SeccionesService) {}

  @Get()
  @ApiOperation({ summary: 'Obtiene toda la configuración de la página de Proyectos para el subdominio actual' })
  @ApiResponse({
    status: 200,
    description: 'Configuración completa de la página de Proyectos (título, secciones, carruseles, comentarios).',
    // Puedes especificar un tipo de respuesta más detallado si creas un DTO para la respuesta del GET
  })
  @ApiResponse({ status: 500, description: 'Error interno del servidor al obtener los datos.' })
  async getProyectosPageData(@GetSubdomain() subdominio: string) {
    // Llama al servicio para obtener todos los datos anidados
    return this.seccionesService.getSeccionesPageData(subdominio);
  }

  @Put()
  @HttpCode(HttpStatus.OK) // Se mantiene OK (200) para indicar éxito de actualización/creación de la configuración
  @ApiOperation({ summary: 'Guarda (actualiza o crea) toda la configuración de la página de Proyectos para el subdominio actual' })
  @ApiBody({ type: CreateUpdateSeccionesPageDto, description: 'Datos completos de la página de Proyectos, incluyendo título y secciones anidadas.' })
  @ApiResponse({ status: 200, description: 'La configuración de la página de Proyectos ha sido guardada exitosamente.' })
  @ApiResponse({ status: 400, description: 'Datos de entrada inválidos.' })
  @ApiResponse({ status: 500, description: 'Error interno del servidor al guardar los datos (posiblemente transacción fallida).' })
  async saveProyectosPageData(
    @Body() seccionesPageDto: CreateUpdateSeccionesPageDto,
    @GetSubdomain() subdominio: string,
  ) {
    // Llama al servicio para guardar/actualizar toda la configuración
    return this.seccionesService.saveSeccionesPageData(seccionesPageDto, subdominio);
  }

  // Si necesitas operaciones de eliminación de secciones individuales, podrías añadir un @Delete(':sectionId')
  // pero la lógica actual es "borrar todo y reinsertar".
}