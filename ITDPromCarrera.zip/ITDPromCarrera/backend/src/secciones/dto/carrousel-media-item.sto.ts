/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, IsUrl, IsOptional } from 'class-validator';

export class CarouselMediaItemDto {
  // El ID aquí es un string temporal del frontend. El backend lo ignorará o usará para lógica.
  // Para la DB, este ID no se usa, la URL va al array 'urls'.
  @IsString()
  @IsOptional() // Puede ser que no venga si es un ítem nuevo o ya se guardó antes
  @ApiProperty({ description: 'ID temporal del frontend para el ítem de carrusel.', example: 'temp-xyz123', required: false })
  id?: string; // Es un string porque el frontend lo genera como 'temp-...'

  @IsString()
  @IsUrl() // Asegura que sea una URL válida
  @IsNotEmpty()
  @ApiProperty({ description: 'URL del medio (imagen o video de YouTube)', example: 'https://example.com/imagen.jpg' })
  url: string;
}