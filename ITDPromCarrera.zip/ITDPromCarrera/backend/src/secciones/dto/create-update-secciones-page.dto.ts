/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, ValidateNested, IsString, IsNotEmpty, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';
import { SectionDto } from './section.dto';

export class CreateUpdateSeccionesPageDto {
  // El título principal de la página, numPagina 2
  @IsString()
  @IsNotEmpty()
  @ApiProperty({ description: 'Título principal de la página de Proyectos.', example: 'Nuestros Proyectos Recientes' })
  headerTitle: string; // Este se guardará en TituloPagina con numPagina=2

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => SectionDto)
  @ApiProperty({ type: [SectionDto], description: 'Lista de secciones que componen la página de Proyectos.' })
  sections: SectionDto[];

  @IsString()
  @IsNotEmpty()
  @IsOptional() // Opcional porque se podría inferir del subdominio de las secciones o del header
  @ApiProperty({
    description: 'Subdominio principal para el que se está guardando esta configuración de página. Será sobreescrito por el subdominio del decorador.',
    example: 'default',
    required: false,
  })
  // Aunque ya se envía en el header y en cada SectionDto,
  // tenerlo aquí puede ser útil para validación o claridad,
  // pero el controlador siempre lo tomará del decorador @GetSubdomain.
  subdominio?: string;
}