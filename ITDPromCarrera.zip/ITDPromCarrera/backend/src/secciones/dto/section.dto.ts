/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsNotEmpty, IsString, ValidateNested, IsOptional } from 'class-validator';
import { CommentSectionItemDto } from './comment-section-item.dto';

export class SectionDto {
  @IsString()
  @IsOptional() // Puede ser un ID temporal del frontend ('temp-...') o un ID de DB si ya existe
  @ApiProperty({ description: 'ID único temporal del frontend para la sección.', example: 'temp-section1', required: false })
  id?: string; // Usamos string porque el frontend puede enviar IDs temporales

  // No tiene 'titulo' según tu última confirmación
  @IsString()
  @IsNotEmpty()
  @ApiProperty({ description: 'Texto principal de la sección.', example: 'Descubre nuestros servicios.' })
  text: string; // Mapea a 'texto' en la DB

  @IsString()
  @IsOptional()
  @ApiProperty({ description: 'URL del ícono de la sección (SVG).', example: '/assets/svg/icono.svg', required: false, nullable: true })
  icon?: string | null; // Mapea a 'icono' en la DB

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ description: 'Color inicial del gradiente de fondo de la sección.', example: '#1A2B3C' })
  color1: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ description: 'Color final del gradiente de fondo de la sección.', example: '#4A5B6C' })
  color2: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ description: 'Subdominio al que pertenece esta sección.', example: 'default' })
  subdominio: string; // Se enviará desde el frontend en cada sección

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CommentSectionItemDto)
  @ApiProperty({ type: [CommentSectionItemDto], description: 'Lista de ítems (comentarios o carruseles) dentro de esta sección.' })
  items: CommentSectionItemDto[]; // Contiene los comentarios y carruseles anidados
}