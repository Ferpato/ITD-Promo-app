/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class CommentDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({ description: 'Título del comentario', example: 'Opinión de Cliente Satisfecho' })
  title: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ description: 'Contenido del comentario', example: 'Excelente servicio y resultados garantizados.' })
  content: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ description: 'Color inicial del gradiente para el fondo del comentario', example: '#FF6B6B' })
  gradientFrom: string; // Mapea a 'color1' en la DB

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ description: 'Color final del gradiente para el fondo del comentario', example: '#FFE66B' })
  gradientTo: string; // Mapea a 'color2' en la DB
}