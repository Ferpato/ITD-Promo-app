/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, ValidateNested } from 'class-validator';
import { CarouselMediaItemDto } from './carrousel-media-item.sto';


export class CarouselDto {
  @IsArray()
  @ValidateNested({ each: true }) // Valida cada elemento del array
  @Type(() => CarouselMediaItemDto) // Transforma cada elemento a CarouselMediaItemDto
  @ApiProperty({ type: [CarouselMediaItemDto], description: 'Lista de URLs de medios para el carrusel.' })
  items: CarouselMediaItemDto[];
}