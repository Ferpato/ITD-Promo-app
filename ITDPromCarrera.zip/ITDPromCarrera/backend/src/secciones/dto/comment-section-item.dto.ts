/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, ValidateNested, IsDefined, IsIn, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';
import { CommentDto } from './comment.dto';
import { CarouselDto } from './carrousel.dto';

// Define los tipos de ítems que puede contener una sección
export type CommentSectionItemType = 'comment' | 'carousel';

export class CommentSectionItemDto {
  @IsString()
  @IsOptional() // Puede ser un ID temporal del frontend ('temp-...') o un ID de DB si ya existe
  @ApiProperty({ description: 'ID único temporal del frontend para el ítem de sección.', example: 'temp-item1', required: false })
  id?: string; // Usamos string porque el frontend puede enviar IDs temporales

  @IsString()
  @IsNotEmpty()
  @IsIn(['comment', 'carousel']) // Valida que el tipo sea 'comment' o 'carousel'
  @ApiProperty({ description: 'Tipo de contenido del ítem: "comment" o "carousel".', enum: ['comment', 'carousel'], example: 'comment' })
  type: CommentSectionItemType;

  @IsDefined()
  @IsOptional() // Es opcional si el tipo es 'carousel'
  @ValidateNested()
  @Type(() => CommentDto)
  @ApiProperty({
    description: 'Datos del comentario, presente si el tipo es "comment".',
    type: CommentDto,
    required: false,
    nullable: true,
  })
  commentData?: CommentDto;

  @IsDefined()
  @IsOptional() // Es opcional si el tipo es 'comment'
  @ValidateNested()
  @Type(() => CarouselDto)
  @ApiProperty({
    description: 'Datos del carrusel, presente si el tipo es "carousel".',
    type: CarouselDto,
    required: false,
    nullable: true,
  })
  carouselData?: CarouselDto;
}