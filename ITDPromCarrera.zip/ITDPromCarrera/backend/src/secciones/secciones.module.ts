/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SeccionesService } from './secciones.service';
import { SeccionesController } from './secciones.controller'; // Lo crearemos en el siguiente paso

// Importa las entidades para este módulo
import { Seccion } from './secciones.entity';

// Importa los módulos de los que dependemos
import { TitulosModule } from '../titulos/titulos.module'; // Importa el módulo de títulos
import { CarruselesModule } from '../carruseles/carruseles.module'; // Importa el módulo de carruseles
import { ComentariosModule } from '../comentarios/comentarios.module'; // Importa el módulo de comentarios

@Module({
  imports: [
    TypeOrmModule.forFeature([Seccion]), // Registra la entidad Seccion para este módulo
    TitulosModule, // Importa TitulosModule para acceder a TitulosService
    CarruselesModule, // Importa CarruselesModule para que TypeORM reconozca la entidad Carrusel
    ComentariosModule, // Importa ComentariosModule para que TypeORM reconozca la entidad Comentario
  ],
  providers: [SeccionesService], // Provee el servicio de secciones
  controllers: [SeccionesController], // Declara el controlador de secciones
  exports: [SeccionesService], // Opcional: exporta el servicio si otros módulos lo necesitarán
})
export class SeccionesModule {}