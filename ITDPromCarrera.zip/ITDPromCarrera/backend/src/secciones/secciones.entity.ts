/* eslint-disable prettier/prettier */

import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Carrusel } from '../carruseles/carruseles.entity'; 
import { Comentario } from '../comentarios/comentarios.entity'; 

@Entity('Secciones') // Mapea a la tabla 'Secciones' en la base de datos
export class Seccion {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 255, nullable: false }) // Asumo que 'texto' es obligatorio
  texto: string; // El texto principal de la sección

  @Column({ type: 'varchar', length: 255, nullable: true }) // El icono puede ser opcional
  icono: string | null;

  @Column({ type: 'varchar', length: 255, nullable: false }) // Asumo color1 es obligatorio
  color1: string; // Color de fondo principal

  @Column({ type: 'varchar', length: 255, nullable: false }) // Asumo color2 es obligatorio
  color2: string; // Color final del gradiente

  @Column({ type: 'varchar', length: 255, nullable: false, default: 'default' })
  subdominio: string; // Subdominio al que pertenece esta sección

  // Relación One-to-Many con Carruseles
  // Una Seccion puede tener muchos Carruseles
  @OneToMany(() => Carrusel, carrusel => carrusel.seccion)
  carruseles: Carrusel[]; // Propiedad para la relación inversa

  // Relación One-to-Many con Comentarios
  // Una Seccion puede tener muchos Comentarios
  @OneToMany(() => Comentario, comentario => comentario.seccion)
  comentarios: Comentario[]; // Propiedad para la relación inversa
}