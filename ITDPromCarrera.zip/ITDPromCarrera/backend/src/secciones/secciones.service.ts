/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unused-vars */

import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';

// Importa los servicios
import { TitulosService } from '../titulos/titulo.service'; // <-- ¡Tu servicio de títulos!

// Importa las entidades

import { Seccion } from './secciones.entity';
import { Carrusel } from '../carruseles/carruseles.entity';
import { Comentario } from '../comentarios/comentarios.entity';

// Importa los DTOs

import { SectionDto } from './dto/section.dto';
import { CommentSectionItemDto } from './dto/comment-section-item.dto';
import { CreateUpdateSeccionesPageDto } from './dto/create-update-secciones-page.dto';
// No necesitamos importar CommentDto, CarouselDto, CarouselMediaItemDto directamente aquí,
// ya que están anidados y validados por el DTO principal y class-transformer.

@Injectable()
export class SeccionesService {
  constructor(
    @InjectRepository(Seccion)
    private readonly seccionRepository: Repository<Seccion>,
    @InjectRepository(Carrusel)
    private readonly carruselRepository: Repository<Carrusel>,
    @InjectRepository(Comentario)
    private readonly comentarioRepository: Repository<Comentario>,
    private readonly titulosService: TitulosService, // <-- ¡Inyectamos tu TitulosService!
    private dataSource: DataSource, // Para manejar transacciones
  ) {}

  // --- Método para Cargar Datos ---
  async getSeccionesPageData(subdominio: string): Promise<any> {
    const numPaginaProyectos = 2; // El número de página para la sección de Proyectos

    // 1. Obtener el título principal de la página (usando tu servicio de títulos)
    // Tu getTituloByPagina ya maneja la creación de uno por defecto si no existe.
    const headerTitleEntity = await this.titulosService.getTituloByPagina(
      numPaginaProyectos,
      subdominio,
    );
    const headerTitle = headerTitleEntity ? headerTitleEntity.titulo : ''; // Asegura que siempre sea string, no null

    // 2. Obtener todas las secciones con sus relaciones anidadas
    const secciones = await this.seccionRepository.find({
      where: { subdominio },
      relations: ['carruseles', 'comentarios'], // Carga automáticamente los carruseles y comentarios relacionados
      order: {
        id: 'ASC', // Asumo que el orden de las secciones se basa en su ID de creación
        // Para ordenar ítems dentro de secciones, necesitarías una columna 'order' en Carrusel y Comentario.
        // carruseles: { id: 'ASC' }, // Si también necesitas ordenar los ítems anidados
        // comentarios: { id: 'ASC' }, // Si también necesitas ordenar los ítems anidados
      },
    });

    // 3. Mapear las entidades de la DB a un formato amigable para el frontend (como los DTOs de request)
    const formattedSections = secciones.map(seccion => {
      const sectionItems: CommentSectionItemDto[] = [];

      // Mapear comentarios
      seccion.comentarios.forEach(comentario => {
        sectionItems.push({
          id: comentario.id.toString(), // Convertir ID a string para compatibilidad con el frontend
          type: 'comment',
          commentData: {
            title: comentario.titulo,
            content: comentario.contenido,
            gradientFrom: comentario.color1,
            gradientTo: comentario.color2,
          },
        });
      });

      // Mapear carruseles
      seccion.carruseles.forEach(carrusel => {
        sectionItems.push({
          id: carrusel.id.toString(), // Convertir ID a string para compatibilidad con el frontend
          type: 'carousel',
          carouselData: {
            items: carrusel.urls.map(url => ({
              id: url, // Usamos la URL como ID temporal/identificador para compatibilidad con el DTO
              url: url,
            })),
          },
        });
      });

      // Si el frontend envía un 'order' o 'position' en CommentSectionItemDto,
      // y esa columna existiera en la DB para comentarios y carruseles,
      // podrías ordenar 'sectionItems' aquí antes de devolverlos.
      // Por ejemplo: sectionItems.sort((a, b) => (a.order || 0) - (b.order || 0));

      return {
        id: seccion.id.toString(), // ID de DB como string
        text: seccion.texto,
        icon: seccion.icono,
        color1: seccion.color1,
        color2: seccion.color2,
        subdominio: seccion.subdominio,
        items: sectionItems,
      } as SectionDto; // Casteamos para asegurar el tipo de salida
    });

    return {
      headerTitle: headerTitle,
      sections: formattedSections,
    };
  }

  // --- Método para Guardar Datos (Upsert con Borrado Total) ---
  async saveSeccionesPageData(
    seccionesPageDto: CreateUpdateSeccionesPageDto,
    subdominio: string, // El subdominio del request header
  ): Promise<any> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    const numPaginaProyectos = 2; // Asegúrate de que este es el numPagina para tu página de Proyectos

    try {
      // 1. Guardar/Actualizar el título principal de la página (usando tu servicio de títulos)
      // Tu updateTitulo() ya maneja el upsert.
      await this.titulosService.updateTitulo({
        numPagina: numPaginaProyectos,
        titulo: seccionesPageDto.headerTitle,
        subdominio: subdominio,
      });

      // 2. Eliminar todas las secciones existentes para el subdominio actual
      // ON DELETE CASCADE se encargará de eliminar carruseles y comentarios relacionados
      await queryRunner.manager.delete(Seccion, { subdominio });
     // console.log(`[SeccionesService] Eliminadas todas las secciones antiguas para subdominio '${subdominio}'`);

      // 3. Iterar sobre las nuevas secciones y guardarlas
      for (const sectionDto of seccionesPageDto.sections) {
        // Usa queryRunner.manager.create para crear una nueva entidad
        const newSeccion = queryRunner.manager.create(Seccion, {
          texto: sectionDto.text, // Mapear 'text' a 'texto' de la entidad
          icono: sectionDto.icon,
          color1: sectionDto.color1,
          color2: sectionDto.color2,
          subdominio: subdominio, // Aseguramos que el subdominio de la sección sea el del request
        });
        const savedSeccion = await queryRunner.manager.save(newSeccion);

        // 4. Iterar sobre los ítems de la sección (comentarios y carruseles)
        for (const itemDto of sectionDto.items) {
          if (itemDto.type === 'comment' && itemDto.commentData) {
            const newComentario = queryRunner.manager.create(Comentario, {
              titulo: itemDto.commentData.title,
              contenido: itemDto.commentData.content,
              color1: itemDto.commentData.gradientFrom, // Mapear a color1
              color2: itemDto.commentData.gradientTo,   // Mapear a color2
              seccion: savedSeccion, // Vincula al objeto Seccion recién guardado
            });
            await queryRunner.manager.save(newComentario);
          } else if (itemDto.type === 'carousel' && itemDto.carouselData) {
            // Extraer solo las URLs del arreglo de objetos CarouselMediaItemDto
            const urls = itemDto.carouselData.items.map(mediaItem => mediaItem.url);
            const newCarrusel = queryRunner.manager.create(Carrusel, {
              urls: urls, // Asignar el arreglo de strings
              seccion: savedSeccion, // Vincula al objeto Seccion recién guardado
            });
            await queryRunner.manager.save(newCarrusel);
          } else {
           // console.warn(`[SeccionesService] Ítem de sección con tipo desconocido o datos faltantes:`, itemDto);
            // Opcional: lanzar una excepción aquí si los datos son inválidos
          }
        }
      }

      await queryRunner.commitTransaction();
     // console.log(`[SeccionesService] Datos de secciones y título guardados exitosamente para subdominio '${subdominio}'`);

      // Opcional: Devolver los datos recién guardados para que el frontend los recargue o confirme
      return {
        message: 'Configuración de página de proyectos guardada exitosamente.',
        // Podrías llamar a getSeccionesPageData() aquí para devolver el estado completo actualizado
      };
    } catch (err) {
      await queryRunner.rollbackTransaction();
      //console.error(`[SeccionesService] Error al guardar datos de secciones para subdominio '${subdominio}':`, err);
      // Lanza una excepción más genérica para el cliente, el error detallado se queda en los logs
      throw new BadRequestException('Error al guardar la configuración de la página de proyectos.');
    } finally {
      await queryRunner.release(); // Libera el queryRunner
    }
  }
}