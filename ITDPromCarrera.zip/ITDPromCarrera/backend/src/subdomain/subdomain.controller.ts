/* eslint-disable prettier/prettier */


/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */

// src/subdominios/subdomain.controller.ts
import { Controller, Get, Post, Body, Param, Delete, NotFoundException, HttpCode, HttpStatus } from '@nestjs/common';
import { GetSubdomain } from '../decorators/get-subdomain.decorator'; // Ajusta esta ruta si tu decorador está en otro lugar
import { SubdomainService } from './subdomain.services';
import { CreateSubdomainDto } from './subdomain.dto'; // ¡IMPORTACIÓN CORREGIDA DEL DTO!


@Controller('subdomains') // La URL base para este controlador es /subdomains
export class SubdomainController {
  constructor(
    private readonly subdomainsService: SubdomainService,
  ) {}

  // --- Endpoints para el Dashboard (CRUD de la lista de subdominios) ---

  // Maneja GET http://127.0.0.1:3001/subdomains
  // Este endpoint es para que el dashboard obtenga la lista de todos los subdominios existentes.
  @Get('/')
  async findAllForDashboard() {
   // console.log('[SubdomainController] Solicitud de listado de todos los subdominios (para dashboard).');
    return this.subdomainsService.findAll();
  }

  // Maneja POST http://127.0.0.1:3001/subdomains
  // Este endpoint es para que el dashboard añada un nuevo subdominio.
  @Post('/')
  @HttpCode(HttpStatus.CREATED) // Para devolver 201 Created al crear
  async create(@Body() createSubdomainDto: CreateSubdomainDto) { // Usando el DTO correctamente importado
  //  console.log(`[SubdomainController] Solicitud para crear subdominio: ${createSubdomainDto.nombre}`);
    return this.subdomainsService.create(createSubdomainDto);
  }

  // Maneja DELETE http://127.0.0.1:3001/subdomains/:id
  // Este endpoint es para que el dashboard elimine un subdominio por su ID.
  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT) // Para devolver 204 No Content al eliminar exitosamente
  async remove(@Param('id') id: string) {
   // console.log(`[SubdomainController] Solicitud para eliminar subdominio con ID: ${id}`);
    await this.subdomainsService.remove(+id); // Convierte el ID de string a number
    // No devuelve nada, solo el 204 No Content
  }

  // --- Endpoint para la Configuración Específica del Subdominio (para marketing.localhost, sucks.localhost) ---

  // Este endpoint maneja GET http://127.0.0.1:3001/subdomains/resolve-config
  // Este es el endpoint que tu aplicación frontend (ej: la que corre en marketing.localhost:3000)
  // debería llamar para obtener su configuración específica.
  // Aquí es donde se activa la lógica de rechazo con 404 si el subdominio de origen no existe en la DB.
  @Get('/resolve-config') // ¡Esta es la ruta para la configuración específica por subdominio de origen!
  async resolveSubdomainConfigByOrigin(@GetSubdomain() subdomainName: string) {
  //  console.log(`[SubdomainController] Solicitud de configuración para el subdominio ORIGEN: ${subdomainName}`);

    // Si el decorador no detecta un subdominio (ej: si accedes desde localhost sin un subdominio),
    // podrías querer devolver un 404 o una configuración por defecto.
    if (!subdomainName) {
        console.warn("[SubdomainController] No se detectó subdominio en la petición de /resolve-config. Devolviendo 404.");
        throw new NotFoundException("No se pudo resolver el subdominio de origen.");
    }

    // Esto lanzará NotFoundException si 'subdomainName' no existe en la base de datos
    const subdomainConfig = await this.subdomainsService.getFullSubdomainConfig(subdomainName);
    return subdomainConfig;
  }
}