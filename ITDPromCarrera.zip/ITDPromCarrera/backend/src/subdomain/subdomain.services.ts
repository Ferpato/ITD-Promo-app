/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */



// src/subdomains/subdomain.services.ts
import { Injectable, NotFoundException, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm'; // Importa 'In' para consultas con múltiples valores
import { Subdomain } from '../subdomain/subdomain.entity'; // Asegúrate de que la ruta a la entidad es correcta

// --- Importa las entidades de las otras tablas ---
import { Seccion } from '../secciones/secciones.entity'; // Asume esta ruta
import { TituloPagina } from '../titulos/titulos.entity'; // Asume esta ruta
import { MainConfig } from '../main/main.entity'; // Asume esta ruta
import { OfertaParrafo } from '../oferta/oferta.entity'; // Asume esta ruta
import { ParagraphGroup } from '../materias/materias.entity'; // Asume esta ruta

// Idealmente, esto debería venir de 'src/subdominios/dto/create-subdomain.dto.ts'
interface CreateSubdomainDto { 
  nombre: string;
}

@Injectable()
export class SubdomainService {
  constructor(
    @InjectRepository(Subdomain)
    private subdomainsRepository: Repository<Subdomain>,
    // --- Inyecta los repositorios de las otras tablas ---
    @InjectRepository(Seccion)
    private seccionesRepository: Repository<Seccion>,
    @InjectRepository(TituloPagina)
    private tituloPaginaRepository: Repository<TituloPagina>,
    @InjectRepository(MainConfig)
    private inicioRepository: Repository<MainConfig>,
    @InjectRepository(OfertaParrafo)
    private parrafosOfertaRepository: Repository<OfertaParrafo>,
    @InjectRepository(ParagraphGroup)
    private paragraphGroupRepository: Repository<ParagraphGroup>,
  ) {}

  // --- Métodos para el Dashboard (listar, añadir, eliminar) ---

  async findAll(): Promise<Subdomain[]> {
    return this.subdomainsRepository.find();
  }

  async create(createSubdomainDto: CreateSubdomainDto): Promise<Subdomain> {
    // Verificar si ya existe un subdominio con ese nombre para evitar duplicados
    const existingSubdomain = await this.subdomainsRepository.findOne({ where: { nombre: createSubdomainDto.nombre } });
    if (existingSubdomain) {
      throw new InternalServerErrorException(`Ya existe un subdominio con el nombre '${createSubdomainDto.nombre}'.`);
    }

    const newSubdomain = this.subdomainsRepository.create(createSubdomainDto);
    return this.subdomainsRepository.save(newSubdomain);
  }

  // --- Método `remove` modificado para eliminación en cascada ---
  async remove(id: number): Promise<void> {
    // 1. Encontrar el subdominio por ID para obtener su nombre
    const subdomainToDelete = await this.subdomainsRepository.findOne({ where: { id } });

    if (!subdomainToDelete) {
      throw new NotFoundException(`Subdominio con ID ${id} no encontrado para eliminar.`);
    }

    const subdomainName = subdomainToDelete.nombre;
   // console.log(`[SubdomainService] Iniciando eliminación en cascada para subdominio: '${subdomainName}' (ID: ${id})`);

    try {
      // 2. Eliminar registros asociados en las tablas de contenido por el nombre del subdominio
      // Utiliza 'delete' con un objeto de criterio para eliminar por el nombre del subdominio
      
     // console.log(`Eliminando Secciones con subdominio: '${subdomainName}'`);
      await this.seccionesRepository.delete({ subdominio: subdomainName });

     // console.log(`Eliminando TituloPagina con subdominio: '${subdomainName}'`);
      await this.tituloPaginaRepository.delete({ subdominio: subdomainName });

    // console.log(`Eliminando Inicio con subdominio: '${subdomainName}'`);
      await this.inicioRepository.delete({ subdominio: subdomainName });

      //console.log(`Eliminando ParrafosOferta con subdominio: '${subdomainName}'`);
      await this.parrafosOfertaRepository.delete({ subdominio: subdomainName });
      
    //  console.log(`Eliminando ParagraphGroup con subdominio: '${subdomainName}'`);
      await this.paragraphGroupRepository.delete({ subdominio: subdomainName });

      // 3. Finalmente, eliminar el registro del subdominio de la tabla 'Subdomain'
      //console.log(`Eliminando Subdomain entity con ID: ${id}`);
      await this.subdomainsRepository.remove(subdomainToDelete); // Usa remove(entity) para TypeORM

      //console.log(`[SubdomainService] Eliminación en cascada completada para subdominio: '${subdomainName}'`);

    } catch (error) {
      console.error(`[SubdomainService] ERROR durante la eliminación en cascada para '${subdomainName}':`, error);
      throw new InternalServerErrorException(`Error al eliminar el subdominio y sus datos asociados: ${error.message}`);
    }
  }

  // --- Métodos para la Configuración Específica del Subdominio ---

  async findByNombre(nombre: string): Promise<Subdomain | null> { 
    return this.subdomainsRepository.findOne({ where: { nombre } });
  }

  async findOneByName(subdomainName: string): Promise<Subdomain> {
    const subdomain = await this.subdomainsRepository.findOne({ where: { nombre: subdomainName } });
    if (!subdomain) {
      throw new NotFoundException(`Subdominio "${subdomainName}" no encontrado en la base de datos.`);
    }
    return subdomain;
  }

  async getFullSubdomainConfig(subdomainName: string): Promise<any> {
    const subdomainEntity = await this.findOneByName(subdomainName);
    return {
      nombre: subdomainEntity.nombre,
      message: `Configuración para el subdominio "${subdomainEntity.nombre}"`
    };
  }
}