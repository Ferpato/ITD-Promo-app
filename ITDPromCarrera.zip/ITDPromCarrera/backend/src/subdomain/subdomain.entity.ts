/* eslint-disable prettier/prettier */
// src/subdominios/entities/subdomain.entity.ts
import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('subdominio') // Asegúrate de que este nombre sea el de tu tabla en la base de datos
export class Subdomain {
  @PrimaryGeneratedColumn() // Esto asume que 'id' es auto-incremental en tu DB
  id: number;

  @Column({ type: 'varchar', length: 255, unique: true, nullable: false })
  nombre: string; // El nombre de la columna en tu tabla para el subdominio
}