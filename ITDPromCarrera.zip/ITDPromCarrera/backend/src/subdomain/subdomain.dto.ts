/* eslint-disable prettier/prettier */
// src/subdominios/dto/create-subdomain.dto.ts
import { IsString, IsNotEmpty } from 'class-validator';

export class CreateSubdomainDto {
  @IsString({ message: 'El nombre del subdominio debe ser una cadena de texto.' })
  @IsNotEmpty({ message: 'El nombre del subdominio no puede estar vacío.' })
  nombre: string;
}