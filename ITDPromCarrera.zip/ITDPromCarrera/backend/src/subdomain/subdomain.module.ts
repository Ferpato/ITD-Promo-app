/* eslint-disable prettier/prettier */
// src/subdomains/subdomains.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Subdomain } from './subdomain.entity'; // Tu entidad de subdominio
import { SubdomainService } from './subdomain.services';
import { SubdomainController } from './subdomain.controller';

// --- ¡IMPORTACIONES CORRECTAS DE ENTIDADES ADICIONALES! ---
import { Seccion } from '../secciones/secciones.entity'; // Asume esta ruta
import { TituloPagina } from '../titulos/titulos.entity'; // Asume esta ruta
import { MainConfig } from '../main/main.entity'; // Asume esta ruta (correspondiente a 'Inicio' previamente)
import { OfertaParrafo } from '../oferta/oferta.entity'; // Asume esta ruta (correspondiente a 'ParrafosOferta' previamente)
import { ParagraphGroup } from '../materias/materias.entity'; // Asume esta ruta (correspondiente a 'ParagraphGroup' en 'materias')


@Module({
  imports: [
    TypeOrmModule.forFeature([
      Subdomain, 
      Seccion, 
      TituloPagina, 
      MainConfig, 
      OfertaParrafo,
      ParagraphGroup, 
    ]),
    // Otros módulos importados si los tienes (ej: AuthModule, etc.)
  ],
  controllers: [SubdomainController],
  providers: [SubdomainService],
  // Es crucial exportar el servicio de Subdomain si otros módulos necesitan inyectarlo
  // O si el decorador @GetSubdomain lo utiliza para la validación de CORS
  exports: [SubdomainService, TypeOrmModule.forFeature([Subdomain])],
})
export class SubdomainsModule {}