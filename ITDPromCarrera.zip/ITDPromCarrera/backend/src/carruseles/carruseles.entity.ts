/* eslint-disable prettier/prettier */

import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Seccion } from '../secciones/secciones.entity'; // Asegúrate de que la ruta a la entidad Seccion sea correcta

@Entity('carruseles') // Mapea a la tabla 'Carruseles' en la base de datos
export class Carrusel {
  @PrimaryGeneratedColumn()
  id: number;

  // TypeORM permite directamente arreglos de cadenas para columnas ARRAY en PostgreSQL
  @Column('varchar', { array: true, nullable: false }) // 'varchar' para string, 'array: true' para arreglo, no puede ser nulo
  urls: string[]; // Arreglo de URLs para las imágenes/videos del carrusel

  @Column({ name: 'seccionId' }) // Nombre explícito de la columna en la DB
  seccionId: number; // Columna para la llave foránea

  // Relación ManyToOne con la entidad Seccion
  // Muchos Carruseles pueden pertenecer a una Seccion
  @ManyToOne(() => Seccion, seccion => seccion.carruseles, {
    onDelete: 'CASCADE', // Si la sección se elimina, los carruseles asociados también
    orphanedRowAction: 'delete', // Elimina carruseles si pierden su sección (no recomendado si se gestionan manualmente)
  })
  @JoinColumn({ name: 'seccionId' }) // Indica que 'seccionId' es la columna FK
  seccion: Seccion; // Propiedad para la relación, no se almacena directamente en la DB
}