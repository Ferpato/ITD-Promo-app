/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Carrusel } from './carruseles.entity'; // Asegúrate de que esta ruta y nombre de entidad sean correctos

@Module({
  imports: [
    TypeOrmModule.forFeature([Carrusel]), // Registra la entidad Carrusel
  ],
  // No necesitamos 'providers' o 'controllers' por ahora si no hay un servicio/controlador CRUD individual
  exports: [TypeOrmModule], // Exporta TypeOrmModule para que SeccionesModule pueda acceder a los repositorios si es necesario
})
export class CarruselesModule {}