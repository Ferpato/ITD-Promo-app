/* eslint-disable prettier/prettier */
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UsuariosAdmin } from '../Usuarios/Usuarios.entity'; 

export interface JwtPayload {
  usuario: string;
  sub: number;
  iat?: number;
  exp?: number;
}

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(
    @InjectRepository(UsuariosAdmin)
    private usersRepository: Repository<UsuariosAdmin>,
    private configService: ConfigService,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      // Usamos el operador '!' para afirmar que configService.get() NO será undefined.
      // Ya lo comprobamos con el console.log de depuración.
      secretOrKey: configService.get<string>('JWT_SECRET')!, 
    });
  }

  async validate(payload: JwtPayload) {
    const user = await this.usersRepository.findOne({ where: { id: payload.sub } });

    if (!user) {
      throw new UnauthorizedException('Token inválido o usuario no encontrado');
    }

    return { userId: payload.sub, username: payload.usuario };
  }
}