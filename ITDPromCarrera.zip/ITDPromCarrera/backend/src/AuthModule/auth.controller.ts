/* eslint-disable prettier/prettier */
import { Controller, Post, Body, HttpCode, HttpStatus } from '@nestjs/common';
import { AuthService } from './auth.service';
import { LoginDto } from './dto/auth.dto'; // Importa el DTO de login
import { ApiTags, ApiResponse, ApiOperation } from '@nestjs/swagger'; // Importa decoradores de Swagger

@ApiTags('Auth') // Etiqueta para agrupar endpoints en Swagger UI
@Controller('auth') // Define la ruta base para este controlador, ej. /auth
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('login') // Define el endpoint POST /auth/login
  @HttpCode(HttpStatus.OK) // Devuelve un código de estado 200 OK en caso de éxito (por defecto es 201 para POST)
  @ApiOperation({ summary: 'Inicia sesión de usuario y devuelve un token JWT' })
  @ApiResponse({ status: 200, description: 'Login exitoso', schema: {
    type: 'object',
    properties: {
      accessToken: { type: 'string', example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' },
      message: { type: 'string', example: 'Login exitoso' },
    },
  }})
  @ApiResponse({ status: 401, description: 'Credenciales incorrectas' })
  async signIn(@Body() loginDto: LoginDto) {
    // Llama al método login del AuthService para validar credenciales y generar el token
    return this.authService.login(loginDto);
  }

  // Más adelante, aquí podrías añadir otras rutas como:
  // @Post('register')
  // @Get('profile') // Una ruta protegida para obtener el perfil del usuario autenticado
  // @UseGuards(JwtAuthGuard) // Esto lo veremos después para proteger rutas
  // getProfile(@Request() req) {
  //   return req.user; // req.user contendrá la información del payload del JWT validado
  // }
}