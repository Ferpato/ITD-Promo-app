/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */

import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcryptjs'; // Importa bcryptjs (o bcrypt)

import { UsuariosAdmin } from '../Usuarios/Usuarios.entity'; // Asegúrate de que la ruta sea correcta
import { LoginDto } from './dto/auth.dto';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(UsuariosAdmin) // Inyecta el repositorio de tu entidad UsuariosAdmin
    private usersRepository: Repository<UsuariosAdmin>,
    private jwtService: JwtService, // Inyecta el JwtService que configuramos en AuthModule
  ) {}

  /**
   * Valida las credenciales de un usuario.
   * @param usuario El nombre de usuario.
   * @param contrasena La contraseña en texto plano.
   * @returns El objeto de usuario sin la contraseña, o null si las credenciales son inválidas.
   */
  async validateUser(usuario: string, contrasena: string): Promise<any> {
    // 1. Buscar al usuario por su nombre de usuario
    const user = await this.usersRepository.findOne({ where: { usuario: usuario } });

    if (!user) {
      return null; // Usuario no encontrado
    }

    // 2. Comparar la contraseña ingresada con la contraseña hasheada almacenada en la DB
    // Asumimos que user.contrasena en la DB ya está hasheada.
    const isPasswordValid = await bcrypt.compare(contrasena, user.contrasena);

    if (isPasswordValid) {
      // 3. Si la contraseña coincide, devolver los datos relevantes del usuario, excluyendo la contraseña
      // Esto es para asegurar que la contraseña hasheada nunca salga del backend
      const { contrasena, ...result } = user; // Desestructura para excluir la contraseña
      return result;
    }
    
    return null; // Contraseña incorrecta
  }

  /**
   * Procesa el login de un usuario, valida credenciales y genera un JWT.
   * @param loginDto DTO con el nombre de usuario y contraseña.
   * @returns Un objeto que contiene el accessToken JWT y un mensaje de éxito.
   */
  async login(loginDto: LoginDto) {
    // 1. Validar las credenciales del usuario usando validateUser
   
    const user = await this.validateUser(loginDto.usuario, loginDto.contrasena);

    if (!user) {
      // Si validateUser devuelve null, lanza una excepción de no autorizado
      throw new UnauthorizedException('Credenciales incorrectas');
    }

    // 2. Crear el payload para el JWT.
    // Este payload contendrá la información que se "codifica" en el token.
    // Es crucial no incluir información sensible como contraseñas.
    // Generalmente, se incluye el ID del usuario (sub) y quizás el nombre de usuario o rol.
    const payload = { usuario: user.usuario, sub: user.id };

    // 3. Firmar el payload para generar el accessToken JWT
    return {
      accessToken: this.jwtService.sign(payload), // JwtService.sign() usa la clave secreta y el expiresIn de JwtModule
      message: 'Login exitoso',
    };
  }

  
}