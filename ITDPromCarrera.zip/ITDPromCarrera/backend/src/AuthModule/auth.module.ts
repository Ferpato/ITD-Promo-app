/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config'; // ¡Importante para acceder a las variables de entorno!

import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { UsuariosAdmin } from '../Usuarios/Usuarios.entity'; // Asegúrate de que esta ruta sea correcta
import { JwtStrategy } from './jwt.strategy';
// Ya NO necesitamos importar jwtConstants de './constants' porque usamos ConfigService

@Module({
  imports: [
    TypeOrmModule.forFeature([UsuariosAdmin]), // Registra tu entidad de usuario para este módulo
    PassportModule, // Módulo base de Passport
    
    // Configura JwtModule de forma asíncrona para que pueda inyectar ConfigService
    JwtModule.registerAsync({
      imports: [ConfigModule], // Necesario para que ConfigService esté disponible aquí
      // eslint-disable-next-line @typescript-eslint/require-await
      useFactory: async (configService: ConfigService) => ({
        secret: configService.get<string>('JWT_SECRET'), // Obtiene la clave secreta desde tu .env
        signOptions: { expiresIn: '2h' }, // ¡Define el tiempo de expiración de tus tokens!
                                          // Considera hacerlo una variable de entorno también, ej. 'JWT_EXPIRATION_TIME'
      }),
      inject: [ConfigService], // Especifica que ConfigService debe ser inyectado en useFactory
    }),
  ],
  providers: [
    AuthService, 
    JwtStrategy // La estrategia JWT también debe ser un proveedor
  ],
  controllers: [AuthController],
  exports: [
    AuthService, 
    JwtModule // Exporta JwtModule si otros módulos lo necesitan para verificar tokens (ej. si tienes guards personalizados)
  ],
})
export class AuthModule {}