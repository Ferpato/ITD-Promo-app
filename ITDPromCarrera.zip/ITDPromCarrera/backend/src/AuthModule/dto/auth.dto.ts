/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger'; // Importa ApiProperty para la documentación de Swagger
import { IsString, IsNotEmpty } from 'class-validator';

export class LoginDto {
  @ApiProperty({ description: 'Nombre de usuario para iniciar sesión', example: 'admin' })
  @IsString({ message: 'El usuario debe ser una cadena de texto.' })
  @IsNotEmpty({ message: 'El usuario no puede estar vacío.' })
  usuario: string; // Coincide con el nombre de la columna en tu DB (si la usas para mapeo)

  @ApiProperty({ description: 'Contraseña del usuario', example: 'password123' })
  @IsString({ message: 'La contraseña debe ser una cadena de texto.' })
  @IsNotEmpty({ message: 'La contraseña no puede estar vacía.' })
  contrasena: string; // Coincide con el nombre de la columna en tu DB (si la usas para mapeo)
}