/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unsafe-return */

import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  // Opcional: Puedes sobrescribir el método handleRequest para personalizar el manejo de errores
  handleRequest(err, user) {
    // Puedes lanzar una excepción personalizada basada en 'err' o 'info'
    if (err || !user) {
      throw err || new UnauthorizedException('No autorizado. Token inválido o no proporcionado.');
    }
    return user;
  }
}