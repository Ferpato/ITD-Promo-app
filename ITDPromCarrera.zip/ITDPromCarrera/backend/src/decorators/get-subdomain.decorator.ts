/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unused-vars */

/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */


import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export const GetSubdomain = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): string => {
    const request = ctx.switchToHttp().getRequest();

    // Preferimos 'Origin' que es más confiable para CORS requests.
    // Si 'Origin' no está presente (ej. ciertas peticiones del mismo origen, o Postman),
    // podemos caer de vuelta a 'Referer' o al host de la petición real (pero con cuidado).
    const originHeader = request.headers.origin as string;
    const refererHeader = request.headers.referer as string; // Referer puede contener la ruta completa

    let hostToParse = '';

    if (originHeader) {
      // Si tenemos la cabecera Origin, la usamos.
      // Necesitamos extraer solo el host de la URL completa (ej. http://marketing.localhost:3000)
      try {
        const originUrl = new URL(originHeader);
        hostToParse = originUrl.hostname; // Esto dará 'marketing.localhost' o 'localhost'
        if (originUrl.port) {
            hostToParse += `:${originUrl.port}`; // Agregamos el puerto si existe
        }
      } catch (e) {
       // console.error(`[GetSubdomain Decorator] Error al parsear Origin URL: ${originHeader}`, e);
        // Fallback si la URL es inválida
        hostToParse = originHeader; // Usar el raw origin, aunque pueda fallar el regex
      }
    } else if (refererHeader) {
      // Si no hay Origin, intentamos con Referer (menos fiable, puede contener rutas)
      try {
        const refererUrl = new URL(refererHeader);
        hostToParse = refererUrl.hostname;
        if (refererUrl.port) {
            hostToParse += `:${refererUrl.port}`;
        }
      } catch (e) {
       // console.error(`[GetSubdomain Decorator] Error al parsear Referer URL: ${refererHeader}`, e);
        hostToParse = refererHeader;
      }
    } else {
      // Último recurso: host de la petición real (que ya sabemos que es localhost:3001)
      // Esto solo lo usaremos si no hay cabeceras de origen/referencia, lo cual es poco probable
      // para peticiones desde el navegador.
      hostToParse = request.headers.host || request.hostname;
    }


   // console.log(`[GetSubdomain Decorator] Host para parsear: ${hostToParse}`);

    const productionDomain = process.env.PRODUCTION_DOMAIN;

    if (!productionDomain) {
     // console.warn('[GetSubdomain Decorator] WARNING: PRODUCTION_DOMAIN no definido en .env. Asumiendo "default".');
      return 'default';
    }

    const escapedProductionDomain = productionDomain.replace(/\./g, '\\.');
    // Regex para subdominios. Permite sub.dominio.com o sub.localhost, con o sin puerto.
    const subdomainRegex = new RegExp(`^(.*?)\\.${escapedProductionDomain}(?::\\d+)?$`);
    const localhostSubdomainRegex = new RegExp(`^(.*?)\\.localhost(?::\\d+)?$`);

    let match;
    let subdomain = 'default';

    if (hostToParse.includes(productionDomain) && productionDomain !== 'localhost') {
        match = hostToParse.match(subdomainRegex);
        if (match && match[1] && match[1] !== 'www') {
            subdomain = match[1];
        }
    } else if (hostToParse.includes('localhost')) {
        match = hostToParse.match(localhostSubdomainRegex);
        if (match && match[1] && match[1] !== 'www') {
            subdomain = match[1];
        } else if (hostToParse.split(':')[0] === 'localhost' || hostToParse.split(':')[0] === '127.0.0.1') {
            // Si es solo 'localhost:3000' o '127.0.0.1:3000', no hay subdominio explícito
            subdomain = 'default';
        }
    }

    //console.log(`[GetSubdomain Decorator] Subdominio detectado: ${subdomain}`);
   // console.log(`[GetSubdomain Decorator] Host para parsear: "${hostToParse}"`);
    //console.log(`[GetSubdomain Decorator] Subdominio FINAL detectado: "${subdomain}"`);
    return subdomain;
  },
);