/* eslint-disable prettier/prettier */
// src/titulos/titulos.controller.ts (o la ruta correcta de tu controlador de títulos)
import { Controller, Get, Body, Put, Param, HttpStatus, HttpCode, Delete, ParseIntPipe } from '@nestjs/common';
import { TitulosService } from './titulo.service';
import { UpdateTituloDto } from './dto/titulo.dto'; // Tu DTO se llama UpdateTituloDto
import { GetSubdomain } from '../decorators/get-subdomain.decorator'; // Asegúrate de que esta ruta sea correcta
import { ApiTags, ApiOperation, ApiResponse, ApiBody, ApiParam } from '@nestjs/swagger'; // Para Swagger

@ApiTags('Titulos de Pagina') // Etiqueta para agrupar en Swagger
@Controller('admin/dashboard/titulos') // Ruta base para este controlador
export class TitulosController {
  constructor(private readonly titulosService: TitulosService) {}

  @Get(':numPagina') // Ahora, el numPagina es parte de la URL
  @ApiOperation({ summary: 'Obtiene el título de una página específica para el subdominio actual' })
  @ApiParam({ name: 'numPagina', description: 'Número identificador de la página (ej. 0 para Oferta)', type: Number })
  @ApiResponse({ status: 200, description: 'Título de la página.', type: UpdateTituloDto })
  async getTitulo(@Param('numPagina', ParseIntPipe) numPagina: number, @GetSubdomain() subdominio: string) {
    // Llama al servicio con el número de página y el subdominio.
    return this.titulosService.getTituloByPagina(numPagina, subdominio);
  }

  @Put() // Usaremos PUT para actualizar o crear el título de una página
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Actualiza o crea el título de una página para el subdominio actual' })
  @ApiBody({ type: UpdateTituloDto })
  @ApiResponse({ status: 200, description: 'El título de la página ha sido actualizado/creado exitosamente.', type: UpdateTituloDto })
  async updateTitulo(@Body() updateTituloDto: UpdateTituloDto, @GetSubdomain() subdominio: string) {
    // Asigna el subdominio detectado al DTO antes de pasarlo al servicio.
    updateTituloDto.subdominio = subdominio;
    // Llama al servicio para crear o actualizar.
    return this.titulosService.updateTitulo(updateTituloDto);
  }

  @Delete(':numPagina')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Elimina el título de una página para el subdominio actual' })
  @ApiParam({ name: 'numPagina', description: 'Número identificador de la página a eliminar', type: Number })
  @ApiResponse({ status: 204, description: 'Título eliminado exitosamente.' })
  @ApiResponse({ status: 404, description: 'Título no encontrado para este subdominio.' })
  async removeTitulo(@Param('numPagina', ParseIntPipe) numPagina: number, @GetSubdomain() subdominio: string) {
    return this.titulosService.removeTituloByPaginaAndSubdomain(numPagina, subdominio);
  }
}