/* eslint-disable prettier/prettier */

import { Entity, PrimaryGeneratedColumn, Column, Unique } from 'typeorm';

@Entity('TituloPagina') // Mapea a la tabla 'TituloPagina' en la base de datos
@Unique(['numPagina', 'subdominio']) 
export class TituloPagina {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'int', nullable: false }) // Añadido nullable: false para asegurar que siempre haya un numPagina
  numPagina: number; // Identificador numérico de la página (ej. 0 para Oferta, 1 para Contacto, 2 para Proyectos)

  @Column({ type: 'text', nullable: false }) 
  titulo: string; 

  @Column({ type: 'varchar', length: 255, nullable: false, default: 'default' })
  subdominio: string; //subdominio asociado al título
}