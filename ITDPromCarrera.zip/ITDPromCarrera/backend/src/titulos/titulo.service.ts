/* eslint-disable prettier/prettier */
// src/titulos/titulos.service.ts
import { Injectable, NotFoundException } from '@nestjs/common'; // Asegúrate de importar NotFoundException
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TituloPagina } from './titulos.entity'; // Tu entidad se llama TituloPagina, no Titulo
import { UpdateTituloDto } from './dto/titulo.dto'; // Tu DTO se llama UpdateTituloDto

@Injectable()
export class TitulosService {
  constructor(
    @InjectRepository(TituloPagina)
    private tituloPaginaRepository: Repository<TituloPagina>,
  ) {}

  /**
   
   * @param numPagina Identificador de la página.
   * @param subdominio El subdominio al que pertenece el título.
   * @returns {Promise<TituloPagina>} El objeto del título de la página.
   */
  async getTituloByPagina(numPagina: number, subdominio: string): Promise<TituloPagina> {
    // Busca el título único para esta página y subdominio.
    let tituloPagina = await this.tituloPaginaRepository.findOne({ where: { numPagina, subdominio } });

    // Si no hay título para esa página y subdominio, crea uno por defecto
    if (!tituloPagina) {
      let defaultTitle = `Título por defecto de la página ${numPagina}`;
      if (numPagina === 0) { // Ejemplo: página de Oferta
        defaultTitle = 'Oferta Educativa - Tu Futuro Comienza Aquí';
      } else if (numPagina === 1) { // Ejemplo: página de Contacto
        defaultTitle = 'Contáctanos - ¡Estamos Aquí para Ayudarte!';
      }
      // Añade más casos según necesites para otras páginas

      tituloPagina = this.tituloPaginaRepository.create({
        numPagina: numPagina,
        titulo: defaultTitle,
        subdominio: subdominio, // ¡Asigna el subdominio al crear el título por defecto!
      });
      await this.tituloPaginaRepository.save(tituloPagina);
    }
    return tituloPagina;
  }

  /**
   * Actualiza o crea el título de una página específica para un subdominio dado.
   * Garantiza que solo haya un título por 'numPagina' y 'subdominio'.
   * @param updateTituloDto Datos para actualizar el título (incluye numPagina, titulo y subdominio).
   * @returns {Promise<TituloPagina>} El objeto del título actualizado.
   */
  async updateTitulo(updateTituloDto: UpdateTituloDto): Promise<TituloPagina> {
    const { numPagina, titulo, subdominio } = updateTituloDto; // ¡Ahora extrae el subdominio!

    // 1. Buscar el título existente para esta combinación de numPagina y subdominio
    const existingTitulo = await this.tituloPaginaRepository.findOne({
      where: { numPagina, subdominio },
    });

    let savedTitulo: TituloPagina;

    if (existingTitulo) {
      // Si existe, actualizamos
      existingTitulo.titulo = titulo;
      savedTitulo = await this.tituloPaginaRepository.save(existingTitulo);
    } else {
      // Si no existe, creamos uno nuevo
      const nuevoTitulo = this.tituloPaginaRepository.create({ numPagina, titulo, subdominio }); // Asegúrate de asignar el subdominio
      savedTitulo = await this.tituloPaginaRepository.save(nuevoTitulo);
    }

   
    return savedTitulo;
  }

  async removeTituloByPaginaAndSubdomain(numPagina: number, subdominio: string): Promise<void> {
    const result = await this.tituloPaginaRepository.delete({ numPagina, subdominio });
    if (result.affected === 0) {
      throw new NotFoundException(`Título de página ${numPagina} para subdominio ${subdominio} no encontrado.`);
    }
  }
}