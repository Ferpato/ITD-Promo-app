/* eslint-disable prettier/prettier */
// src/titulos/titulos.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TitulosController } from './titulo.controller';
import { TitulosService } from './titulo.service'; // <-- Asegúrate de que esta ruta sea correcta
import { TituloPagina } from './titulos.entity'; // <-- Asegúrate de que esta ruta sea correcta

@Module({
  imports: [
    TypeOrmModule.forFeature([TituloPagina]),
  ],
  controllers: [TitulosController],
  providers: [TitulosService],
  exports: [TitulosService],
})
export class TitulosModule {}