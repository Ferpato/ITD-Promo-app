/* eslint-disable prettier/prettier */

import { IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateTituloDto {
  @IsNumber()
  @ApiProperty({ description: 'Identificador numérico de la página a la que pertenece el título', example: 0 })
  numPagina: number;

  @IsString()
  @ApiProperty({ description: 'El texto del título de la página', example: 'Profesionistas especializados...' })
  titulo: string;
 
  @ApiProperty({ description: 'Subdominio al que pertenece este título de página', example: 'default' })
  @IsString()
 
  @IsNotEmpty()
  subdominio: string;
  
}