/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */

import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';
import { SubdomainService } from './subdomain/subdomain.services'; 

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // --- Get ConfigService and SubdomainService instances ---
  const configService = app.get(ConfigService);
  const subdomainsService = app.get(SubdomainService); 
  // Global validation pipe configuration
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    forbidNonWhitelisted: true,
    transform: true,
    transformOptions: {
      enableImplicitConversion: true,
    },
  }));

  // --- START DYNAMIC CORS CONFIGURATION ---
  console.log('--- Advanced Dynamic CORS Configuration ---');

  // Explicitly allowed origins (from FRONTEND_URL in .env) - e.g., your dashboard's URL
  const allowedOriginsString = configService.get<string>('FRONTEND_URL');
  const explicitAllowedOrigins = allowedOriginsString
    ? allowedOriginsString.split(',').map(s => s.trim()).filter(s => s.length > 0)
    : [];
  //console.log('DEBUG: Explicitly allowed origins (from FRONTEND_URL):', explicitAllowedOrigins);

  // Base domain for dynamic subdomains (from PRODUCTION_DOMAIN in .env) - e.g., 'localhost' for dev, 'yourdomain.com' for prod
  const productionDomain = configService.get<string>('PRODUCTION_DOMAIN');
 // console.log('DEBUG: Base domain for dynamic subdomains (PRODUCTION_DOMAIN):', `"${productionDomain}"`);

  app.enableCors({
    origin: async (origin, callback) => { // <-- The 'origin' function is now ASYNC
   //   console.log(`CORS Check: Request origin is '${origin}'`);

      // 1. Check if the origin is in the explicit list (e.g., your main dashboard)
      const isExplicitlyAllowed = origin && explicitAllowedOrigins.includes(origin);
      if (isExplicitlyAllowed) {
        //console.log(`CORS Allowed: Explicit origin '${origin}'.`);
        return callback(null, true);
      }

      // 2. Allow null origins (for tools like Postman, curl, or local files)
      const isNullOrigin = !origin;
      if (isNullOrigin) {
        //console.log(`CORS Allowed: Origin is null (likely Postman or local file).`);
        return callback(null, true);
      }

      // 3. Logic for dynamic subdomains (REQUIRES DATABASE LOOKUP)
      if (origin && productionDomain) {
        try {
          const url = new URL(origin);
          const hostname = url.hostname;

          // Check if the hostname ends with .PRODUCTION_DOMAIN and is not just the PRODUCTION_DOMAIN itself
          if (hostname.endsWith(`.${productionDomain}`) && hostname !== productionDomain) {
            const subdomainName = hostname.substring(0, hostname.length - `.${productionDomain}`.length);
          //  console.log(`CORS Check: Potential dynamic subdomain detected: '${subdomainName}'. Querying DB...`);

            // --- THIS IS WHERE WE QUERY THE DATABASE! ---
            // We use findByNombre which returns Subdomain | null
            const subdomainInDb = await subdomainsService.findByNombre(subdomainName);

            if (subdomainInDb) {
              //console.log(`CORS Allowed: Subdomain '${subdomainName}' FOUND in DB.`);
              return callback(null, true);
            } else {
             // console.warn(`CORS BLOCKED: Subdomain '${subdomainName}' NOT FOUND in DB.`);
            }
          } else if (hostname === productionDomain) {
            // Allow the base production domain itself (e.g., if you access http://localhost:3000 and PRODUCTION_DOMAIN is localhost)
            //console.log(`CORS Allowed: Origin '${origin}' is the base production domain.`);
            return callback(null, true);
          }
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        } catch (e) {
          //console.error(`CORS Error: Failed to process origin '${origin}' or query DB.`, e);
        }
      }

      // If none of the above rules allowed the origin, block it
      //console.error(`CORS BLOCKED: Origin '${origin}' not allowed by any rule.`);
      callback(new Error(`Not allowed by CORS: ${origin}`));
    },
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true,
  });
  // --- END DYNAMIC CORS CONFIGURATION ---

  // --- Swagger Configuration ---
  const config = new DocumentBuilder()
    .setTitle('API del ITD - Backend')
    .setDescription('Documentación de la API para el sitio web del Instituto Tecnológico de Durango')
    .setVersion('1.0')
    .addTag('Subdominios', 'Operaciones para gestionar subdominios válidos')
    .addTag('Titulos de Pagina', 'Operaciones para gestionar los títulos de las páginas por subdominio')
    .addTag('parrafos-oferta', 'Operaciones para gestionar los párrafos de oferta por subdominio')
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document);

  await app.listen(3001, '127.0.0.1');

  //console.log(`NestJS Application running at ${await app.getUrl()}`);
  //console.log(`Swagger UI available at ${await app.getUrl()}/api`);
}

bootstrap();