/* eslint-disable prettier/prettier */
import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('UsuariosAdmin') // El decorador @Entity() mapea esta clase a la tabla 'UsuariosAdmin' en tu DB
export class UsuariosAdmin {
  @PrimaryGeneratedColumn() // Define 'id' como la columna de clave primaria autoincremental
  id: number;

  @Column({ unique: true, name: 'Usuario' }) // Mapea a la columna 'Usuario' y asegura que sea única
  usuario: string; // Nombre de la propiedad en tu clase de TypeScript

  @Column({ name: 'Contrasena' }) // Mapea a la columna 'Contraseña'
  contrasena: string; // Nombre de la propiedad en tu clase de TypeScript

  // NOTA IMPORTANTE: En un entorno de producción, la columna 'Contraseña' DEBE almacenar
  // las contraseñas hasheadas (ej. con bcrypt), NO en texto plano.
  // La comparación de contraseñas también debería usar bcrypt.compare().
}