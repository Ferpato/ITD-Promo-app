/* eslint-disable prettier/prettier */

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm'; // Importa TypeOrmModule
import { SubdominiosService } from './subdominio.service'; // Importa el servicio
import { SubdominiosController } from './subdominio.controller'; // Importa el controlador
import { Subdominio } from './subdominios.entity'; // Importa la entidad

@Module({
  imports: [TypeOrmModule.forFeature([Subdominio])], // Registra la entidad para este módulo
  controllers: [SubdominiosController],
  providers: [SubdominiosService],
  exports: [SubdominiosService, TypeOrmModule] // Exporta el servicio y el módulo de TypeORM si necesitas usarlos en otros módulos
})
export class SubdominiosModule {}