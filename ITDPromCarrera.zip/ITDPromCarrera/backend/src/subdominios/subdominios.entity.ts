/* eslint-disable prettier/prettier */
// src/subdominios/entities/subdominio.entity.ts
import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger'; // Para la documentación de Swagger

@Entity('subdominios')
export class Subdominio {
  @ApiProperty({ description: 'ID único del subdominio', readOnly: true })
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ description: 'Nombre único del subdominio (ej. marketing, ingenieria)', example: 'marketing' })
  @Column({ type: 'varchar', length: 255, unique: true, nullable: false })
  nombre: string;
}