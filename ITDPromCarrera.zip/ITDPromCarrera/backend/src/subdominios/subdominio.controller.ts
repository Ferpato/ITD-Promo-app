/* eslint-disable prettier/prettier */
// src/subdominios/subdominios.controller.ts
import { Controller, Get, Post, Body, Patch, Param, Delete, HttpCode, HttpStatus, NotFoundException } from '@nestjs/common';
import { SubdominiosService } from './subdominio.service'; // Importa el servicio
import { CreateSubdominioDto } from './dto/subdominios.dto'; // Importa el DTO de creación
import { UpdateSubdominioDto } from './dto/update.subdominio.dto'; // Importa el DTO de actualización
import { ApiTags, ApiResponse, ApiOperation, ApiBody, ApiParam } from '@nestjs/swagger'; // Para Swagger

@ApiTags('Subdominios') // Etiqueta para agrupar en la documentación de Swagger
@Controller('admin/subdominios') // Ruta base para este controlador en tu API
export class SubdominiosController {
  constructor(private readonly subdominiosService: SubdominiosService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED) // Retorna 201 Created si es exitoso
  @ApiOperation({ summary: 'Crea un nuevo subdominio' })
  @ApiBody({ type: CreateSubdominioDto }) // Define el cuerpo de la petición para Swagger
  @ApiResponse({ status: 201, description: 'El subdominio ha sido creado exitosamente.', type: CreateSubdominioDto })
  @ApiResponse({ status: 409, description: 'El subdominio ya existe.' })
  async create(@Body() createSubdominioDto: CreateSubdominioDto) {
    return this.subdominiosService.create(createSubdominioDto);
  }

  @Get()
  @ApiOperation({ summary: 'Obtiene todos los subdominios registrados' })
  @ApiResponse({ status: 200, description: 'Lista de subdominios.', type: [CreateSubdominioDto] })
  findAll() {
    return this.subdominiosService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obtiene un subdominio por su ID' })
  @ApiParam({ name: 'id', description: 'ID del subdominio', type: Number })
  @ApiResponse({ status: 200, description: 'Detalles del subdominio.', type: CreateSubdominioDto })
  @ApiResponse({ status: 404, description: 'Subdominio no encontrado.' })
  findOne(@Param('id') id: string) {
    return this.subdominiosService.findOne(+id); // Convierte el ID de string a number
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Actualiza un subdominio existente por su ID' })
  @ApiParam({ name: 'id', description: 'ID del subdominio a actualizar', type: Number })
  @ApiBody({ type: UpdateSubdominioDto })
  @ApiResponse({ status: 200, description: 'El subdominio ha sido actualizado exitosamente.', type: CreateSubdominioDto })
  @ApiResponse({ status: 404, description: 'Subdominio no encontrado.' })
  @ApiResponse({ status: 409, description: 'El nuevo nombre de subdominio ya existe.' })
  update(@Param('id') id: string, @Body() updateSubdominioDto: UpdateSubdominioDto) {
    return this.subdominiosService.update(+id, updateSubdominioDto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT) // Retorna 204 No Content si la eliminación es exitosa
  @ApiOperation({ summary: 'Elimina un subdominio por su ID y todo su contenido asociado (Requiere lógica adicional)' })
  @ApiParam({ name: 'id', description: 'ID del subdominio a eliminar', type: Number })
  @ApiResponse({ status: 204, description: 'El subdominio ha sido eliminado exitosamente.' })
  @ApiResponse({ status: 404, description: 'Subdominio no encontrado.' })
  async remove(@Param('id') id: string) {
    // Necesitamos obtener el nombre del subdominio ANTES de eliminarlo de la tabla 'subdominios'
    // para poder usar ese nombre para eliminar datos asociados en otras tablas.
    const subdominioToDelete = await this.subdominiosService.findOne(+id);
    if (!subdominioToDelete) {
      throw new NotFoundException(`Subdominio con ID ${id} no encontrado.`);
    }

  

    await this.subdominiosService.remove(+id); // Elimina el registro del subdominio de la tabla 'subdominios'
  }
}