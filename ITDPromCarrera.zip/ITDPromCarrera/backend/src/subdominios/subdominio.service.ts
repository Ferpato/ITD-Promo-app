/* eslint-disable prettier/prettier */
// src/subdominios/subdominios.service.ts
import { Injectable, ConflictException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Subdominio } from './subdominios.entity'; // Importa la entidad Subdominio
import { CreateSubdominioDto } from './dto/subdominios.dto'; // Importa el DTO de creación
import { UpdateSubdominioDto } from './dto/update.subdominio.dto'; // Importa el DTO de actualización

@Injectable()
export class SubdominiosService {
  constructor(
    @InjectRepository(Subdominio)
    private subdominiosRepository: Repository<Subdominio>,
  ) {}

  async create(createSubdominioDto: CreateSubdominioDto): Promise<Subdominio> {
    const { nombre } = createSubdominioDto;
    // Verifica si el subdominio ya existe antes de crearlo
    const existingSubdomain = await this.subdominiosRepository.findOne({ where: { nombre } });
    if (existingSubdomain) {
      throw new ConflictException(`El subdominio '${nombre}' ya existe.`);
    }

    const newSubdominio = this.subdominiosRepository.create(createSubdominioDto);
    return this.subdominiosRepository.save(newSubdominio);
  }

  async findAll(): Promise<Subdominio[]> {
    return this.subdominiosRepository.find({ order: { nombre: 'ASC' } });
  }

  async findOne(id: number): Promise<Subdominio> {
    const subdominio = await this.subdominiosRepository.findOne({ where: { id } });
    if (!subdominio) {
      throw new NotFoundException(`Subdominio con ID ${id} no encontrado.`);
    }
    return subdominio;
  }

  async findOneByName(nombre: string): Promise<Subdominio | null> {
    return this.subdominiosRepository.findOne({ where: { nombre } });
  }

  async update(id: number, updateSubdominioDto: UpdateSubdominioDto): Promise<Subdominio> {
    const existingSubdomain = await this.subdominiosRepository.findOne({ where: { id } });
    if (!existingSubdomain) {
      throw new NotFoundException(`Subdominio con ID ${id} no encontrado.`);
    }

    // Si se intenta cambiar el nombre, verificar que el nuevo nombre no exista ya en otro subdominio
    if (updateSubdominioDto.nombre && updateSubdominioDto.nombre !== existingSubdomain.nombre) {
      const nameConflict = await this.subdominiosRepository.findOne({ where: { nombre: updateSubdominioDto.nombre } });
      if (nameConflict) {
        throw new ConflictException(`El subdominio '${updateSubdominioDto.nombre}' ya existe.`);
      }
    }

    // Actualiza solo las propiedades que vienen en el DTO
    Object.assign(existingSubdomain, updateSubdominioDto);
    return this.subdominiosRepository.save(existingSubdomain);
  }

  async remove(id: number): Promise<void> {
    const subdominioToRemove = await this.subdominiosRepository.findOne({ where: { id } });
    if (!subdominioToRemove) {
      throw new NotFoundException(`Subdominio con ID ${id} no encontrado.`);
    }

    // Por ahora, solo elimina el registro del subdominio de esta tabla.
    // La eliminación de datos asociados en otras tablas se gestionará en el controlador.
    await this.subdominiosRepository.remove(subdominioToRemove);
  }
}