/* eslint-disable prettier/prettier */

import { PartialType } from '@nestjs/swagger';
import { CreateSubdominioDto } from './subdominios.dto';

// Hace que todas las propiedades de CreateSubdominioDto sean opcionales para la actualización.
export class UpdateSubdominioDto extends PartialType(CreateSubdominioDto) {}