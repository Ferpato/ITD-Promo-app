/* eslint-disable prettier/prettier */

import { IsString, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateSubdominioDto {
  @ApiProperty({ description: 'Nombre único del subdominio (ej. marketing, ingenieria)', example: 'marketing' })
  @IsString()
  @IsNotEmpty()
  nombre: string;
}