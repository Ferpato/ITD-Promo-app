/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unused-vars */



/* eslint-disable prefer-const */

// src/main/main.controller.ts
import { Controller, Get, Put, Body, HttpStatus, UseGuards, Request } from '@nestjs/common'; // Importa UseGuards y Request
import { MainService } from './main.service';
import { MainDto } from './dto/main.dto';
import { GetSubdomain } from 'src/decorators/get-subdomain.decorator';
import { ApiTags, ApiOperation, ApiResponse, ApiHeader, ApiBody, ApiBearerAuth } from '@nestjs/swagger'; // Importa ApiBearerAuth
import { JwtAuthGuard } from 'src/AuthModule/jwt.auth.guard';


@ApiTags('Configuración Principal')
@Controller('admin/dashboard/inicio')
                                    
                                
export class MainController {
  constructor(private readonly mainService: MainService) {}

  // Función auxiliar para generar una configuración por defecto
  private getDefaultMainConfig(subdominio: string) {
    return {
      subdominio: subdominio,
      Titulo: '',
      TextoBotonSuperior: '',
      LinkBotonSuperior: '',
      Color1BotonSuperior: 'from-guinda', // Default colors
      Color2BotonSuperior: 'to-vino',    // Default colors
      TextoBotonInferior: '',
      LinkBotonInferior: '',
      Color1BotonInferior: 'from-guinda', // Default colors
      Color2BotonInferior: 'to-vino',    // Default colors
    };
  }

  // =========================================================
  // --- Endpoint Público (Lectura) ---
  // =========================================================
  @Get()
  @ApiOperation({ summary: 'Obtener la configuración principal para un subdominio (Público)' })
  @ApiHeader({
    name: 'X-Subdomain',
    description: 'El subdominio para el cual obtener la configuración (ej. "marketing", "default").',
    required: true,
    example: 'marketing',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Configuración encontrada, o valores por defecto/vacíos si no existe para el subdominio específico.',
    type: MainDto,
  })
  async getConfig(@GetSubdomain() subdominio: string) {
    let config = await this.mainService.findOne(subdominio);

    if (!config) {
      //  console.log(`[MainController] No config found for subdomain "${subdominio}". Returning default structure.`);
        return this.getDefaultMainConfig(subdominio);
    }
    
    return config;
  }

  // =========================================================
  // --- Endpoint Protegido (Escritura/Actualización) ---
  // =========================================================
  @UseGuards(JwtAuthGuard) // <--- ¡Aplica la guardia JWT aquí!
  @ApiBearerAuth() // <--- Indica en Swagger que esta ruta requiere autenticación
  @Put()
  @ApiOperation({ summary: 'Crear o actualizar la configuración principal para un subdominio (Protegido - Admin)' })
  @ApiHeader({
    name: 'X-Subdomain',
    description: 'El subdominio para el cual crear o actualizar la configuración (ej. "marketing", "default").',
    required: true,
    example: 'marketing',
  })
  @ApiBody({ type: MainDto, description: 'Datos de la configuración principal a guardar.' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Configuración creada o actualizada exitosamente.',
    type: MainDto,
  })
  @ApiResponse({ status: 401, description: 'No autorizado. Token inválido o no proporcionado.' }) // Agrega para Swagger
  @ApiResponse({ status: 403, description: 'Prohibido. No tiene permisos para esta acción.' }) // Agrega para Swagger
  async createOrUpdateConfig(@Body() mainDto: MainDto, @GetSubdomain() subdominio: string, @Request() req) {
   // console.log(`Admin ${req.user.username} intentando crear/actualizar configuración principal para ${subdominio}.`);
    return this.mainService.createOrUpdate(subdominio, mainDto);
  }
}