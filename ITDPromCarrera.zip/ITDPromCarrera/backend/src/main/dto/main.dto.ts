/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */


import { IsString, IsOptional, IsUrl, ValidateIf, IsNotEmpty } from 'class-validator'; // ¡Importamos IsNotEmpty!
import { ApiProperty } from '@nestjs/swagger';

export class MainDto {
  @ApiProperty({
    description: 'Título principal de la sección',
    example: 'Bienvenido a la página principal',
    required: true, // Ahora es requerido para Swagger
  })

  @IsString({ message: 'El título principal debe ser una cadena de texto.' })
  @IsNotEmpty({ message: 'El título principal no puede estar vacío.' })
  Titulo: string; // Ya no es opcional aquí (no lleva '?')

  @ApiProperty({
    description: 'Texto del botón superior',
    example: 'Ver Más',
    required: true, // Ahora es requerido para Swagger
  })
  // ¡QUITAMOS @IsOptional()!
  @IsString({ message: 'El texto del botón superior debe ser una cadena de texto.' })
  @IsNotEmpty({ message: 'El texto del botón superior no puede estar vacío.' }) 
  TextoBotonSuperior: string; 

  @ApiProperty({
    description: 'Enlace (URL) del botón superior',
    example: 'https://example.com/superior',
    required: false,
    nullable: true,
  })
  @IsOptional()
  @IsString({ message: 'El enlace del botón superior debe ser texto.' })
  @ValidateIf(o => o.LinkBotonSuperior !== null && o.LinkBotonSuperior !== '')
  @IsUrl({}, { message: 'El enlace del botón superior debe ser una URL válida.' })
  LinkBotonSuperior?: string; 

  @ApiProperty({
    description: 'Primer color del gradiente del botón superior (ej. CSS color keyword o hex)',
    example: 'blue',
    required: false,
  })
  @IsOptional()
  @IsString()
  Color1BotonSuperior?: string;

  @ApiProperty({
    description: 'Segundo color del gradiente del botón superior (ej. CSS color keyword o hex)',
    example: 'lightblue',
    required: false,
  })
  @IsOptional()
  @IsString()
  Color2BotonSuperior?: string;

  @ApiProperty({
    description: 'Texto del botón inferior',
    example: 'Contactar',
    required: true, // Ahora es requerido para Swagger
  })
  // ¡QUITAMOS @IsOptional()!
  @IsString({ message: 'El texto del botón inferior debe ser una cadena de texto.' })
  @IsNotEmpty({ message: 'El texto del botón inferior no puede estar vacío.' }) // ¡Nuevo decorador!
  TextoBotonInferior: string;

  @ApiProperty({
    description: 'Enlace (URL) del botón inferior',
    example: 'https://www.facebook.com/ITDgoOficial',
    required: false,
    nullable: true,
  })
  @IsOptional()
  @IsString({ message: 'El enlace del botón inferior debe ser texto.' })
  @ValidateIf(o => o.LinkBotonInferior !== null && o.LinkBotonInferior !== '')
  @IsUrl({}, { message: 'El enlace del botón inferior debe ser una URL válida.' })
  LinkBotonInferior?: string;

  @ApiProperty({
    description: 'Primer color del gradiente del botón inferior (ej. CSS color keyword o hex)',
    example: 'green',
    required: false,
  })
  @IsOptional()
  @IsString()
  Color1BotonInferior?: string;

  @ApiProperty({
    description: 'Segundo color del gradiente del botón inferior (ej. CSS color keyword o hex)',
    example: 'lightgreen',
    required: false,
  })
  @IsOptional()
  @IsString()
  Color2BotonInferior?: string;
}