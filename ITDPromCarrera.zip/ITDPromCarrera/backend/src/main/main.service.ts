/* eslint-disable prettier/prettier */
// src/main/main.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MainConfig } from './main.entity';
import { MainDto } from './dto/main.dto';

@Injectable()
export class MainService {
  constructor(
    @InjectRepository(MainConfig)
    private readonly mainRepository: Repository<MainConfig>,
  ) {}

  async findOne(subdominio: string): Promise<MainConfig | null> {
    return this.mainRepository.findOne({ where: { subdominio } });
  }

  async createOrUpdate(subdominio: string, mainDto: MainDto): Promise<MainConfig> {
    let mainConfig = await this.mainRepository.findOne({ where: { subdominio } });

    if (mainConfig) {
      Object.assign(mainConfig, mainDto);
    } else {
      mainConfig = this.mainRepository.create({ ...mainDto, subdominio });
    }

    return this.mainRepository.save(mainConfig);
  }
}