/* eslint-disable prettier/prettier */
// src/main/entities/main.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, Unique } from 'typeorm';

@Entity('inicio')
@Unique(['subdominio'])
export class MainConfig {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ nullable: true })
  Titulo: string;

  @Column({ nullable: true })
  TextoBotonSuperior: string;

  @Column({ nullable: true }) 
  LinkBotonSuperior: string;

  @Column({ nullable: true })
  Color1BotonSuperior: string;

  @Column({ nullable: true })
  Color2BotonSuperior: string;

  @Column({ nullable: true })
  TextoBotonInferior: string;

  @Column({ nullable: true }) // Ya está nullable, no hay cambio.
  LinkBotonInferior: string;

  @Column({ nullable: true })
  Color1BotonInferior: string;

  @Column({ nullable: true })
  Color2BotonInferior: string;

  @Column()
  subdominio: string;
}