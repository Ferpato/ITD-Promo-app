/* eslint-disable prettier/prettier */

import { Module } from '@nestjs/common';
import { MainService } from './main.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MainConfig } from './main.entity';
import { MainController } from './main.controller';


@Module({
  imports: [TypeOrmModule.forFeature([MainConfig])],
  providers: [MainService],
  controllers: [MainController], 
  exports: [MainService],
})
export class MainModule {}