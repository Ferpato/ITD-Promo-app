/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Comentario } from './comentarios.entity'; // Asegúrate de que esta ruta y nombre de entidad sean correctos

@Module({
  imports: [
    TypeOrmModule.forFeature([Comentario]), // Registra la entidad Comentario
  ],
  // No necesitamos 'providers' o 'controllers' por ahora si no hay un servicio/controlador CRUD individual
  exports: [TypeOrmModule], // Exporta TypeOrmModule para que SeccionesModule pueda acceder a los repositorios si es necesario
})
export class ComentariosModule {}