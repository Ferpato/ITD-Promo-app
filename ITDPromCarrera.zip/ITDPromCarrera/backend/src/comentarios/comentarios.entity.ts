/* eslint-disable prettier/prettier */
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Seccion } from '../secciones/secciones.entity'; // Asegúrate de que la ruta a la entidad Seccion sea correcta

@Entity('Comentarios') // Mapea a la tabla 'Comentarios' en la base de datos
export class Comentario {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 255, nullable: false }) // Título del comentario, asumo obligatorio
  titulo: string;

  @Column({ type: 'text', nullable: false }) // Contenido del comentario, asumo obligatorio. Usamos 'text' para longitud variable.
  contenido: string;

  @Column({ type: 'varchar', length: 255, nullable: false }) // Color de inicio del gradiente, asumo obligatorio
  color1: string;

  @Column({ type: 'varchar', length: 255, nullable: false }) // Color final del gradiente, asumo obligatorio
  color2: string;

  @Column({ name: 'seccionId' }) // Nombre explícito de la columna en la DB para la FK
  seccionId: number; // Columna para la llave foránea

  // Relación ManyToOne con la entidad Seccion
  // Muchos Comentarios pueden pertenecer a una Seccion
  @ManyToOne(() => Seccion, seccion => seccion.comentarios, {
    onDelete: 'CASCADE', // Si se elimina una sección, los comentarios asociados también se eliminan
    orphanedRowAction: 'delete', // Elimina comentarios si pierden su sección (opcional)
  })
  @JoinColumn({ name: 'seccionId' }) // Indica que 'seccionId' es la columna FK
  seccion: Seccion; // Propiedad para la relación, no se almacena directamente en la DB
}