/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config'; 
import { MainModule } from './main/main.module';
import { TitulosModule } from './titulos/titulos.module';
import { OfertaModule } from './oferta/oferta.module';
import { SubdomainsModule } from './subdomain/subdomain.module';
import { Subdomain } from './subdomain/subdomain.entity'; 
import { MainConfig } from './main/main.entity';
import { TituloPagina } from './titulos/titulos.entity';
import { OfertaParrafo } from './oferta/oferta.entity';

import { Seccion } from './secciones/secciones.entity';
import { Carrusel } from './carruseles/carruseles.entity';
import { Comentario } from './comentarios/comentarios.entity';
import { SeccionesModule } from './secciones/secciones.module';
import { CarruselesModule } from './carruseles/carruseles.module';
import { ComentariosModule } from './comentarios/comentarios.module';
import { ParagraphGroup } from './materias/materias.entity';
import { MateriasModule } from './materias/materias.module';
import { UsuariosAdmin } from './Usuarios/Usuarios.entity';
import { AuthModule } from './AuthModule/auth.module';


@Module({
  imports: [
    // ConfigModule debe ser el primero en importarse para que las variables de entorno
    // estén disponibles para otros módulos que dependan de ellas.
    ConfigModule.forRoot({
      isGlobal: true, // Esto hace que ConfigService esté disponible en toda la aplicación
    }),

    // TypeOrmModule.forRootAsync es mejor para usar ConfigService
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule], 
      inject: [ConfigService], 
      useFactory: (configService: ConfigService) => ({
        type: 'postgres',
        host: configService.get<string>('DB_HOST'),
        port: configService.get<number>('DB_PORT'),
        username: configService.get<string>('DB_USERNAME'),
        password: configService.get<string>('DB_PASSWORD'),
        database: configService.get<string>('DB_DATABASE_NAME'),
        
        entities: [
          Subdomain, 
          
          TituloPagina,
          OfertaParrafo,
          MainConfig,
          Seccion,
          Carrusel,
          Comentario,
          ParagraphGroup,
          UsuariosAdmin,
          
        
        
        ],
        synchronize: false, 
        
      }),
    }),

    // Tus módulos de características

    MainModule,
    TitulosModule,
    OfertaModule,
    SubdomainsModule,
    SeccionesModule,
    CarruselesModule, 
    ComentariosModule, 
    MateriasModule,
    AuthModule,
   
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}