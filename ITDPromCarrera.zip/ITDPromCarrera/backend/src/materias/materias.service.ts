/* eslint-disable prettier/prettier */
/* eslint-disable no-useless-escape */

/// src/materias/materias.service.ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ParagraphGroup } from './materias.entity'; // Importa tu entidad ParagraphGroup
import { CreateParagraphGroupDto } from './materias.dto';


@Injectable()
export class MateriasService {
  constructor(
    @InjectRepository(ParagraphGroup)
    private paragraphGroupRepository: Repository<ParagraphGroup>,
    // Eliminada la inyección de PageTitleRepository
  ) {}

  /**
   * Crea un nuevo grupo de párrafo en la base de datos.
   * @param createDto Los datos del grupo de párrafo a crear.
   * @returns El grupo de párrafo recién creado.
   */
  async createParagraphGroup(createDto: CreateParagraphGroupDto): Promise<ParagraphGroup> {
    const newGroup = this.paragraphGroupRepository.create(createDto);
    //console.log(`[MateriasService] Creando grupo para subdominio (desde DTO): "${createDto.subdominio}"`); // <-- Importante
    return this.paragraphGroupRepository.save(newGroup);
  }

  /**
   * Elimina todos los grupos de párrafo asociados a un subdominio específico.
   * ¡Cuidado: Esta operación es destructiva! Asegúrate de que los permisos estén bien controlados.
   * @param subdomain El subdominio cuyos grupos de párrafo se eliminarán.
   */
  async deleteAllParagraphGroups(subdomain: string): Promise<void> {
    await this.paragraphGroupRepository.delete({ subdominio: subdomain });
   // console.log(`[MateriasService] Ejecutando DELETE para subdominio: "${subdomain}"`); // <-- Importante
   // console.log(`[MateriasService] Eliminados <span class="math-inline">\{result\.affected\} registros para subdominio\: "</span>{subdomain}"`);
  }

  // ELIMINADO: updateOrCreateTitle ya que se maneja externamente
  // async updateOrCreateTitle(numPagina: number, subdomain: string, titulo: string): Promise<any> { ... }

  /**
   * Obtiene todos los grupos de párrafo para un subdominio específico.
   * @param subdomain El subdominio para el cual se buscarán los grupos de párrafo.
   * @returns Un array de grupos de párrafo.
   */
  async findAllParagraphGroups(subdomain: string): Promise<ParagraphGroup[]> {
    return this.paragraphGroupRepository.find({
      where: { subdominio: subdomain },
      order: { id: 'ASC' } // Opcional: ordenar por ID para consistencia
    });
  }

  // ELIMINADO: getPageTitle ya que se maneja externamente
  // async getPageTitle(numPagina: number, subdomain: string): Promise<string> { ... }

  /**
   * Elimina un solo grupo de párrafo por su ID y subdominio.
   * @param id El ID del grupo de párrafo a eliminar.
   * @param subdomain El subdominio al que pertenece el grupo de párrafo.
   * @throws NotFoundException si el grupo de párrafo no se encuentra para el ID y subdominio dados.
   */
  async removeParagraphGroup(id: number, subdomain: string): Promise<void> {
    const result = await this.paragraphGroupRepository.delete({ id, subdominio: subdomain });
    if (result.affected === 0) {
      throw new NotFoundException(`Paragraph group with ID ${id} not found for subdomain ${subdomain}`);
    }
  }
}