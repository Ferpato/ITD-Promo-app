/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unused-vars */


// src/materias/materias.controller.ts
import { Controller, Get, Post, Body, Delete, Param, UsePipes, ValidationPipe, UseGuards, Request } from '@nestjs/common'; // Importa UseGuards y Request
import { MateriasService } from './materias.service';
import { CreateParagraphGroupDto } from './materias.dto';
import { GetSubdomain } from '../decorators/get-subdomain.decorator';

import { ApiTags, ApiBearerAuth, ApiOperation, ApiResponse } from '@nestjs/swagger'; // Importa decoradores de Swagger
import { JwtAuthGuard } from 'src/AuthModule/jwt.auth.guard';

@ApiTags('Materias') // Agrupa en Swagger
@Controller('materias')
@UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
export class MateriasController {
  constructor(private readonly materiasService: MateriasService) {}

  // =========================================================
  // --- Endpoints para el frontend público (Lectura) ---
  // =========================================================
  @Get('paragraph-groups')
  @ApiOperation({ summary: 'Obtiene todos los grupos de párrafos para una página de Materias (público).' })
  @ApiResponse({ status: 200, description: 'Grupos de párrafos encontrados.' })
  async getParagraphGroups(@GetSubdomain() subdomain: string) {
    return this.materiasService.findAllParagraphGroups(subdomain);
  }

  // =========================================================
  // --- Endpoints para la administración (Escritura y Borrado) ---
  // Estos deben estar PROTEGIDOS con JwtAuthGuard.
  // =========================================================

  @UseGuards(JwtAuthGuard) // <--- ¡Aplica la guardia JWT aquí!
  @ApiBearerAuth() // <--- Indica en Swagger que esta ruta requiere autenticación
  @ApiOperation({ summary: 'Elimina TODOS los grupos de párrafos de Materias para un subdominio (admin).' })
  @ApiResponse({ status: 200, description: 'Grupos de párrafos eliminados exitosamente.' })
  @ApiResponse({ status: 401, description: 'No autorizado.' })
  @Delete('admin/paragraph-groups/delete-all')
  async deleteAllParagraphGroups(@GetSubdomain() subdomain: string, @Request() req) {
    //console.log(`Admin ${req.user.username} intentando eliminar todos los grupos de párrafos para ${subdomain}.`);
    await this.materiasService.deleteAllParagraphGroups(subdomain);
    return { message: 'All paragraph groups deleted successfully for this subdomain.' };
  }

  @UseGuards(JwtAuthGuard) // <--- ¡Aplica la guardia JWT aquí!
  @ApiBearerAuth() // <--- Indica en Swagger que esta ruta requiere autenticación
  @ApiOperation({ summary: 'Crea o actualiza un grupo de párrafos de Materias (admin).' })
  @ApiResponse({ status: 201, description: 'Grupo de párrafos creado/actualizado exitosamente.' })
  @ApiResponse({ status: 401, description: 'No autorizado.' })
  @Post('admin/paragraph-groups')
  async createParagraphGroup(@Body() createParagraphGroupDto: CreateParagraphGroupDto, @GetSubdomain() subdomainFromRequest: string, @Request() req) {
   // console.log(`Admin ${req.user.username} intentando crear/actualizar grupo de párrafos para ${subdomainFromRequest}.`);
    createParagraphGroupDto.subdominio = subdomainFromRequest;
    return this.materiasService.createParagraphGroup(createParagraphGroupDto);
  }

  @UseGuards(JwtAuthGuard) // <--- ¡Aplica la guardia JWT aquí!
  @ApiBearerAuth() // <--- Indica en Swagger que esta ruta requiere autenticación
  @ApiOperation({ summary: 'Elimina un grupo de párrafos de Materias por ID (admin).' })
  @ApiResponse({ status: 200, description: 'Grupo de párrafos eliminado exitosamente.' })
  @ApiResponse({ status: 401, description: 'No autorizado.' })
  @Delete('admin/paragraph-groups/:id')
  async removeParagraphGroup(@Param('id') id: string, @GetSubdomain() subdomain: string, @Request() req) {
    //console.log(`Admin ${req.user.username} intentando eliminar grupo de párrafos con ID ${id} para ${subdomain}.`);
    await this.materiasService.removeParagraphGroup(+id, subdomain);
    return { message: `Paragraph group with ID ${id} deleted successfully.` };
  }
}