/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */


import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('ParagraphGroup') // Asegúrate de que el nombre de la tabla coincida con tu SQL
export class ParagraphGroup {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 255, nullable: false })
  subdominio: string;

  // --- Campos del primer párrafo (firstItem) ---
  @Column({ type: 'varchar', length: 255, nullable: false })
  firstItemTitle: string;

  @Column({ type: 'text', nullable: false })
  firstItemContent: string;

  @Column({ type: 'varchar', length: 50, nullable: false })
  firstItemGradientFrom: string;

  @Column({ type: 'varchar', length: 50, nullable: false })
  firstItemGradientTo: string;

  @Column({ type: 'boolean', nullable: false })
  firstItemLineDecoration: boolean;

  @Column({ type: 'boolean', nullable: false })
  firstItemOverLined: boolean;

  // --- Campos del segundo párrafo (secondItemParagraph) ---
  // Estos campos son nullable porque solo existen si el segundo elemento es un párrafo
  @Column({ type: 'varchar', length: 255, nullable: true, default: null })
  secondItemTitle: string | null;

  @Column({ type: 'text', nullable: true, default: null })
  secondItemContent: string | null;

  @Column({ type: 'varchar', length: 50, nullable: true, default: null })
  secondItemGradientFrom: string | null;

  @Column({ type: 'varchar', length: 50, nullable: true, default: null })
  secondItemGradientTo: string | null;

  @Column({ type: 'boolean', nullable: true, default: null })
  secondItemLineDecoration: boolean | null;

  @Column({ type: 'boolean', nullable: true, default: null })
  secondItemOverLined: boolean | null;

  // --- Tipo del segundo elemento (none, paragraph, carousel) ---
  // Este campo es crucial para saber cómo interpretar los campos opcionales
  @Column({ type: 'enum', enum: ['none', 'paragraph', 'carousel'], default: 'none', nullable: false })
  secondItemType: 'none' | 'paragraph' | 'carousel';


  // --- Campos para el carrusel (secondItemCarouselItems) ---
  // Este campo es nullable porque solo existe si el segundo elemento es un carrusel
  // Usaremos un transformer para convertir el array de strings a un string JSON y viceversa
  @Column({
    type: 'text',
    nullable: true,
    default: null, // Aseguramos que el valor por defecto en la DB sea NULL
    transformer: {
      from: (value: string | null): string[] | null => {
        if (value === null || value === '') { // Añadir value === '' para cadenas vacías
          return null;
        }
        try {
          const parsed = JSON.parse(value);
          // Asegúrate de que el parseo sea un array de strings.
          // Si no es un array o contiene elementos que no son strings, también devuelve null.
          if (Array.isArray(parsed) && parsed.every(item => typeof item === 'string')) {
            return parsed;
          }
          console.warn('Parsed carouselUrls is not an array of strings or contains non-string elements:', parsed);
          return null;
        } catch (e) {
          console.error('Error parsing carouselUrls from DB:', e);
          return null; // En caso de error de parseo, devuelve NULL
        }
      },
      to: (value: string[] | null): string | null => {
        if (value === null || value.length === 0) {
          return null; // Si es NULL o array vacío en la entidad, guarda NULL en la DB
        }
        return JSON.stringify(value);
      },
    },
  })
  carouselUrls: string[] | null;
}