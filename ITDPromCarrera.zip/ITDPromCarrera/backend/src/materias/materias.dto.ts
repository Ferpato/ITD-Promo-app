/* eslint-disable prettier/prettier */
// src/materias/dto/create-paragraph-group.dto.ts

import {
  IsString,
  IsNotEmpty,
  IsBoolean,
  IsOptional,
  IsArray,
  IsEnum, // Necesario para validar el enum
  IsUrl, // Necesario para validar las URLs del carrusel
} from 'class-validator';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { Type } from 'class-transformer'; // Necesario si tuvieras anidaciones que requieran transformación

// NOTA: No necesitamos ParagraphConfigDto ni CarouselMediaItemDto
// para este DTO de creación/actualización individual,
// ya que los campos se reciben aplanados directamente.

// --- DTO para la creación/inserción de un solo grupo de párrafo ---
// Este DTO mapea directamente a los campos de la entidad 'ParagraphGroup'.
export class CreateParagraphGroupDto {
  // El 'id' no se incluye aquí porque el backend lo generará.
  // El frontend envía los datos "sin ID" para una nueva inserción.

  @IsString()
  @IsNotEmpty()
  subdominio: string;

  // --- Campos del primer párrafo (firstItem) ---
  @IsString()
  @IsNotEmpty()
  firstItemTitle: string;

  @IsString()
  @IsNotEmpty()
  firstItemContent: string;

  @IsString()
  @IsNotEmpty()
  firstItemGradientFrom: string;

  @IsString()
  @IsNotEmpty()
  firstItemGradientTo: string;

  @IsBoolean()
  firstItemLineDecoration: boolean;

  @IsBoolean()
  firstItemOverLined: boolean;

  // --- Campo para el tipo de segundo ítem ---
  @IsEnum(['none', 'paragraph', 'carousel'], { message: 'secondItemType must be one of: none, paragraph, carousel' })
  @IsNotEmpty() // Siempre debe venir un tipo
  secondItemType: 'none' | 'paragraph' | 'carousel';

  // --- Campos del segundo párrafo (secondItemParagraph) ---
  // Son opcionales y pueden ser null
  @IsOptional()
  @IsString()
  secondItemTitle?: string | null;

  @IsOptional()
  @IsString()
  secondItemContent?: string | null;

  @IsOptional()
  @IsString()
  secondItemGradientFrom?: string | null;

  @IsOptional()
  @IsString()
  secondItemGradientTo?: string | null;

  @IsOptional()
  @IsBoolean()
  secondItemLineDecoration?: boolean | null;

  @IsOptional()
  @IsBoolean()
  secondItemOverLined?: boolean | null;

  // --- Campos para el carrusel (secondItemCarouselItems) ---
  // Es opcional, puede ser un array vacío o null
  @IsOptional()
  @IsArray()
  @IsString({ each: true }) // Cada elemento del array debe ser un string
  @IsUrl({ require_tld: false }, { each: true }) // Cada string debe ser una URL válida (require_tld: false para localhost)
  carouselUrls?: string[] | null; // El frontend ya envía un array de strings (o null)
}