/* eslint-disable prettier/prettier */
// src/materias/materias.module.ts

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MateriasService } from './materias.service';
import { MateriasController } from './materias.controller';
import { ParagraphGroup } from './materias.entity'; // Importa la entidad

@Module({
  imports: [
    TypeOrmModule.forFeature([ParagraphGroup]), // Registra la entidad en TypeORM para este módulo
  ],
  providers: [MateriasService], // Registra el servicio
  controllers: [MateriasController], // Registra el controlador
  exports: [MateriasService], // Si otros módulos necesitan usar MateriasService
})
export class MateriasModule {}